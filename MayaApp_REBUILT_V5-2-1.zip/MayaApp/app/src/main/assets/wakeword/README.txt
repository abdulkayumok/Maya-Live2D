WAKEWORD ASSETS
===============

Wake word models go here:

1. hey_maya.tflite
   Triggered by: "Hey Maya"
   Setting: hello_maya = true (default ON)

2. hello_maya.tflite  
   Triggered by: "Wake up Maya"  
   Setting: wake_up_maya = true (default OFF)

These are lightweight on-device keyword spotting models.
They run continuously at low power on AudioRecord input.

If you don't have these models, Maya falls back to
using the ASSIST intent (long-press home button).

For custom wake words: use TensorFlow Lite Model Maker
or Porcupine SDK to train your own.
