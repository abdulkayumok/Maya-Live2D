package com.getmaya.android.tools

import android.content.Context
import com.getmaya.android.automation.MayaAccessibilityService
import com.getmaya.android.automation.MayaNotificationListener
import com.getmaya.android.connectors.ConnectorsManager
import com.getmaya.android.core.TtsEngine
import com.getmaya.android.data.models.MayaSettings
import com.getmaya.android.data.repository.SettingsRepository
import com.getmaya.android.data.repository.WikiMemory
import com.getmaya.android.search.SearchEngine
import com.getmaya.android.termux.TermuxBridge
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// TOOL RESULT — uniform return type from every tool
//
// success  = true  → speak `speak` or return `data` silently
// success  = false → speak `error` to user
// silent   = true  → tool ran; don't speak anything
// ═══════════════════════════════════════════════════════════

data class ToolResult(
    val success: Boolean,
    val speak: String  = "",          // TTS output (success)
    val error: String  = "",          // TTS output (failure)
    val data: JSONObject = JSONObject(), // structured data for chaining
    val silent: Boolean = false       // run silently (e.g. background tasks)
) {
    val ttsText: String get() = if (success) speak else error

    companion object {
        fun ok(speak: String, data: JSONObject = JSONObject()) =
            ToolResult(true, speak = speak, data = data)

        fun silent(data: JSONObject = JSONObject()) =
            ToolResult(true, silent = true, data = data)

        fun err(msg: String) =
            ToolResult(false, error = msg)
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL CONTEXT — everything a tool might need, passed down
// ═══════════════════════════════════════════════════════════

class ToolContext(
    val context: Context,
    val settings: MayaSettings,
    val repo: SettingsRepository,
    val wiki: WikiMemory,
    val search: SearchEngine,
    val connectors: ConnectorsManager,
    val termux: TermuxBridge,
    val tts: TtsEngine,
    // Optional — only available when service is alive
    var accessibility: MayaAccessibilityService? = null,
    var notifications: MayaNotificationListener?  = null,
)
