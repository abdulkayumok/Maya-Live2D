package com.getmaya.android.msa.vad

/**
 * Represents a detected speech segment from the VAD pipeline.
 *
 * Extracted from APK DEX strings: "VadSegment(startMs=" and
 * the interface method onSegment(VadSegment).
 *
 * The guardian/silero_vad.tflite model produces these segments
 * when voice activity is detected in the mic stream.
 */
data class VadSegment(
    /** Segment start time in milliseconds from stream start. */
    val startMs: Long,
    /** Segment end time in milliseconds from stream start. -1 if still open. */
    val endMs: Long = -1L,
    /** Confidence score 0.0..1.0 from the VAD model. */
    val confidence: Float = 1.0f
) {
    /** True if this segment is still accumulating audio (endMs not set). */
    val isOpen: Boolean get() = endMs < 0L

    /** Duration in milliseconds. 0 if segment is still open. */
    val durationMs: Long get() = if (isOpen) 0L else endMs - startMs

    override fun toString(): String =
        "VadSegment(startMs=$startMs, endMs=$endMs, confidence=$confidence)"
}

/** Callback interface for VAD segment events. */
fun interface VadListener {
    /** Called each time a VAD segment is finalized or updated. */
    fun onSegment(segment: VadSegment)
}
