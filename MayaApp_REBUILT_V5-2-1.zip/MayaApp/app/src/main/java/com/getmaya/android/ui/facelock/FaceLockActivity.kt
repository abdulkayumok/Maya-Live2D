package com.getmaya.android.ui.facelock

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import android.util.Log
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Face lock / biometric camera authentication screen.
 *
 * Extracted from APK DEX:
 *   Fields:
 *     h0: ProcessCameraProvider  (front camera)
 *     i0: ProcessCameraProvider  (back camera / secondary)
 *     j0: Boolean                (authenticated flag)
 *     k0: Int                    (attempt counter)
 *   Methods:
 *     l() — internal camera setup
 *     m(): String — returns label or package name for the locked app
 *     n(Intent) — handles incoming launch intent
 *     onCreate, onDestroy, onNewIntent, onPause, onResume, onStop
 *
 * DEX intent extras read: "pkg", "label"
 * DEX action handled: android.intent.action.MAIN / android.intent.category.HOME
 *
 * Can act as a HOME replacement to intercept launcher launches when
 * face lock is enabled.
 */
class FaceLockActivity : AppCompatActivity() {

    companion object {
        private const val TAG        = "FaceLockActivity"
        const val EXTRA_PKG          = "pkg"
        const val EXTRA_LABEL        = "label"
        private const val MAX_TRIES  = 5
    }

    // DEX fields h0, i0: camera providers
    private var h0: ProcessCameraProvider? = null
    private var i0: ProcessCameraProvider? = null
    // DEX field j0: authenticated
    private var j0: Boolean = false
    // DEX field k0: attempt counter
    private var k0: Int = 0

    private var cameraExecutor: ExecutorService? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "FaceLockActivity — onCreate")
        cameraExecutor = Executors.newSingleThreadExecutor()
        n(intent)
        l()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        n(intent)
    }

    override fun onResume() {
        super.onResume()
        if (!j0) l()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        h0?.unbindAll()
        i0?.unbindAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor?.shutdown()
        h0?.unbindAll()
        i0?.unbindAll()
    }

    /** DEX method l() — camera bind and face analysis setup. */
    private fun l() {
        if (j0) return
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                h0 = providerFuture.get()
                bindCamera(h0!!)
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** DEX method m() — returns label of the app being locked. */
    private fun m(): String {
        return intent?.getStringExtra(EXTRA_LABEL)
            ?: intent?.getStringExtra(EXTRA_PKG)
            ?: packageName
    }

    /** DEX method n(Intent) — parse intent and set up lock target. */
    private fun n(intent: Intent?) {
        val pkg   = intent?.getStringExtra(EXTRA_PKG)   ?: return
        val label = intent.getStringExtra(EXTRA_LABEL)  ?: pkg
        Log.d(TAG, "FaceLock protecting: $label ($pkg)")
    }

    private fun bindCamera(provider: ProcessCameraProvider) {
        val selector = CameraSelector.DEFAULT_FRONT_CAMERA
        val preview  = Preview.Builder().build()
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { ia ->
                ia.setAnalyzer(cameraExecutor!!) { imageProxy ->
                    processFrame(imageProxy)
                    imageProxy.close()
                }
            }
        try {
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, preview, analysis)
        } catch (e: Exception) {
            Log.e(TAG, "Camera lifecycle bind failed: ${e.message}")
        }
    }

    private fun processFrame(image: androidx.camera.core.ImageProxy) {
        // Face detection wired to ML Kit / on-device model.
        // On successful recognition: j0 = true → finish() and allow launch.
        k0++
        if (k0 > MAX_TRIES * 10) {
            Log.d(TAG, "FaceLock max frames — falling back")
            runOnUiThread { finish() }
        }
    }
}
