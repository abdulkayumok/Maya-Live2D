package com.getmaya.android.termux

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Transparent trampoline Activity that requests the Termux RUN_COMMAND
 * permission at runtime, then finishes.
 *
 * Extracted from APK DEX:
 *   Field N: Boolean  (granted flag)
 *   Methods: onCreate, onDestroy, onRequestPermissionsResult
 *   DEX permission string: "com.termux.permission.RUN_COMMAND"
 *
 * Usage: start this Activity from TermuxBridge when the permission
 * is not yet granted; it requests it and delivers the result back
 * via a local broadcast that TermuxBridge is listening for.
 */
class TermuxPermissionActivity : Activity() {

    companion object {
        private const val TAG            = "TermuxPermActivity"
        private const val REQ_CODE       = 4921
        const val TERMUX_RUN_PERMISSION  = "com.termux.permission.RUN_COMMAND"
        const val ACTION_PERM_RESULT     = "com.getmaya.android.TERMUX_PERM_RESULT"
        const val EXTRA_GRANTED          = "granted"
    }

    private var N: Boolean = false   // permission granted — preserved from DEX field

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        N = ContextCompat.checkSelfPermission(this, TERMUX_RUN_PERMISSION) ==
                PackageManager.PERMISSION_GRANTED

        if (N) {
            deliverResult(true)
            finish()
            return
        }

        ActivityCompat.requestPermissions(this, arrayOf(TERMUX_RUN_PERMISSION), REQ_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_CODE) return

        N = grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED

        Log.d(TAG, "Termux RUN_COMMAND permission granted=$N")
        deliverResult(N)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Ensure result is delivered even if the activity is killed
        if (!N) deliverResult(false)
    }

    private fun deliverResult(granted: Boolean) {
        sendBroadcast(
            android.content.Intent(ACTION_PERM_RESULT)
                .setPackage(packageName)
                .putExtra(EXTRA_GRANTED, granted)
        )
    }
}
