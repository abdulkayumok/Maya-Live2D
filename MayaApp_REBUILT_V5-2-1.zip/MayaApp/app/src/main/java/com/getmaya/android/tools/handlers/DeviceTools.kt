package com.getmaya.android.tools.handlers

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import com.getmaya.android.tools.ToolContext
import com.getmaya.android.tools.ToolResult
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class DeviceTools(private val ctx: ToolContext) {

    private val c = ctx.context
    private val audio = c.getSystemService(AudioManager::class.java)

    // ── Volume ─────────────────────────────────────────────
    fun setVolume(level: Int, stream: String): ToolResult {
        val streamType = when (stream.lowercase()) {
            "music", "media"  -> AudioManager.STREAM_MUSIC
            "ring", "ringer"  -> AudioManager.STREAM_RING
            "alarm"           -> AudioManager.STREAM_ALARM
            "call", "voice"   -> AudioManager.STREAM_VOICE_CALL
            "notification"    -> AudioManager.STREAM_NOTIFICATION
            else              -> AudioManager.STREAM_MUSIC
        }
        val max = audio.getStreamMaxVolume(streamType)
        val target = (level.coerceIn(0, 100) * max / 100.0).toInt()
        audio.setStreamVolume(streamType, target, 0)
        return ToolResult.ok("Volume $level% kar diya")
    }

    // ── Torch ──────────────────────────────────────────────
    fun setTorch(on: Boolean): ToolResult {
        return try {
            val cm = c.getSystemService(CameraManager::class.java)
            val cameraId = cm.cameraIdList.firstOrNull() ?: return ToolResult.err("Camera nahi mila")
            cm.setTorchMode(cameraId, on)
            ToolResult.ok(if (on) "Torch on" else "Torch off")
        } catch (e: Exception) {
            ToolResult.err("Torch error: ${e.message}")
        }
    }

    // ── Brightness ─────────────────────────────────────────
    fun setBrightness(level: Int): ToolResult {
        return try {
            Settings.System.putInt(
                c.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            val value = (level.coerceIn(0, 100) * 255 / 100.0).toInt()
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            ToolResult.ok("Brightness $level% kar diya")
        } catch (e: Exception) {
            ToolResult.err("Brightness change nahi hua — WRITE_SETTINGS permission chahiye")
        }
    }

    fun setAutoBrightness(on: Boolean): ToolResult {
        return try {
            Settings.System.putInt(
                c.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (on) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                else    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            ToolResult.ok(if (on) "Auto brightness on" else "Auto brightness off")
        } catch (e: Exception) {
            ToolResult.err("Setting change nahi hua")
        }
    }

    // ── Ringer mode ────────────────────────────────────────
    fun setRingerMode(mode: String): ToolResult {
        val ringerMode = when (mode.lowercase()) {
            "silent", "mute"   -> AudioManager.RINGER_MODE_SILENT
            "vibrate"          -> AudioManager.RINGER_MODE_VIBRATE
            "normal", "ring"   -> AudioManager.RINGER_MODE_NORMAL
            "dnd"              -> { setDnd(); return ToolResult.ok("DND on") }
            else               -> AudioManager.RINGER_MODE_NORMAL
        }
        audio.ringerMode = ringerMode
        return ToolResult.ok("Ringer mode: $mode")
    }

    private fun setDnd() {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        // If we have DND permission, set it directly
        val nm = c.getSystemService(android.app.NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_NONE)
        } else {
            c.startActivity(intent)
        }
    }

    // ── Earpiece mode ──────────────────────────────────────
    fun setEarpieceMode(on: Boolean): ToolResult {
        audio.isSpeakerphoneOn = !on
        if (on) audio.mode = AudioManager.MODE_IN_CALL
        else    audio.mode = AudioManager.MODE_NORMAL
        return ToolResult.ok(if (on) "Earpiece mode on" else "Speaker mode on")
    }

    // ── Driving mode ───────────────────────────────────────
    fun setDrivingMode(on: Boolean): ToolResult {
        val prefs = c.getSharedPreferences("maya_settings_secure", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("maya_driving_mode", on).apply()
        c.sendBroadcast(Intent("com.getmaya.android.DRIVING_MODE_CHANGED").apply {
            putExtra("enabled", on)
        })
        return ToolResult.ok(if (on) "Driving mode on — auto-announce calls on" else "Driving mode off")
    }

    fun getDrivingMode(): ToolResult {
        val prefs = c.getSharedPreferences("maya_settings_secure", Context.MODE_PRIVATE)
        val on = prefs.getBoolean("maya_driving_mode", false)
        return ToolResult.ok(if (on) "Driving mode on hai" else "Driving mode off hai")
    }

    // ── Battery status ─────────────────────────────────────
    fun getBatteryStatus(): ToolResult {
        val bm = c.getSystemService(BatteryManager::class.java)
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        val status = if (charging) "charge ho raha hai" else "battery pe chal raha hai"
        return ToolResult.ok("Battery $level% — $status")
    }

    // ── Sound status ───────────────────────────────────────
    fun getSoundStatus(): ToolResult {
        val mode = when (audio.ringerMode) {
            AudioManager.RINGER_MODE_SILENT  -> "silent"
            AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
            else                             -> "normal"
        }
        val vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val pct = (vol * 100 / max.toFloat()).toInt()
        return ToolResult.ok("Ringer: $mode | Media volume: $pct%")
    }

    // ── Current time ───────────────────────────────────────
    fun getCurrentTime(): ToolResult {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy — h:mm a", Locale("hi", "IN"))
        return ToolResult.ok(sdf.format(Date()))
    }

    // ── Location ───────────────────────────────────────────
    fun getLocation(): ToolResult {
        if (ActivityCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            return ToolResult.err("Location permission nahi diya")
        }
        val lm = c.getSystemService(LocationManager::class.java)
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        for (provider in providers) {
            val loc = lm.getLastKnownLocation(provider)
            if (loc != null) {
                val data = JSONObject().apply {
                    put("lat", loc.latitude)
                    put("lng", loc.longitude)
                    put("accuracy", loc.accuracy)
                }
                return ToolResult.ok(
                    "Location mili: ${loc.latitude}, ${loc.longitude}",
                    data
                )
            }
        }
        return ToolResult.err("Location abhi available nahi — GPS on karo")
    }

    // ── Clipboard ──────────────────────────────────────────
    fun readClipboard(): ToolResult {
        val cm = c.getSystemService(ClipboardManager::class.java)
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        return if (!text.isNullOrEmpty())
            ToolResult.ok("Clipboard: $text")
        else
            ToolResult.err("Clipboard khaali hai")
    }

    fun writeClipboard(text: String): ToolResult {
        val cm = c.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("maya", text))
        return ToolResult.ok("Clipboard mein copy kar diya")
    }

    // ── Mute Maya ──────────────────────────────────────────
    fun muteMaya(mute: Boolean): ToolResult {
        c.sendBroadcast(Intent("com.getmaya.android.SET_MUTE").apply {
            putExtra("muted", mute)
        })
        return ToolResult.ok(if (mute) "Maya mute — sun rahi hoon, bolungi nahi" else "Maya unmute")
    }

    // ── Go to sleep ────────────────────────────────────────
    fun goToSleep(): ToolResult {
        val pm = c.getSystemService(PowerManager::class.java)
        // Requires DEVICE_POWER permission (system/root only)
        // Accessibility fallback: long-press power
        ctx.accessibility?.performLockScreen()
        return ToolResult.ok("Phone lock ho gaya")
    }
}
