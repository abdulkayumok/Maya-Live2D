package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VoiceModeSelectionScreen(navController: androidx.navigation.NavHostController) {
    var selectedCharacter by remember { mutableStateOf("Maya") }
    var selectedMode by remember { mutableStateOf("Normal") }

    val characters = listOf("Maya", "Friday", "Venom")
    
    val voiceModes = mapOf(
        "Maya" to listOf(
            VoiceMode("Leda", "Girlfriend", "रोमांटिक, मीठी आवाज़"),
            VoiceMode("Autonoe", "Normal", "तटस्थ, पेशेवर"),
            VoiceMode("Callirrhoe", "Friend", "अनौपचारिक, मज़ेदार"),
            VoiceMode("Laomedeia", "Mentor", "ज्ञानवान, शिक्षाप्रद")
        ),
        "Friday" to listOf(
            VoiceMode("Leda", "Assistant", "सहायक, पेशेवर"),
            VoiceMode("Zephyr", "Support", "सहायक, मैत्रीपूर्ण"),
            VoiceMode("Sulafat", "Expert", "विशेषज्ञ, तकनीकी"),
            VoiceMode("Gacrux", "Smart", "स्मार्ट, तीव्र")
        ),
        "Venom" to listOf(
            VoiceMode("Alnilam", "Dark", "अंधकार, गहरी आवाज़"),
            VoiceMode("Iapetus", "Aggressive", "आक्रामक, नाटकीय"),
            VoiceMode("Achernar", "Symbiote", "सिम्बायोट, भयानक"),
            VoiceMode("Fenrir", "Intense", "तीव्र, भारी")
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            "🎤 Voice Selection",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Character Selection
        Text(
            "Character",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            characters.forEach { char ->
                CharacterButton(
                    name = char,
                    selected = selectedCharacter == char,
                    onClick = { selectedCharacter = char }
                )
            }
        }

        // Voice Mode Selection
        Text(
            "Voice Mode",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        voiceModes[selectedCharacter]?.forEach { mode ->
            VoiceModeCard(
                mode = mode,
                selected = selectedMode == mode.voiceName,
                onClick = { selectedMode = mode.voiceName }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Apply Button
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Apply Settings", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CharacterButton(name: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .height(40.dp)
            .weight(1f),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) 
                MaterialTheme.colorScheme.primary 
            else 
                MaterialTheme.colorScheme.surface
        )
    ) {
        Text(
            name,
            fontSize = 12.sp,
            color = if (selected)
                MaterialTheme.colorScheme.onPrimary
            else
                MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun VoiceModeCard(mode: VoiceMode, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clickable(onClick = onClick)
            .background(
                if (selected) 
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surface
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        mode.displayName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        mode.voiceName,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                RadioButton(
                    selected = selected,
                    onClick = onClick,
                    colors = RadioButtonDefaults.colors(
                        selectedColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Text(
                mode.description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

data class VoiceMode(
    val voiceName: String,
    val displayName: String,
    val description: String
)
