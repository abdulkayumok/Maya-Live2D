package com.getmaya.android.tools.handlers

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Environment
import android.view.accessibility.AccessibilityNodeInfo
import com.getmaya.android.automation.MayaAccessibilityService
import com.getmaya.android.tools.ToolContext
import com.getmaya.android.tools.ToolResult
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class ScreenTools(private val ctx: ToolContext) {

    private fun acc(): MayaAccessibilityService? = ctx.accessibility

    // ── Tap by visible text ────────────────────────────────
    fun tapText(text: String, index: Int): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility service off hai — settings mein on karo")
        val found = a.findNodeByText(text, index)
            ?: return ToolResult.err("\"$text\" screen pe nahi mila")
        found.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return ToolResult.ok("\"$text\" pe tap kiya")
    }

    // ── Tap by element ID / viewId ─────────────────────────
    fun tapElement(elementId: String): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        val found = a.findNodeById(elementId)
            ?: return ToolResult.err("Element \"$elementId\" nahi mila")
        found.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return ToolResult.ok("Element tap kiya")
    }

    // ── Tap by screen coordinates ──────────────────────────
    fun tapCoords(x: Int, y: Int): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        a.dispatchGestureTap(x.toFloat(), y.toFloat())
        return ToolResult.ok("($x, $y) pe tap kiya")
    }

    // ── Scroll ─────────────────────────────────────────────
    fun scroll(down: Boolean, steps: Int): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        val root = a.rootInActiveWindow ?: return ToolResult.err("Screen nahi mili")
        val scrollable = findScrollable(root)
        repeat(steps) {
            scrollable?.performAction(
                if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else      AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        }
        return ToolResult.ok(if (down) "Scroll down kiya" else "Scroll up kiya")
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findScrollable(child)
            if (result != null) return result
        }
        return null
    }

    // ── Swipe gesture ──────────────────────────────────────
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        a.dispatchGestureSwipe(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat())
        return ToolResult.ok("Swipe kiya")
    }

    // ── Navigation ─────────────────────────────────────────
    fun goBack(): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        a.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        return ToolResult.ok("Back")
    }

    fun goHome(): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        a.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
        return ToolResult.ok("Home pe aaya")
    }

    // ── Open app by package name ───────────────────────────
    fun openApp(packageName: String): ToolResult {
        val pm = ctx.context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
            ?: return ToolResult.err("App nahi mila: $packageName")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.context.startActivity(intent)
        return ToolResult.ok("App khul raha hai")
    }

    // ── Open app by human name ─────────────────────────────
    fun openAppByName(name: String): ToolResult {
        // 1. Check remembered app names (wiki/prefs)
        val rememberedPkg = getRememberedAppPackage(name)
        if (rememberedPkg != null) return openApp(rememberedPkg)

        // 2. Search installed apps by label
        val pm = ctx.context.packageManager
        val apps = pm.getInstalledApplications(0)
        val matched = apps.firstOrNull { app ->
            pm.getApplicationLabel(app).toString().contains(name, ignoreCase = true)
        }
        if (matched != null) return openApp(matched.packageName)

        // 3. Common alias map
        val aliases = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "twitter" to "com.twitter.android",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient",
            "phone" to "com.google.android.dialer",
            "camera" to "com.android.camera2",
            "settings" to "com.android.settings",
            "play store" to "com.android.vending",
            "termux" to "com.termux"
        )
        val pkg = aliases[name.lowercase()]
            ?: return ToolResult.err("\"$name\" app nahi mila phone mein")
        return openApp(pkg)
    }

    private fun getRememberedAppPackage(name: String): String? {
        val prefs = ctx.context.getSharedPreferences("maya_app_names", Context.MODE_PRIVATE)
        return prefs.getString(name.lowercase(), null)
    }

    // ── Read all visible UI elements ───────────────────────
    fun readScreenElements(): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        val root = a.rootInActiveWindow ?: return ToolResult.err("Screen nahi mili")
        val elements = JSONArray()
        collectNodes(root, elements)
        return ToolResult.ok(
            "${elements.length()} elements mile screen pe",
            JSONObject().put("elements", elements)
        )
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: JSONArray) {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        val id   = node.viewIdResourceName ?: ""
        if (text.isNotEmpty() || desc.isNotEmpty() || node.isClickable) {
            out.put(JSONObject().apply {
                put("text", text)
                put("desc", desc)
                put("id", id)
                put("clickable", node.isClickable)
                put("class", node.className?.toString() ?: "")
            })
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectNodes(child, out)
        }
    }

    // ── Read screen as plain text ──────────────────────────
    fun readScreenText(): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        val root = a.rootInActiveWindow ?: return ToolResult.err("Screen nahi mili")
        val sb = StringBuilder()
        extractText(root, sb)
        val text = sb.toString().trim()
        return if (text.isNotEmpty())
            ToolResult.ok("Screen pe: $text")
        else
            ToolResult.err("Screen pe koi text nahi")
    }

    private fun extractText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        val t = node.text?.toString()
        if (!t.isNullOrEmpty()) sb.append(t).append(" ")
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            extractText(child, sb)
        }
    }

    // ── Wait for text to appear on screen ─────────────────
    suspend fun waitForText(text: String, timeoutMs: Long): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val root = a.rootInActiveWindow
            if (root != null && findTextInTree(root, text)) {
                return ToolResult.ok("\"$text\" screen pe aa gaya")
            }
            kotlinx.coroutines.delay(500)
        }
        return ToolResult.err("\"$text\" nahi mila ${timeoutMs / 1000}s mein")
    }

    private fun findTextInTree(node: AccessibilityNodeInfo, target: String): Boolean {
        if (node.text?.toString()?.contains(target, ignoreCase = true) == true) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findTextInTree(child, target)) return true
        }
        return false
    }

    // ── Screenshot ─────────────────────────────────────────
    fun takeScreenshot(share: Boolean): ToolResult {
        val a = acc() ?: return ToolResult.err("Accessibility off hai")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            a.takeScreenshot(ctx.context.mainExecutor) { ss ->
                if (ss != null) {
                    val bitmap = ss.hardwareBuffer?.let { Bitmap.wrapHardwareBuffer(it, null) }
                    if (bitmap != null) {
                        val file = saveScreenshot(bitmap)
                        if (share) {
                            ctx.context.sendBroadcast(Intent("com.getmaya.android.SHARE_SCREENSHOT").apply {
                                putExtra("path", file?.absolutePath)
                            })
                        } else {
                            ctx.context.sendBroadcast(Intent("com.getmaya.android.VISION_SCREENSHOT").apply {
                                putExtra("path", file?.absolutePath)
                            })
                        }
                    }
                }
            }
            return ToolResult.ok("Screenshot le raha hoon")
        }
        // Fallback: shell screenshot
        return ToolResult.err("Screenshot ke liye Android 11+ chahiye")
    }

    private fun saveScreenshot(bitmap: Bitmap): File? {
        return try {
            val dir = File(ctx.context.cacheDir, "screenshots").also { it.mkdirs() }
            val file = File(dir, "maya_ss_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 90, it) }
            file
        } catch (e: Exception) { null }
    }

    // ── Look at file ───────────────────────────────────────
    fun lookAtFile(path: String): ToolResult {
        // Sends file path to AiEngine for vision analysis
        ctx.context.sendBroadcast(Intent("com.getmaya.android.VISION_FILE").apply {
            putExtra("path", path)
        })
        return ToolResult.ok("File dekh raha hoon")
    }

    // ── Open barcode scanner ───────────────────────────────
    fun openScanner(): ToolResult {
        val intent = Intent(ctx.context, com.getmaya.android.ui.screens.BarcodeScannerScreen::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.context.startActivity(intent)
            ToolResult.ok("Scanner khul gaya")
        } catch (e: Exception) {
            ToolResult.err("Scanner nahi khula")
        }
    }
}

// Android version alias
private val Build = android.os.Build
