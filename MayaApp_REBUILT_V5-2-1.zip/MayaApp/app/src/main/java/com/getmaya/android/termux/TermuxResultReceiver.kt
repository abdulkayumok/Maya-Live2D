package com.getmaya.android.termux

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receives results from Termux command executions and routes them
 * to the waiting coroutine in [TermuxBridge].
 *
 * Extracted from APK DEX:
 *   onReceive(Context, Intent)
 *
 * DEX extra keys:
 *   "maya_exec_id"  — UUID identifying the pending TermuxBridge request
 *   "result"        — command stdout/stderr output
 *
 * DEX log strings:
 *   "TERMUX result for "
 *   " with nobody waiting"
 */
class TermuxResultReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG          = "TermuxResultReceiver"
        const val RESULT_ACTION        = "com.getmaya.android.TERMUX_RESULT"
        const val EXTRA_EXEC_ID        = "maya_exec_id"
        const val EXTRA_RESULT         = "result"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val execId = intent.getStringExtra(EXTRA_EXEC_ID) ?: return
        val result = intent.getStringExtra(EXTRA_RESULT) ?: ""

        Log.d(TAG, "TERMUX result for $execId")

        // Deliver result to TermuxBridge pending callback registry
        val delivered = TermuxBridge.deliverResult(execId, result)
        if (!delivered) {
            Log.d(TAG, "TERMUX result for $execId with nobody waiting")
        }
    }
}
