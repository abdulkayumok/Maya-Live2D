package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AutomationScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "⚡ Automation & Macros",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Text(
                "Create custom commands and automations",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimary.copy(0.8f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(6) { index ->
                MacroCard(
                    icon = when (index) {
                        0 -> "📱"
                        1 -> "🏠"
                        2 -> "🔔"
                        3 -> "⏰"
                        4 -> "🎵"
                        else -> "🔦"
                    },
                    title = when (index) {
                        0 -> "Call Someone"
                        1 -> "Control Smart Home"
                        2 -> "Send Notification"
                        3 -> "Set Reminder"
                        4 -> "Play Music"
                        else -> "Control Lights"
                    },
                    description = when (index) {
                        0 -> "\"Call Mom\""
                        1 -> "\"Turn on the AC\""
                        2 -> "\"Remind me to sleep\""
                        3 -> "\"Alarm at 7 AM\""
                        4 -> "\"Play my playlist\""
                        else -> "\"Dim the lights\""
                    },
                    enabled = index < 4
                )
            }

            item {
                Button(
                    onClick = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .padding(top = 12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("➕ Create Macro", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MacroCard(icon: String, title: String, description: String, enabled: Boolean) {
    var isActive by remember { mutableStateOf(enabled) }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(icon, fontSize = 24.sp)
                }

                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                    )
                }
            }

            Switch(
                checked = isActive,
                onCheckedChange = { isActive = it }
            )
        }
    }
}
