package com.getmaya.android.tools

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.view.WindowManager
import com.getmaya.android.data.models.MayaSettings
import com.getmaya.android.tools.handlers.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

// ═══════════════════════════════════════════════════════════
// TOOL DISPATCHER
// Routes tool_name → correct handler class
//
// Called by MayaForegroundService after AI returns a
// tool_call JSON: { "tool": "...", "params": {...} }
//
// Every handler is a suspend fun returning ToolResult.
// The service speaks result.ttsText via TtsEngine.
// ═══════════════════════════════════════════════════════════

class ToolDispatcher(private val ctx: ToolContext) {

    private val phone   by lazy { PhoneTools(ctx) }
    private val wa      by lazy { WhatsAppTools(ctx) }
    private val screen  by lazy { ScreenTools(ctx) }
    private val camera  by lazy { CameraTools(ctx) }
    private val web     by lazy { WebTools(ctx) }
    private val code    by lazy { CodeTools(ctx) }
    private val social  by lazy { SocialTools(ctx) }
    private val docs    by lazy { DocTools(ctx) }
    private val alarms  by lazy { AlarmTools(ctx) }
    private val device  by lazy { DeviceTools(ctx) }
    private val guard   by lazy { SecurityTools(ctx) }
    private val finance by lazy { FinanceTools(ctx) }
    private val mktg    by lazy { MarketingToolsHandler(ctx) }
    private val memory  by lazy { MemoryTools(ctx) }
    private val conn    by lazy { ConnectorTools(ctx) }
    private val auto    by lazy { AutomationTools(ctx) }
    private val pc      by lazy { PcLinkTools(ctx) }
    private val smarthome by lazy { SmartHomeTools(ctx) }
    private val persona by lazy { PersonaTools(ctx) }
    private val files   by lazy { FileTools(ctx) }

    // ── Main dispatch ──────────────────────────────────────
    suspend fun dispatch(toolName: String, params: JSONObject): ToolResult =
        withContext(Dispatchers.IO) {
            try {
                route(toolName, params)
            } catch (e: Exception) {
                ToolResult.err("Tool error in $toolName: ${e.message}")
            }
        }

    @Suppress("LongMethod", "CyclomaticComplexMethod")
    private suspend fun route(name: String, p: JSONObject): ToolResult = when (name) {

        // ── Phone & Calls ──────────────────────────────────
        "answer_call"          -> phone.answerCall()
        "reject_call"          -> phone.rejectCall(p.optString("message"))
        "end_call"             -> phone.endCall()
        "make_call", "call_named" -> phone.makeCall(p.optString("number"), p.optString("name"))
        "whatsapp_call"        -> phone.whatsappCall(p.optString("number"), p.optString("name"))
        "set_call_sim"         -> phone.setCallSim(p.optInt("sim", 1))
        "send_sms"             -> phone.sendSms(p.optString("number"), p.optString("message"))
        "get_lock_state"       -> phone.getLockState()
        "unlock_phone"         -> phone.unlockPhone()
        "lock_device"          -> phone.lockDevice()
        "start_commentary"     -> phone.startCommentary()
        "stop_commentary"      -> phone.stopCommentary()

        // ── WhatsApp ───────────────────────────────────────
        "whatsapp_send_message" -> wa.sendMessage(p.optString("number"), p.optString("name"), p.optString("message"))
        "whatsapp_send_file"    -> wa.sendFile(p.optString("number"), p.optString("filePath"))
        "send_voice_reply"      -> wa.sendVoiceReply(p.optString("number"), p.optString("audioPath"))
        "cancel_voice_reply"    -> wa.cancelVoiceReply()
        "prepare_voice_reply"   -> wa.prepareVoiceReply(p.optString("number"))
        "send_whatsapp_voice_reply" -> wa.sendForeignLangReply(p.optString("number"), p.optString("text"), p.optString("language"))
        "set_whatsapp_autoreply" -> wa.setAutoReply(p.optBoolean("enabled"), p.optString("message"))
        "get_whatsapp_autoreply" -> wa.getAutoReplyStatus()

        // ── Screen Automation ──────────────────────────────
        "tap_text"             -> screen.tapText(p.optString("text"), p.optInt("index", 0))
        "tap_element"          -> screen.tapElement(p.optString("elementId"))
        "tap_coordinates"      -> screen.tapCoords(p.optInt("x"), p.optInt("y"))
        "scroll_down"          -> screen.scroll(down = true, steps = p.optInt("steps", 3))
        "scroll_up"            -> screen.scroll(down = false, steps = p.optInt("steps", 3))
        "swipe"                -> screen.swipe(p.optInt("x1"), p.optInt("y1"), p.optInt("x2"), p.optInt("y2"))
        "go_back"              -> screen.goBack()
        "go_home"              -> screen.goHome()
        "open_app"             -> screen.openApp(p.optString("packageName"))
        "open_app_by_name"     -> screen.openAppByName(p.optString("name"))
        "read_screen_elements" -> screen.readScreenElements()
        "read_screen_text"     -> screen.readScreenText()
        "wait_for_screen_text" -> screen.waitForText(p.optString("text"), p.optLong("timeoutMs", 10_000))
        "need_vision"          -> screen.takeScreenshot(share = false)
        "look_at_screen"       -> screen.takeScreenshot(share = false)
        "look_at_file"         -> screen.lookAtFile(p.optString("path"))
        "open_scanner"         -> screen.openScanner()
        "send_screenshot"      -> screen.takeScreenshot(share = true)

        // ── Camera & Media ─────────────────────────────────
        "take_photo"           -> camera.takePhoto(p.optBoolean("front", false))
        "take_screenshot"      -> camera.captureScreen()
        "record_video"         -> camera.recordVideo(p.optLong("durationSec", 10))
        "record_screen"        -> camera.recordScreen(p.optLong("durationSec", 30))
        "stop_video_recording" -> camera.stopRecording()
        "start_screen_share"   -> camera.startScreenShare()
        "stop_screen_share"    -> camera.stopScreenShare()
        "generate_image"       -> camera.generateImage(p.optString("prompt"), p.optString("style"))
        "generate_quote_image" -> camera.generateQuoteImage(p.optString("text"), p.optString("author"), p.optString("background"))

        // ── Web & Research ─────────────────────────────────
        "web_search", "search_web" -> web.search(p.optString("query"), p.optInt("results", 5))
        "read_url", "read_page"    -> web.readUrl(p.optString("url"))
        "search_nearby"            -> web.searchNearby(p.optString("query"), p.optDouble("lat", 0.0), p.optDouble("lng", 0.0))
        "deep_research"            -> web.deepResearch(p.optString("topic"), p.optInt("depth", 3))
        "get_research_report"      -> web.getResearchReport(p.optString("topic"))
        "get_news"                 -> web.getNews(p.optString("topic"), p.optString("country", "in"))
        "get_weather"              -> web.getWeather(p.optString("location"))

        // ── Coding & Websites ──────────────────────────────
        "create_website"           -> code.createWebsite(p.optString("name"), p.optString("description"), p.optString("type"))
        "update_website"           -> code.updateWebsite(p.optString("name"), p.optString("instruction"))
        "read_website_code"        -> code.readWebsiteCode(p.optString("name"), p.optString("file"))
        "delete_website"           -> code.deleteWebsite(p.optString("name"))
        "deploy_website"           -> code.deployWebsite(p.optString("name"))
        "list_websites"            -> code.listWebsites()
        "list_live_websites"       -> code.listLiveWebsites()
        "check_website", "get_website_status" -> code.getWebsiteStatus(p.optString("name"))
        "generate_website_page"    -> code.generatePage(p.optString("site"), p.optString("page"), p.optString("description"))
        "create_code_project"      -> code.createCodeProject(p.optString("name"), p.optString("language"), p.optString("description"))
        "publish_to_github"        -> code.publishToGithub(p.optString("project"), p.optString("repo"), p.optString("message"))
        "github_local_read"        -> code.githubLocalRead(p.optString("repo"), p.optString("path"))

        // ── Social Media ───────────────────────────────────
        "post_photo_to_social"     -> social.postPhoto(p.optString("platform"), p.optString("imagePath"), p.optString("caption"))
        "post_to_social", "publish_content" -> social.postText(p.optString("platform"), p.optString("text"))
        "post_story"               -> social.postStory(p.optString("platform"), p.optString("mediaPath"))
        "facebook_post", "fb_post" -> social.facebookPost(p.optString("text"), p.optString("imagePath"))
        "ig_post", "instagram_post", "insta_post", "image_post" -> social.instagramPost(p.optString("imagePath"), p.optString("caption"))
        "schedule_post"            -> social.schedulePost(p.optString("platform"), p.optString("content"), p.optString("time"))
        "cancel_scheduled_post"    -> social.cancelScheduledPost(p.optString("id"))
        "list_scheduled_posts"     -> social.listScheduledPosts()
        "set_daily_story"          -> social.setDailyStory(p.optBoolean("enabled"), p.optString("time"))
        "create_content"           -> social.createContent(p.optString("topic"), p.optString("platform"), p.optString("tone"))
        "auto_post"                -> social.autoPost(p.optBoolean("enabled"))

        // ── Documents & Notes ──────────────────────────────
        "create_document"          -> docs.createDocument(p.optString("title"), p.optString("content"))
        "read_document"            -> docs.readDocument(p.optString("title"))
        "list_documents"           -> docs.listDocuments()
        "open_document"            -> docs.openDocument(p.optString("title"))
        "write_email"              -> docs.writeEmail(p.optString("to"), p.optString("subject"), p.optString("body"))
        "send_email"               -> docs.sendEmail(p.optString("to"), p.optString("subject"), p.optString("body"))
        "create_note"              -> docs.createNote(p.optString("title"), p.optString("content"))
        "add_note"                 -> docs.addNote(p.optString("content"))
        "save_script_to_notes"     -> docs.saveScript(p.optString("title"), p.optString("script"))
        "write_video_script"       -> docs.writeVideoScript(p.optString("topic"), p.optString("duration"), p.optString("style"))

        // ── Alarms & Reminders ─────────────────────────────
        "add_reminder"             -> alarms.addReminder(p.optString("text"), p.optString("time"), p.optString("repeat"))
        "list_reminders"           -> alarms.listReminders()
        "set_alarm"                -> alarms.setAlarm(p.optString("time"), p.optString("label"))
        "set_timer"                -> alarms.setTimer(p.optLong("seconds"), p.optString("label"))
        "add_calendar_event"       -> alarms.addCalendarEvent(p.optString("title"), p.optString("start"), p.optString("end"), p.optString("location"))
        "set_event_trigger"        -> alarms.setEventTrigger(p.optString("event"), p.optString("action"))

        // ── Audio & Device ─────────────────────────────────
        "set_volume"               -> device.setVolume(p.optInt("level"), p.optString("stream", "music"))
        "set_torch"                -> device.setTorch(p.optBoolean("on"))
        "set_brightness"           -> device.setBrightness(p.optInt("level"))
        "set_auto_brightness"      -> device.setAutoBrightness(p.optBoolean("on"))
        "set_ringer_mode"          -> device.setRingerMode(p.optString("mode"))
        "set_earpiece_mode"        -> device.setEarpieceMode(p.optBoolean("on"))
        "set_driving_mode"         -> device.setDrivingMode(p.optBoolean("on"))
        "get_driving_mode"         -> device.getDrivingMode()
        "get_battery_status"       -> device.getBatteryStatus()
        "get_sound_status"         -> device.getSoundStatus()
        "get_current_time"         -> device.getCurrentTime()
        "get_location"             -> device.getLocation()
        "read_clipboard"           -> device.readClipboard()
        "write_clipboard"          -> device.writeClipboard(p.optString("text"))
        "mute_maya"                -> device.muteMaya(true)
        "unmute_maya"              -> device.muteMaya(false)
        "go_to_sleep"              -> device.goToSleep()

        // ── Security & Guard ───────────────────────────────
        "arm_guard"                -> guard.armGuard()
        "disarm_guard"             -> guard.disarmGuard()
        "set_touch_guard"          -> guard.setTouchGuard(p.optBoolean("on"))
        "get_touch_guard_status"   -> guard.getTouchGuardStatus()
        "guardian_lock"            -> guard.guardianLock()
        "set_watchman"             -> guard.setWatchman(p.optBoolean("on"))
        "get_watchman_log"         -> guard.getWatchmanLog()
        "add_face"                 -> guard.addFace(p.optString("name"), p.optString("role"))
        "remove_face"              -> guard.removeFace(p.optString("name"))
        "list_faces"               -> guard.listFaces()
        "verify_face"              -> guard.verifyFace()
        "set_voice_role"           -> guard.setVoiceRole(p.optString("role"))
        "remove_voice"             -> guard.removeVoice(p.optString("name"))
        "list_voices"              -> guard.listVoices()
        "voice_check"              -> guard.voiceCheck()
        "sos_trigger"              -> guard.sosTrigger()
        "add_sos_contact"          -> guard.addSosContact(p.optString("name"), p.optString("number"))
        "list_sos_contacts"        -> guard.listSosContacts()

        // ── Finance & Stocks ───────────────────────────────
        "get_stock_quote"          -> finance.getStockQuote(p.optString("symbol"))
        "get_stock_history"        -> finance.getStockHistory(p.optString("symbol"), p.optString("period", "1mo"))
        "get_stock_indicators"     -> finance.getStockIndicators(p.optString("symbol"))
        "get_trending_stocks"      -> finance.getTrendingStocks(p.optString("market", "NSE"))
        "search_stock"             -> finance.searchStock(p.optString("query"))
        "add_to_watchlist"         -> finance.addToWatchlist(p.optString("symbol"))
        "remove_from_watchlist"    -> finance.removeFromWatchlist(p.optString("symbol"))
        "get_watchlist"            -> finance.getWatchlist()
        "list_price_alerts"        -> finance.listPriceAlerts()
        "set_price_alert"          -> finance.setPriceAlert(p.optString("symbol"), p.optDouble("price"), p.optString("condition", "above"))
        "add_holding"              -> finance.addHolding(p.optString("symbol"), p.optDouble("qty"), p.optDouble("avgPrice"))
        "remove_holding"           -> finance.removeHolding(p.optString("symbol"))
        "update_holding"           -> finance.updateHolding(p.optString("symbol"), p.optDouble("qty"), p.optDouble("avgPrice"))
        "add_stock_holding"        -> finance.addHolding(p.optString("symbol"), p.optDouble("qty"), p.optDouble("avgPrice"))
        "get_portfolio"            -> finance.getPortfolio()
        "get_market_news"          -> finance.getMarketNews(p.optString("symbol"))
        "get_market_snapshot"      -> finance.getMarketSnapshot(p.optString("market", "NSE"))
        "get_crypto_price"         -> finance.getCryptoPrice(p.optString("symbol"))
        "get_forex_rate"           -> finance.getForexRate(p.optString("from"), p.optString("to"))
        "scan_watchlist"           -> finance.scanWatchlist()
        "send_report"              -> finance.sendReport(p.optString("type"), p.optString("period"))
        "save_report_format"       -> finance.saveReportFormat(p.optString("format"))

        // ── Marketing & Leads ──────────────────────────────
        "create_ad_plan"           -> mktg.createAdPlan(p.optString("product"), p.optString("budget"), p.optString("audience"))
        "create_landing_page"      -> mktg.createLandingPage(p.optString("product"), p.optString("cta"))
        "get_ad_metrics"           -> mktg.getAdMetrics(p.optString("platform"), p.optString("period"))
        "add_lead"                 -> mktg.addLead(p.optString("name"), p.optString("phone"), p.optString("email"), p.optString("note"))
        "update_lead"              -> mktg.updateLead(p.optString("id"), p.optString("status"), p.optString("note"))
        "delete_lead"              -> mktg.deleteLead(p.optString("id"))
        "list_leads"               -> mktg.listLeads(p.optString("status"))
        "send_lead_message"        -> mktg.sendLeadMessage(p.optString("id"), p.optString("message"))
        "set_message_alerts"       -> mktg.setMessageAlerts(p.optBoolean("on"), p.optString("keyword"))
        "list_watches"             -> mktg.listWatches()
        "send_webhook"             -> mktg.sendWebhook(p.optString("url"), p)
        "get_add_metrics"          -> mktg.getAdMetrics(p.optString("platform"), p.optString("period"))

        // ── Memory & Rules ─────────────────────────────────
        "backup_memory"            -> memory.backupMemory()
        "restore_memory"           -> memory.restoreMemory(p.optString("backup"))
        "export_memory"            -> memory.exportMemory()
        "add_rule"                 -> memory.addRule(p.optString("trigger"), p.optString("action"), p.optString("condition"))
        "delete_rule"              -> memory.deleteRule(p.optString("id"))
        "list_rules"               -> memory.listRules()
        "update_rule"              -> memory.updateRule(p.optString("id"), p.optString("trigger"), p.optString("action"))
        "set_user_name"            -> memory.setUserName(p.optString("name"))
        "memory_auto_save"         -> memory.setAutoSave(p.optBoolean("on"))

        // ── Connectors & External ──────────────────────────
        "notion_search"            -> conn.notionSearch(p.optString("query"))
        "spotify_play"             -> conn.spotifyPlay(p.optString("query"))
        "play_music", "play_song", "play_favorite_song" -> conn.playMusic(p.optString("query"), p.optString("service"))
        "get_now_playing"          -> conn.getNowPlaying()
        "set_music_preferences"    -> conn.setMusicPrefs(p.optString("genres"), p.optString("service"))
        "youtube_search", "youtube_search_and_play", "play_youtube", "search_youtube", "youtube_open" -> conn.youtubePlay(p.optString("query"))

        // ── Automation & Macros ────────────────────────────
        "play_macro"               -> auto.playMacro(p.optString("name"))
        "record_macro"             -> auto.recordMacro(p.optString("name"))
        "create_macro"             -> auto.createMacro(p.optString("name"), p.optString("steps"))
        "edit_macro"               -> auto.editMacro(p.optString("name"), p.optString("steps"))
        "delete_macro"             -> auto.deleteMacro(p.optString("name"))
        "save_macro"               -> auto.saveMacro(p.optString("name"))
        "list_macros"              -> auto.listMacros()
        "run_agent_task"           -> auto.runAgentTask(p.optString("task"), p.optInt("steps", 10))
        "run_mission"              -> auto.runMission(p.optString("mission"))
        "run_tool"                 -> dispatch(p.optString("tool"), p.optJSONObject("params") ?: JSONObject())
        "find_tool"                -> auto.findTool(p.optString("query"))
        "remember_app_name"        -> auto.rememberAppName(p.optString("name"), p.optString("packageName"))

        // ── PC Link ────────────────────────────────────────
        "call_my_pc"               -> pc.callPc()
        "end_pc_call"              -> pc.endPcCall()
        "ask_pc_maya"              -> pc.askPcMaya(p.optString("message"))
        "pc_control"               -> pc.pcControl(p.optString("command"))
        "relay_to_pc"              -> pc.relayToPc(p.optString("data"))
        "start_duet_call"          -> pc.startDuetCall()
        "set_listen_mode"          -> pc.setListenMode(p.optString("mode"))
        "set_voice_filter"         -> pc.setVoiceFilter(p.optBoolean("on"), p.optString("profile"))

        // ── Smart Home ─────────────────────────────────────
        "smart_home_list"          -> smarthome.listDevices()
        "open_bluetooth_settings"  -> smarthome.openBluetoothSettings()
        "open_wifi_settings"       -> smarthome.openWifiSettings()

        // ── Persona & Settings ─────────────────────────────
        "switch_persona"           -> persona.switchPersona(p.optString("name"))
        "get_personas"             -> persona.getPersonas()
        "set_intimacy"             -> persona.setIntimacy(p.optInt("level"))
        "install_skill"            -> persona.installSkill(p.optString("name"))
        "uninstall_skill"          -> persona.uninstallSkill(p.optString("name"))
        "list_skills"              -> persona.listSkills()
        "create_skill"             -> persona.createSkill(p.optString("name"), p.optString("description"), p.optString("trigger"), p.optString("action"))
        "open_whiteboard"          -> persona.openWhiteboard()
        "whiteboard_teach"         -> persona.whiteboardTeach(p.optString("topic"))
        "whiteboard_clear"         -> persona.whiteboardClear()

        // ── Files & Contacts ───────────────────────────────
        "find_files"               -> files.findFiles(p.optString("query"), p.optString("type"))
        "delete_file"              -> files.deleteFile(p.optString("path"))
        "share_file"               -> files.shareFile(p.optString("path"), p.optString("target"))
        "open_file"                -> files.openFile(p.optString("path"))
        "open_url"                 -> files.openUrl(p.optString("url"))
        "open_website"             -> files.openUrl(p.optString("url"))
        "find_contact"             -> files.findContact(p.optString("name"))
        "find_email_address"       -> files.findEmail(p.optString("name"))
        "save_contact"             -> files.saveContact(p.optString("name"), p.optString("phone"), p.optString("email"))
        "add_favorite"             -> files.addFavorite(p.optString("name"), p.optString("value"), p.optString("type"))
        "remove_favorite"          -> files.removeFavorite(p.optString("name"))
        "list_favorites"           -> files.listFavorites()

        // ── Misc / IDE / Termux ────────────────────────────
        "termux_run"               -> auto.termuxRun(p.optString("command"))
        "set_git_identity"         -> code.setGitIdentity(p.optString("name"), p.optString("email"))
        "huntercode_deploy"        -> code.huntercodeAction("deploy", p.optString("project"))
        "huntercode_open"          -> code.huntercodeAction("open", p.optString("project"))

        else -> ToolResult.err("Unknown tool: $name. Maya ko yeh tool nahi pata.")
    }
}
