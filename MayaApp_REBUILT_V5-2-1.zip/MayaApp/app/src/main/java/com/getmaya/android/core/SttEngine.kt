package com.getmaya.android.core

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// STT ENGINE — Deepgram WebSocket (nova-3, multi-language)
//
// From APK:
// wss://api.deepgram.com/v1/listen
// ?model=nova-3&language=multi
// &encoding=linear16&sample_rate=16000
// &interim_results=true&smart_format=true
//
// Fallback: Android SpeechRecognizer (Google STT)
// ═══════════════════════════════════════════════════════════

class SttEngine(private val context: Context) {

    private val SAMPLE_RATE   = 16000
    private val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    private val AUDIO_FORMAT   = AudioFormat.ENCODING_PCM_16BIT
    private val BUFFER_SIZE    = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT) * 2

    private var audioRecord: AudioRecord? = null
    private var wsClient: WebSocket? = null
    @Volatile private var isRecording = false
    private var captureJob: Job? = null
    private val http = OkHttpClient()

    // ── Start streaming STT ────────────────────────────────
    fun startStreaming(
        deepgramApiKey: String,
        onInterim: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val url = buildDeepgramUrl()

        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Token $deepgramApiKey")
            .build()

        wsClient = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                startMicCapture(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                parseDeepgramResponse(text, onInterim, onFinal)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                stopRecording()
                onError(t.message ?: "Deepgram error")
                // Fallback to Google STT
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                stopRecording()
            }
        })
    }

    private fun buildDeepgramUrl(): String {
        return "wss://api.deepgram.com/v1/listen" +
            "?model=nova-3" +
            "&language=multi" +           // Hindi + English detection
            "&encoding=linear16" +
            "&sample_rate=$SAMPLE_RATE" +
            "&interim_results=true" +
            "&smart_format=true" +        // Auto-punctuation
            "&endpointing=300" +          // 300ms silence = end
            "&utterance_end_ms=1000"
    }

    private fun startMicCapture(ws: WebSocket) {
        stopRecording()
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT
        )
        if (minBuffer <= 0) {
            ws.close(1011, "Microphone unavailable")
            return
        }

        val bufferBytes = maxOf(BUFFER_SIZE, minBuffer * 2)
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, bufferBytes
            )
        } catch (_: Exception) {
            ws.close(1011, "Could not initialize microphone")
            return
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            ws.close(1011, "Microphone not initialized")
            return
        }

        try {
            recorder.startRecording()
        } catch (_: Exception) {
            recorder.release()
            ws.close(1011, "Could not start microphone")
            return
        }
        audioRecord = recorder
        isRecording = true

        captureJob = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ShortArray(bufferBytes / 2)
            try {
                while (isRecording && isActive) {
                    val read = recorder.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        val bytes = ByteArray(read * 2)
                        for (i in 0 until read) {
                            bytes[i * 2] = (buffer[i].toInt() and 0xFF).toByte()
                            bytes[i * 2 + 1] = (buffer[i].toInt() shr 8 and 0xFF).toByte()
                        }
                        if (!ws.send(ByteString.of(*bytes))) break
                    } else if (read < 0) {
                        break
                    }
                }
            } finally {
                isRecording = false
                if (audioRecord === recorder) audioRecord = null
                try { recorder.stop() } catch (_: Exception) {}
                try { recorder.release() } catch (_: Exception) {}
                ws.send("{\"type\":\"CloseStream\"}")
            }
        }
    }

    private fun parseDeepgramResponse(
        json: String,
        onInterim: (String) -> Unit,
        onFinal: (String) -> Unit
    ) {
        try {
            val obj = JSONObject(json)
            val isFinal = obj.getBoolean("is_final")
            val transcript = obj
                .getJSONArray("channel")
                .getJSONObject(0)
                .getJSONArray("alternatives")
                .getJSONObject(0)
                .getString("transcript")

            if (transcript.isNotBlank()) {
                if (isFinal) onFinal(transcript) else onInterim(transcript)
            }
        } catch (_: Exception) {}
    }

    fun stopRecording() {
        isRecording = false
        val recorder = audioRecord
        audioRecord = null
        if (recorder != null) {
            try {
                if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop()
            } catch (_: Exception) {
            }
            // The capture coroutine owns final release when active.
            if (captureJob?.isActive != true) {
                try { recorder.release() } catch (_: Exception) {}
            }
        }
        if (captureJob?.isActive != true) captureJob = null
    }

    fun stopStreaming() {
        stopRecording()
        wsClient?.close(1000, "Done")
        wsClient = null
    }

    // ── Fallback: record a fixed buffer for voice guardian ─
    suspend fun recordBuffer(durationMs: Int): ShortArray = withContext(Dispatchers.IO) {
        val numSamples = (SAMPLE_RATE * durationMs / 1000)
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT,
            BUFFER_SIZE
        )
        recorder.startRecording()
        val buffer = ShortArray(numSamples)
        recorder.read(buffer, 0, numSamples)
        recorder.stop()
        recorder.release()
        buffer
    }
}
