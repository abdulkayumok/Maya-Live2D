package com.getmaya.android.notify

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import android.util.Log

/**
 * Background worker for delivering Maya notices and announcements.
 *
 * Extracted from APK DEX:
 *   constructor(Context, WorkerParameters)
 *   doWork() via coroutine dispatch (DEX method f(CF))
 *
 * Runs in WorkManager's background pool. Fetches and posts
 * pending notices that Maya has queued for the user.
 */
class NoticeWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG   = "NoticeWorker"
        const val WORK_NAME     = "maya_notice_worker"
        const val KEY_NOTICE_ID = "notice_id"
        const val KEY_MESSAGE   = "message"
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "NoticeWorker — started")
        return try {
            deliverPendingNotices()
            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "NoticeWorker failed: ${t.message}", t)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    private suspend fun deliverPendingNotices() {
        val prefs = applicationContext.getSharedPreferences("maya_notices", Context.MODE_PRIVATE)
        val pending = prefs.all.entries
            .filter { it.key.startsWith("notice_") }
            .sortedBy { it.key }

        for (entry in pending) {
            val msg = entry.value as? String ?: continue
            Log.d(TAG, "Delivering notice: $msg")
            // Actual delivery wired to NotificationHelper / TTS on main thread
            prefs.edit().remove(entry.key).apply()
        }
    }
}
