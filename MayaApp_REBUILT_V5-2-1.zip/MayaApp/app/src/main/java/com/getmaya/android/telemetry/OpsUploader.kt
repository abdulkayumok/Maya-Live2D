package com.getmaya.android.telemetry

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/**
 * Background worker that uploads operational telemetry.
 *
 * Extracted from APK DEX:
 *   Fields U: OkHttpClient, V: coroutine context
 *   constructor(Context, WorkerParameters)
 *   doWork() via coroutine dispatch (DEX method f(CF))
 *
 * DEX strings:
 *   "application/json"
 *   " Tum yeh baat use kar sakti ho agar natural lage: \""
 *   (AI insight injection string — used when Maya generates a contextual tip)
 */
class OpsUploader(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG       = "OpsUploader"
        const val WORK_NAME         = "maya_ops_upload"
        private const val JSON_TYPE = "application/json"
        /** AI response injection prefix used when surfacing usage insights. */
        const val AI_INSIGHT_PREFIX =
            " Tum yeh baat use kar sakti ho agar natural lage: \""
    }

    private val U = OkHttpClient()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "OpsUploader — started")
        try {
            val payload = buildPayload()
            uploadOps(payload)
            Log.d(TAG, "OpsUploader — success")
            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "OpsUploader — failed: ${t.message}", t)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    private fun buildPayload(): JSONObject {
        val prefs = applicationContext.getSharedPreferences("maya_ops", Context.MODE_PRIVATE)
        return JSONObject().apply {
            put("app_version", packageVersion())
            put("session_count", prefs.getInt("session_count", 0))
            put("voice_uses",    prefs.getInt("voice_uses", 0))
            put("ts",            System.currentTimeMillis())
        }
    }

    private suspend fun uploadOps(payload: JSONObject) {
        // Ops endpoint — internal only; no external network call in open build
        Log.d(TAG, "OpsUploader payload: $payload")
    }

    private fun packageVersion(): String = try {
        applicationContext.packageManager
            .getPackageInfo(applicationContext.packageName, 0).versionName ?: "?"
    } catch (e: Exception) { "?" }
}
