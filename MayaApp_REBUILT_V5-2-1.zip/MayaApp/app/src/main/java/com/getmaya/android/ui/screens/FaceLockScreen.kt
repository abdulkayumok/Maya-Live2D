package com.getmaya.android.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FaceLockScreen(navController: androidx.navigation.NavHostController) {
    var isScanning by remember { mutableStateOf(false) }
    var isFaceDetected by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "faceScan")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = InfiniteRepeatableSpec(
            animation = tween(1500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "faceScale"
    )

    LaunchedEffect(isScanning) {
        if (isScanning) {
            repeat(100) {
                scanProgress = it / 100f
                kotlinx.coroutines.delay(50)
            }
            isFaceDetected = true
            kotlinx.coroutines.delay(1000)
            isScanning = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!isFaceDetected) {
            // Face Scanning Camera View
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .background(
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.extraLarge
                    )
                    .scale(scale),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "📷",
                    fontSize = 80.sp,
                    modifier = Modifier.scale(if (isScanning) scale else 1f)
                )
            }

            Text(
                if (isScanning) "Scanning Face..." else "Position Your Face",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 32.dp)
            )

            if (isScanning) {
                LinearProgressIndicator(
                    progress = { scanProgress },
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .padding(top = 24.dp)
                )
            }

            Button(
                onClick = { isScanning = true },
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .padding(top = 32.dp)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(if (isScanning) "Scanning..." else "Start Scan", fontSize = 14.sp)
            }
        } else {
            // Face Detected - Success State
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = MaterialTheme.shapes.extraLarge
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("✅", fontSize = 80.sp)
            }

            Text(
                "Face Unlocked!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 32.dp)
            )

            Text(
                "Device is now unlocked",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(0.7f),
                modifier = Modifier.padding(top = 8.dp)
            )

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .padding(top = 32.dp)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text("Continue", fontSize = 14.sp)
            }
        }
    }
}
