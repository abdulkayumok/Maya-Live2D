package com.getmaya.android.guardian

import android.content.Context
import com.getmaya.android.data.models.VoiceRole
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

// ═══════════════════════════════════════════════════════════
// VOICE GUARDIAN ENGINE — reverse engineered from APK
//
// Pipeline:
// Audio → Silero VAD → ECAPA-TDNN → AS-Norm vs cohort.bin → Accept/Reject
//
// Files (from assets/guardian/):
// - ecapa6s.tflite     ~42MB ECAPA-TDNN speaker model
// - silero_vad.tflite  ~650KB VAD model
// - cohort.bin         MAYACOH1 header + 200×192 float32 vectors
//
// Accuracy: EER 1.43% @ 5dB SNR (production grade)
// ═══════════════════════════════════════════════════════════

class VoiceGuardianEngine(private val context: Context) {

    private var ecapaInterpreter: Interpreter? = null
    private var vadInterpreter: Interpreter? = null
    private var cohortVectors: Array<FloatArray> = emptyArray()
    private val enrolledProfiles = mutableListOf<VoiceAuthProfile>()

    companion object {
        const val SAMPLE_RATE = 16000
        const val VOICED_SECONDS = 6               // 6s voiced audio for embedding
        const val EMBEDDING_DIM = 192              // ECAPA output dimension
        const val COHORT_COUNT = 200               // stranger vectors in cohort.bin
        const val EER_THRESHOLD = 0.5f             // cosine similarity threshold
        const val COHORT_MAGIC = "MAYACOH1"
    }

    // ── Initialization ─────────────────────────────────────
    fun initialize() {
        loadEcapaModel()
        loadVadModel()
        loadCohort()
        loadEnrolledProfiles()
    }

    private fun loadEcapaModel() {
        val modelFile = context.assets.open("guardian/ecapa6s.tflite").use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(modelFile.size)
            .order(ByteOrder.nativeOrder())
            .apply { put(modelFile); rewind() }
        ecapaInterpreter = Interpreter(buffer)
        // Input:  [1, 96000] raw waveform (6s × 16kHz)
        // Output: [1, 192]   speaker embedding
    }

    private fun loadVadModel() {
        val modelFile = context.assets.open("guardian/silero_vad.tflite").use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(modelFile.size)
            .order(ByteOrder.nativeOrder())
            .apply { put(modelFile); rewind() }
        vadInterpreter = Interpreter(buffer)
        // Silero VAD v4: frame-by-frame with LSTM hidden state
        // Input:  audio frame
        // Output: speech probability [0.0 - 1.0]
    }

    private fun loadCohort() {
        // Parse cohort.bin — MAYACOH1 format
        // Header: 8 bytes magic + 4 bytes count + 4 bytes dim
        // Body:   count × dim × 4 bytes (float32)
        context.assets.open("guardian/cohort.bin").use { stream ->
            val data = stream.readBytes()
            val magic = String(data, 0, 8)
            if (magic != COHORT_MAGIC) throw IllegalStateException("Invalid cohort file")

            val count = ByteBuffer.wrap(data, 8, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val dim   = ByteBuffer.wrap(data, 12, 4).order(ByteOrder.LITTLE_ENDIAN).int
            // count=200, dim=192

            cohortVectors = Array(count) { i ->
                val offset = 16 + i * dim * 4
                FloatArray(dim) { j ->
                    ByteBuffer.wrap(data, offset + j * 4, 4)
                        .order(ByteOrder.LITTLE_ENDIAN).float
                }
            }
        }
    }

    private fun loadEnrolledProfiles() {
        // Load from EncryptedSharedPreferences or profiles.json
        // Each profile: name, role (BOSS/FAMILY/FRIEND/GUEST/BLOCKED), embedding
    }

    // ── Verification pipeline ──────────────────────────────
    fun verify(audioBuffer: ShortArray): VerificationResult {
        // 1. VAD: collect 6s of VOICED audio
        val voicedAudio = extractVoicedSegments(audioBuffer)
        if (voicedAudio.size < SAMPLE_RATE * VOICED_SECONDS) {
            return VerificationResult.INSUFFICIENT_SPEECH
        }

        // 2. ECAPA-TDNN: generate embedding
        val embedding = extractEmbedding(voicedAudio)

        // 3. Compare against enrolled profiles
        for (profile in enrolledProfiles) {
            val rawScore = cosineSimilarity(embedding, profile.embedding)
            val normScore = asNorm(rawScore, embedding, profile.embedding)

            if (normScore > EER_THRESHOLD) {
                return VerificationResult.ACCEPTED(profile.name, profile.role, normScore)
            }
        }

        return VerificationResult.REJECTED
    }

    private fun extractVoicedSegments(audio: ShortArray): FloatArray {
        // Silero VAD: process frame by frame (30ms frames at 16kHz = 480 samples)
        val FRAME_SIZE = 480
        val voiced = mutableListOf<Float>()
        var h = FloatArray(64) { 0f }  // LSTM hidden state
        var c = FloatArray(64) { 0f }  // LSTM cell state

        for (i in audio.indices step FRAME_SIZE) {
            val frame = FloatArray(FRAME_SIZE) { j ->
                if (i + j < audio.size) audio[i + j] / 32768f else 0f
            }
            val prob = vadInfer(frame, h, c)
            if (prob > 0.5f) {
                voiced.addAll(frame.toList())
            }
        }

        // Fallback: DSP (energy + zero-crossing rate) if VAD unavailable
        return voiced.toFloatArray()
    }

    private fun vadInfer(frame: FloatArray, h: FloatArray, c: FloatArray): Float {
        val interpreter = vadInterpreter ?: return energyFallbackVad(frame)
        val inputBuf = ByteBuffer.allocateDirect(frame.size * 4).order(ByteOrder.nativeOrder())
        frame.forEach { inputBuf.putFloat(it) }
        inputBuf.rewind()
        val outputBuf = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
        interpreter.run(inputBuf, outputBuf)
        outputBuf.rewind()
        return outputBuf.float
    }

    private fun energyFallbackVad(frame: FloatArray): Float {
        // Energy-based fallback
        val energy = frame.sumOf { (it * it).toDouble() } / frame.size
        val zcr = frame.zipWithNext().count { (a, b) -> (a >= 0) != (b >= 0) }.toFloat() / frame.size
        return if (energy > 0.001 && zcr < 0.3f) 0.8f else 0.1f
    }

    private fun extractEmbedding(audio: FloatArray): FloatArray {
        val interpreter = ecapaInterpreter ?: return FloatArray(EMBEDDING_DIM)

        // Pad/truncate to exactly 6s
        val input = FloatArray(SAMPLE_RATE * VOICED_SECONDS)
        audio.copyInto(input, 0, 0, minOf(audio.size, input.size))

        val inputBuf = ByteBuffer.allocateDirect(input.size * 4).order(ByteOrder.nativeOrder())
        input.forEach { inputBuf.putFloat(it) }
        inputBuf.rewind()

        val outputBuf = ByteBuffer.allocateDirect(EMBEDDING_DIM * 4).order(ByteOrder.nativeOrder())
        interpreter.run(inputBuf, outputBuf)
        outputBuf.rewind()

        return FloatArray(EMBEDDING_DIM) { outputBuf.float }
    }

    // ── AS-Norm (Adaptive Score Normalization) ─────────────
    // Uses cohort.bin: 200 "impostor" vectors for normalization
    private fun asNorm(rawScore: Float, testEmb: FloatArray, enrollEmb: FloatArray): Float {
        // Compute cohort scores for test and enroll
        val testCohort = cohortVectors.map { cosineSimilarity(testEmb, it) }.sorted().takeLast(200)
        val enrollCohort = cohortVectors.map { cosineSimilarity(enrollEmb, it) }.sorted().takeLast(200)

        val testMean = testCohort.average().toFloat()
        val testStd  = testCohort.standardDeviation()
        val enrollMean = enrollCohort.average().toFloat()
        val enrollStd  = enrollCohort.standardDeviation()

        val normTest   = (rawScore - testMean) / (testStd + 1e-7f)
        val normEnroll = (rawScore - enrollMean) / (enrollStd + 1e-7f)

        return (normTest + normEnroll) / 2f
    }

    // ── Voice enrollment ───────────────────────────────────
    fun enroll(name: String, role: VoiceRole, audioBuffer: ShortArray): Boolean {
        val voiced = extractVoicedSegments(audioBuffer)
        if (voiced.size < SAMPLE_RATE * 3) return false  // need at least 3s

        val embedding = extractEmbedding(voiced)
        enrolledProfiles.add(VoiceAuthProfile(name, role, embedding))
        saveProfiles()
        return true
    }

    fun removeVoice(name: String) {
        enrolledProfiles.removeAll { it.name == name }
        saveProfiles()
    }

    fun listVoices(): List<VoiceAuthProfile> = enrolledProfiles.toList()

    fun identifySpeaker(audioBuffer: ShortArray): VoiceAuthProfile? {
        val voiced = extractVoicedSegments(audioBuffer)
        val embedding = extractEmbedding(voiced)
        return enrolledProfiles.maxByOrNull { cosineSimilarity(embedding, it.embedding) }
            ?.takeIf { cosineSimilarity(embedding, it.embedding) > EER_THRESHOLD }
    }

    private fun saveProfiles() {
        // Save to EncryptedSharedPreferences / profiles.json
        // Location: /data/data/com.getmaya.android/files/guardian/
    }

    // ── Math helpers ───────────────────────────────────────
    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f; var normA = 0f; var normB = 0f
        for (i in a.indices) { dot += a[i] * b[i]; normA += a[i] * a[i]; normB += b[i] * b[i] }
        return if (normA == 0f || normB == 0f) 0f else dot / (sqrt(normA) * sqrt(normB))
    }

    private fun List<Float>.standardDeviation(): Float {
        val mean = average().toFloat()
        return sqrt(map { (it - mean) * (it - mean) }.average().toFloat())
    }

    fun dispose() {
        ecapaInterpreter?.close()
        vadInterpreter?.close()
    }
}

// ── Data classes ──────────────────────────────────────────
/** Voice authentication profile — enrolled speaker record. */
data class VoiceAuthProfile(
    val name: String,
    val role: VoiceRole,        // from com.getmaya.android.data.models.VoiceRole
    val embedding: FloatArray
)

sealed class VerificationResult {
    data class ACCEPTED(val name: String, val role: VoiceRole, val score: Float) : VerificationResult()
    object REJECTED : VerificationResult()
    object INSUFFICIENT_SPEECH : VerificationResult()
}
