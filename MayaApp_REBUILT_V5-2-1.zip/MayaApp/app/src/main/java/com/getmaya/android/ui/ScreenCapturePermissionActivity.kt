package com.getmaya.android.ui

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.media.projection.MediaProjectionManager
import android.content.Context

class ScreenCapturePermissionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Request screen capture permission
        val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
        // Show permission dialog
    }
}
