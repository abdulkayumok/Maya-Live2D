package com.getmaya.android

import android.app.Application
import android.content.Intent
import androidx.work.*
import com.getmaya.android.core.MayaForegroundService
import com.getmaya.android.data.repository.SettingsRepository
import java.util.concurrent.TimeUnit

class MayaApplication : Application() {

    lateinit var settingsRepository: SettingsRepository

    override fun onCreate() {
        super.onCreate()
        instance = this
        settingsRepository = SettingsRepository(this)
        scheduleKeepAliveWorker()
    }

    private fun scheduleKeepAliveWorker() {
        val req = PeriodicWorkRequestBuilder<KeepAliveWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "maya_keepalive", ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    companion object {
        lateinit var instance: MayaApplication
            private set
    }
}

class KeepAliveWorker(ctx: android.content.Context, params: WorkerParameters)
    : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val intent = Intent(applicationContext, MayaForegroundService::class.java)
            .apply { action = "STANDBY" }
        try { applicationContext.startForegroundService(intent) } catch (_: Exception) {}
        return Result.success()
    }
}
