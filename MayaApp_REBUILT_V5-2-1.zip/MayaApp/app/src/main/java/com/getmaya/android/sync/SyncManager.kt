package com.getmaya.android.sync

import android.content.Context
import com.getmaya.android.core.MayaActions
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// SYNC MANAGER — PC ⇄ Phone (Maya Home)
//
// From APK strings:
// Hub:       sync.hunterislive.online
// Join:      https://sync.hunterislive.online/home/join
// WebSocket: wss://sync.hunterislive.online/home/ws
//
// Flow:
// 1. User installs Maya Home on PC
// 2. PC gets a Box ID
// 3. Phone: Settings → PC ⇄ Phone → Enter Box ID + password
// 4. WebSocket keeps both connected
// 5. Commands flow: PC → phone (relay) or phone → PC
//
// PC relay mode system prompt (from DEX verbatim):
// "Tum Maya ho, Boss ki personal AI (phone pe chal rahi ho).
//  Ye command Boss ke DOOSRE device (PC) se relay pe aayi hai."
// ═══════════════════════════════════════════════════════════

class SyncManager(private val context: Context) {

    private val BASE_HTTP = "https://sync.hunterislive.online/home"
    private val BASE_WS   = "wss://sync.hunterislive.online/home/ws"

    private val http = OkHttpClient()
    private var ws: WebSocket? = null
    private var boxId = ""
    private var password = ""
    private var isConnected = false
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Connect to Maya Home ───────────────────────────────
    fun connect(boxId: String, password: String, onMessage: (SyncMessage) -> Unit) {
        this.boxId = boxId
        this.password = password

        val req = Request.Builder()
            .url("$BASE_WS?box=$boxId&pass=$password")
            .build()

        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isConnected = true
                // Identify ourselves
                webSocket.send(JSONObject().apply {
                    put("type", "IDENTIFY")
                    put("device", "android")
                    put("box_id", boxId)
                }.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val type = json.optString("type")
                    val data = json.optString("data", "")

                    when (type) {
                        "COMMAND" -> {
                            // PC sent a command to phone
                            onMessage(SyncMessage.Command(data))
                            // Route to MayaForegroundService
                            context.sendBroadcast(
                                android.content.Intent(MayaActions.SEND_COMMAND).apply {
                                    putExtra("text", data)
                                    putExtra("source", "pc_relay")
                                }
                            )
                        }
                        "PING" -> webSocket.send(JSONObject().put("type", "PONG").toString())
                        "RESPONSE" -> onMessage(SyncMessage.Response(data))
                        "STATUS"   -> onMessage(SyncMessage.Status(data))
                    }
                } catch (_: Exception) {}
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                onMessage(SyncMessage.Error(t.message ?: "Connection failed"))
                // Retry after 5s
                scope.launch {
                    delay(5000)
                    connect(boxId, password, onMessage)
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
            }
        })
    }

    // ── Send response from phone back to PC ────────────────
    fun sendResponse(response: String) {
        ws?.send(JSONObject().apply {
            put("type", "RESPONSE")
            put("data", response)
            put("device", "android")
        }.toString())
    }

    // ── Send phone status to PC ────────────────────────────
    fun sendStatus(status: String) {
        ws?.send(JSONObject().apply {
            put("type", "STATUS")
            put("data", status)
        }.toString())
    }

    // ── Join a box (initial setup) ─────────────────────────
    suspend fun joinBox(boxId: String, password: String): JoinResult = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("box_id", boxId)
            put("password", password)
            put("device", "android")
        }
        return@withContext try {
            val resp = http.newCall(
                Request.Builder()
                    .url("$BASE_HTTP/join")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
            ).execute().use { JSONObject(it.body!!.string()) }

            if (resp.optBoolean("success")) JoinResult.Success(resp.optString("token"))
            else JoinResult.Failed(resp.optString("error", "Join failed"))
        } catch (e: Exception) {
            JoinResult.Failed(e.message ?: "Network error")
        }
    }

    fun disconnect() {
        ws?.close(1000, "Disconnected by user")
        ws = null
        isConnected = false
        scope.cancel()
    }

    fun isConnected() = isConnected
}

sealed class SyncMessage {
    data class Command(val text: String) : SyncMessage()
    data class Response(val text: String) : SyncMessage()
    data class Status(val text: String) : SyncMessage()
    data class Error(val message: String) : SyncMessage()
}

sealed class JoinResult {
    data class Success(val token: String) : JoinResult()
    data class Failed(val reason: String) : JoinResult()
}
