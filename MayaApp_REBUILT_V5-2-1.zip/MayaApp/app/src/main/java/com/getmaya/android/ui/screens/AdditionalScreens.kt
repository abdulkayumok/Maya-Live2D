package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WebsiteCodingScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("💻 Website / Coding", fontSize = 24.sp, fontWeight = FontWeight.Bold, 
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        Text("Web development और coding tutorials यहाँ आएंगे", 
            fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(0.7f))
    }
}

@Composable
fun StudyWhiteboardScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("📚 Study / Whiteboard", fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        Text("अध्ययन सामग्री और व्हाइटबोर्ड यहाँ उपलब्ध होगी",
            fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(0.7f))
    }
}

@Composable
fun MayaRulesScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("📋 Maya Rules", fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(5) { index ->
                RuleCard("Rule ${index + 1}", "यह Maya के लिए एक महत्वपूर्ण नियम है")
            }
        }
    }
}

@Composable
fun PCPhoneScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("🔗 PC ⇌ Phone", fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        Text("अपने पीसी और फोन को सिंक करें",
            fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(0.7f))
        
        Button(
            onClick = {},
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp)
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Text("Connect Device")
        }
    }
}

@Composable
fun PrivacyPolicyScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("🔐 Privacy Policy", fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        Text("Maya आपकी गोपनीयता की रक्षा करता है। हम आपके डेटा को कभी तीसरे पक्ष के साथ साझा नहीं करते।",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(0.8f))
    }
}

@Composable
fun AboutScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("ℹ️ About Maya", fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 24.dp))
        
        InfoCard("Version", "5.2.9")
        InfoCard("Developer", "Sir Abdul Kayum Ai")
        InfoCard("Package", "com.getmaya.android")
        InfoCard("SDK", "API Level 34")
    }
}

@Composable
fun RuleCard(title: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(description, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
        }
    }
}

@Composable
fun InfoCard(label: String, value: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}
