package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NotificationsScreen(navController: androidx.navigation.NavHostController) {
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }
    var callNotificationEnabled by remember { mutableStateOf(true) }
    var reminderNotificationEnabled by remember { mutableStateOf(true) }
    var updateNotificationEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "🔔 Notifications",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        SettingsSection("Alert Settings") {
            NotificationToggle("Sound", soundEnabled) { soundEnabled = it }
            NotificationToggle("Vibration", vibrationEnabled) { vibrationEnabled = it }
        }

        SettingsSection("Notification Types") {
            NotificationToggle("📞 Call Notifications", callNotificationEnabled) { 
                callNotificationEnabled = it 
            }
            NotificationToggle("⏰ Reminder Notifications", reminderNotificationEnabled) { 
                reminderNotificationEnabled = it 
            }
            NotificationToggle("📦 Update Notifications", updateNotificationEnabled) { 
                updateNotificationEnabled = it 
            }
        }

        SettingsSection("Recent Notifications") {
            repeat(3) { index ->
                NotificationCard(
                    title = "Notification ${index + 1}",
                    time = "Today ${10 + index}:${30 * index}",
                    message = "You have a new notification"
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Save", fontSize = 14.sp)
        }
    }
}

@Composable
fun DeviceManagementScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "📱 Linked Devices",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Current Device
        DeviceCard(
            deviceName = "My Phone",
            deviceType = "Android 14",
            lastSync = "Just now",
            isPrimary = true
        )

        Text(
            "Paired Devices",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
            modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)
        )

        // Other devices
        repeat(2) { index ->
            DeviceCard(
                deviceName = "Device ${index + 1}",
                deviceType = "Last active 2 days ago",
                lastSync = "Oct ${6 - index}, 2026"
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Add New Device", fontSize = 14.sp)
        }
    }
}

@Composable
fun NotificationToggle(label: String, enabled: Boolean, onToggle: (Boolean) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 13.sp)
            Switch(checked = enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
fun NotificationCard(title: String, time: String, message: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(time, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
            }
            Text(message, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun DeviceCard(deviceName: String, deviceType: String, lastSync: String, isPrimary: Boolean = false) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPrimary) 
                MaterialTheme.colorScheme.primaryContainer 
            else 
                MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        deviceName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        deviceType,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (isPrimary) {
                    Text("⭐", fontSize = 20.sp)
                }
            }
            Text(
                "Last sync: $lastSync",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
