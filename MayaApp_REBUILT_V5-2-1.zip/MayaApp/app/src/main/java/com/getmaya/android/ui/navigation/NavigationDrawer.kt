package com.getmaya.android.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun NavigationDrawer(navController: NavHostController, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "🎤 MAYA",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Text(
                "by Sir Abdul Kayum Ai",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimary.copy(0.8f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // HOME Section
        NavSection(title = "HOME") {
            NavDrawerItem("🏠 Home", NavScreens.HOME, navController)
            NavDrawerItem("🎤 Maya Home", NavScreens.MAYA_HOME, navController)
            NavDrawerItem("🧠 Memories", NavScreens.MEMORIES, navController)
        }

        // PRODUCTIVITY Section
        NavSection(title = "PRODUCTIVITY") {
            NavDrawerItem("💻 Website / Coding", NavScreens.WEBSITE_CODING, navController)
            NavDrawerItem("📚 Study / Whiteboard", NavScreens.STUDY, navController)
        }

        // SYSTEM Section
        NavSection(title = "SYSTEM") {
            NavDrawerItem("⚙️ Settings", NavScreens.SETTINGS, navController)
            NavDrawerItem("📋 Maya Rules", NavScreens.MAYA_RULES, navController)
            NavDrawerItem("🔗 PC ⇌ Phone", NavScreens.PC_PHONE, navController)
        }

        // OTHER Section
        NavSection(title = "OTHER") {
            NavDrawerItem("🔐 Privacy Policy", NavScreens.PRIVACY, navController)
            NavDrawerItem("ℹ️ About", NavScreens.ABOUT, navController)
            NavDrawerItem("🚀 Upgrade", "upgrade", navController)
            NavDrawerItem("🔔 Notifications", "notifications", navController)
        }

        Spacer(modifier = Modifier.weight(1f))

        // Footer
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "v5.2.10",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
            )
            Text(
                "Sir Abdul Kayum Ai",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun NavSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)) {
        Text(
            title,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
            modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
        )
        content()
    }
}

@Composable
fun NavDrawerItem(label: String, route: String, navController: NavHostController) {
    Text(
        label,
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { navController.navigate(route) }
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp)
            )
            .padding(12.dp)
    )
}
