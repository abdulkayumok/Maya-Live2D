package com.getmaya.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ═══════════════════════════════════════════════════════════
// REUSABLE UI COMPONENTS — Maya Design System
// ═══════════════════════════════════════════════════════════

// ── Maya Button ───────────────────────────────────────────
@Composable
fun MayaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    secondary: Boolean = false,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (secondary) Color(0xFF1A2540) else Color(0xFF4477FF),
            contentColor = Color.White,
            disabledContainerColor = Color(0xFF1A2540),
            disabledContentColor = Color(0xFF445566)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(text, fontWeight = FontWeight.Medium)
    }
}

// ── Status Chip ───────────────────────────────────────────
@Composable
fun StatusChip(label: String, color: Color = Color(0xFF4477FF)) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

// ── Maya Card ─────────────────────────────────────────────
@Composable
fun MayaCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(Color(0xFF0F1A2E))
    Column(
        modifier = if (onClick != null) base.then(modifier).clickable(onClick = onClick)
                   else base.then(modifier),
        content = content
    )
}

// ── Loading Indicator ────────────────────────────────────
@Composable
fun MayaLoader(message: String = "Maya soch rahi hai...") {
    Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(
            color = Color(0xFF4477FF),
            strokeWidth = 2.dp,
            modifier = Modifier.size(32.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(message, color = Color(0xFF556677), fontSize = 13.sp)
    }
}

// ── Avatar Bubble ─────────────────────────────────────────
@Composable
fun AvatarBubble(
    character: String = "M",
    size: Int = 40,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0xFF1A2540))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = character.first().uppercaseChar().toString(),
            color = Color(0xFF4A90D9),
            fontSize = (size * 0.4f).sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ── Divider ───────────────────────────────────────────────
@Composable
fun MayaDivider() {
    HorizontalDivider(
        color = Color(0xFF1A2540),
        thickness = 0.5.dp,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

// ── Section Label ─────────────────────────────────────────
@Composable
fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        color = Color(0xFF445566),
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 6.dp)
    )
}

// ── Empty State ───────────────────────────────────────────
@Composable
fun EmptyState(icon: String, message: String, sub: String = "") {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 40.sp)
        Spacer(Modifier.height(12.dp))
        Text(message, color = Color(0xFF8899AA), fontSize = 15.sp,
            fontWeight = FontWeight.Medium)
        if (sub.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(sub, color = Color(0xFF556677), fontSize = 13.sp)
        }
    }
}

// ── Toast-style Snackbar state ────────────────────────────
@Composable
fun rememberMayaSnackbar(): SnackbarHostState = remember { SnackbarHostState() }

// ── Character Badge (Pro Max) ─────────────────────────────
@Composable
fun ProMaxBadge() {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1A1A3E))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text("✦ PRO", color = Color(0xFF818CF8), fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold)
    }
}
