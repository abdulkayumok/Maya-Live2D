package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NotificationsScreen(navController: androidx.navigation.NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "🔔 Notifications",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Text(
                "Manage app notifications and alerts",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimary.copy(0.8f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(8) { index ->
                NotificationCard(
                    app = when (index) {
                        0 -> "Messages"
                        1 -> "Calls"
                        2 -> "Reminders"
                        3 -> "Alarms"
                        4 -> "Mail"
                        5 -> "Calendar"
                        6 -> "Weather"
                        else -> "System Updates"
                    },
                    icon = when (index) {
                        0 -> "💬"
                        1 -> "☎️"
                        2 -> "⏰"
                        3 -> "⏲️"
                        4 -> "📧"
                        5 -> "📅"
                        6 -> "🌤️"
                        else -> "🔧"
                    },
                    enabled = true,
                    count = when (index) {
                        0 -> "5 new"
                        1 -> "1 missed"
                        2 -> "3 upcoming"
                        3 -> "Active"
                        4 -> "10 new"
                        5 -> "2 events"
                        6 -> "Updated"
                        else -> "Available"
                    }
                )
            }
        }
    }
}

@Composable
fun NotificationCard(app: String, icon: String, enabled: Boolean, count: String) {
    var isEnabled by remember { mutableStateOf(enabled) }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(icon, fontSize = 20.sp)
                }

                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(app, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        count,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                    )
                }
            }

            Switch(
                checked = isEnabled,
                onCheckedChange = { isEnabled = it }
            )
        }
    }
}
