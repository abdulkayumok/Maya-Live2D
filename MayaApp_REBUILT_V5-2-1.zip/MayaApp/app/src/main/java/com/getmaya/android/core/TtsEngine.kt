package com.getmaya.android.core

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.getmaya.android.data.models.PersonaId
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.*
import kotlin.coroutines.resume

// ═══════════════════════════════════════════════════════════
// TTS ENGINE — Google TTS (on-device) + Google Cloud TTS
//
// From APK:
// - texttospeech.googleapis.com/v1/text:synthesize
// - Emotive mode: ~5s vs 2.4s normal
// - Persona voices: Maya / Venom (doubled symbiote layer)
//                   Friday / Jarvis
// - Earpiece mode support
// - Media stream mode
// ═══════════════════════════════════════════════════════════

class TtsEngine(private val context: Context) {

    private var androidTts: TextToSpeech? = null
    private var ttsReady = false
    private var currentPersona = PersonaId.MAYA
    private var emotiveMode = false
    private var earpieceMode = false

    private val http = OkHttpClient()

    fun initialize(onReady: () -> Unit) {
        androidTts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                configureVoice()
                onReady()
            }
        }
    }

    private fun configureVoice() {
        androidTts?.language = Locale("hi", "IN")  // Hindi-Indian
        androidTts?.setSpeechRate(if (emotiveMode) 0.85f else 1.0f)
        androidTts?.setPitch(getPersonaPitch())
        configureAudioStream()
    }

    private fun getPersonaPitch(): Float = when (currentPersona) {
        PersonaId.MAYA   -> 1.1f   // Slightly high — female
        PersonaId.VENOM  -> 0.6f   // Deep — symbiote
        PersonaId.FRIDAY -> 1.0f   // Neutral
        PersonaId.JARVIS -> 0.9f   // Slightly low — formal
    }

    private fun configureAudioStream() {
        val streamType = if (earpieceMode) AudioManager.STREAM_VOICE_CALL
                         else AudioManager.STREAM_MUSIC
        val attrs = AudioAttributes.Builder()
            .setUsage(if (earpieceMode) AudioAttributes.USAGE_VOICE_COMMUNICATION
                      else AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        androidTts?.setAudioAttributes(attrs)
    }

    // ── Speak ──────────────────────────────────────────────
    suspend fun speak(text: String): Boolean = suspendCancellableCoroutine { cont ->
        if (!ttsReady || androidTts == null) { cont.resume(false); return@suspendCancellableCoroutine }

        val uttId = UUID.randomUUID().toString()
        androidTts!!.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (uttId == utteranceId) cont.resume(true) }
            override fun onError(utteranceId: String?) { if (uttId == utteranceId) cont.resume(false) }
        })

        // Venom: speak then add symbiote effect (doubled bass layer)
        val finalText = when (currentPersona) {
            PersonaId.VENOM -> applyVenomEffect(text)
            else -> text
        }

        androidTts!!.speak(finalText, TextToSpeech.QUEUE_FLUSH, null, uttId)
    }

    // Venom symbiote effect — lower pitch version layered
    private fun applyVenomEffect(text: String): String {
        // In full implementation: play two TTS instances simultaneously
        // one at pitch 0.6 (main), one at 0.4 (doubled symbiote layer)
        // For now: just use deep pitch (set in getPersonaPitch)
        return text
    }

    // ── Google Cloud TTS (higher quality, emotive) ─────────
    suspend fun speakCloud(text: String, apiKey: String): Boolean {
        // Emotive mode: use Neural2 voice with SSML stress markers
        val ssml = if (emotiveMode) wrapEmotive(text) else "<speak>$text</speak>"
        val voiceName = when (currentPersona) {
            PersonaId.MAYA   -> "hi-IN-Neural2-A"   // Hindi female
            PersonaId.VENOM  -> "en-US-Neural2-D"   // Deep male
            PersonaId.FRIDAY -> "en-US-Neural2-J"   // Neutral female
            PersonaId.JARVIS -> "en-GB-Neural2-B"   // British male
        }

        val body = JSONObject().apply {
            put("input", JSONObject().put("ssml", ssml))
            put("voice", JSONObject().apply {
                put("languageCode", if (currentPersona == PersonaId.MAYA) "hi-IN" else "en-US")
                put("name", voiceName)
            })
            put("audioConfig", JSONObject().apply {
                put("audioEncoding", "MP3")
                put("speakingRate", if (emotiveMode) 0.85 else 1.0)
                put("pitch", when (currentPersona) {
                    PersonaId.VENOM  -> -8.0
                    PersonaId.MAYA   -> 2.0
                    PersonaId.JARVIS -> -2.0
                    else             -> 0.0
                })
            })
        }

        return try {
            val req = Request.Builder()
                .url("https://texttospeech.googleapis.com/v1/text:synthesize?key=$apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use false
                val audioContent = JSONObject(resp.body!!.string()).getString("audioContent")
                // Decode base64 MP3 and play via MediaPlayer
                playMp3Base64(audioContent)
                true
            }
        } catch (e: Exception) {
            speak(text)  // fallback to on-device
        }
    }

    private fun wrapEmotive(text: String): String {
        // Add SSML emotion markers for emotive mode (~5s instead of 2.4s)
        return """<speak>
            <prosody rate="slow" pitch="+2st">$text</prosody>
        </speak>"""
    }

    private fun playMp3Base64(base64: String) {
        val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
        val tmpFile = java.io.File(context.cacheDir, "maya_tts_${System.currentTimeMillis()}.mp3")
        tmpFile.writeBytes(bytes)
        android.media.MediaPlayer().apply {
            setDataSource(tmpFile.absolutePath)
            prepare()
            start()
            setOnCompletionListener {
                it.release()
                tmpFile.delete()
            }
        }
    }

    // ── Configuration ──────────────────────────────────────
    fun setPersona(persona: PersonaId) {
        currentPersona = persona
        configureVoice()
    }

    fun setEmotiveMode(enabled: Boolean) {
        emotiveMode = enabled
        androidTts?.setSpeechRate(if (enabled) 0.85f else 1.0f)
    }

    fun setEarpieceMode(enabled: Boolean) {
        earpieceMode = enabled
        configureAudioStream()
    }

    fun stop() { androidTts?.stop() }

    fun dispose() {
        androidTts?.shutdown()
        androidTts = null
    }
}
