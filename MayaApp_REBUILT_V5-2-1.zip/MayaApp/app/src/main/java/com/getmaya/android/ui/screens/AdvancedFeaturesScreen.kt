package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BarcodeScannerScreen(navController: androidx.navigation.NavHostController) {
    var scanResult by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            "📱 Barcode Scanner",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(
                    color = MaterialTheme.colorScheme.surface,
                    shape = MaterialTheme.shapes.large
                ),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            if (isScanning) {
                CircularProgressIndicator()
            } else {
                Text("📷", fontSize = 60.sp)
            }
        }

        Button(
            onClick = { isScanning = !isScanning },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp)
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(if (isScanning) "Scanning..." else "Start Scan", fontSize = 14.sp)
        }

        if (scanResult.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Scan Result", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(scanResult, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Done", fontSize = 14.sp)
        }
    }
}

@Composable
fun AdvancedVoiceSettingsScreen(navController: androidx.navigation.NavHostController) {
    var enableWakeWord by remember { mutableStateOf(true) }
    var enableVAD by remember { mutableStateOf(true) }
    var enableNoiseFilter by remember { mutableStateOf(true) }
    var enableEchoCancellation by remember { mutableStateOf(true) }
    var noiseThreshold by remember { mutableStateOf(50f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "🎤 Advanced Voice Settings",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        SettingsSection("Wake Word Detection") {
            AdvancedToggleSetting(
                icon = "🎙️",
                title = "Enable Wake Word",
                description = "Listen for 'Hey Maya' command",
                enabled = enableWakeWord
            ) { enableWakeWord = it }

            Text(
                "Wake Words: Hey Maya, Hello Maya, Wake up Maya",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
                modifier = Modifier.padding(12.dp)
            )
        }

        SettingsSection("Voice Processing") {
            AdvancedToggleSetting(
                icon = "🔊",
                title = "Voice Activity Detection",
                description = "Auto-detect when you speak",
                enabled = enableVAD
            ) { enableVAD = it }

            AdvancedToggleSetting(
                icon = "🔇",
                title = "Noise Filter",
                description = "Remove background noise",
                enabled = enableNoiseFilter
            ) { enableNoiseFilter = it }

            AdvancedToggleSetting(
                icon = "📢",
                title = "Echo Cancellation",
                description = "Remove audio feedback",
                enabled = enableEchoCancellation
            ) { enableEchoCancellation = it }

            SliderSetting(
                "Noise Threshold",
                noiseThreshold,
                0f..100f
            ) { noiseThreshold = it }
        }

        SettingsSection("Performance") {
            PerformanceItem("Wake Word Accuracy", "98%")
            PerformanceItem("VAD Response Time", "50ms")
            PerformanceItem("Processing Latency", "120ms")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Save Settings", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AdvancedToggleSetting(
    icon: String,
    title: String,
    description: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f)) {
                Text(icon, fontSize = 20.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Switch(checked = enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
fun PerformanceItem(label: String, value: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 13.sp)
            Text(
                value,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
