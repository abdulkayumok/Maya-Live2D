package com.getmaya.android.assistant

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.getmaya.android.core.MayaActions
import com.getmaya.android.core.SttEngine

// ═══════════════════════════════════════════════════════════
// VOICE SERVICES — replaces Google Assistant as system voice AI
//
// 3 services work together:
// 1. MayaVoiceInteractionService — registers Maya as system assistant
// 2. MayaVoiceInteractionSessionService — handles the session
// 3. MayaRecognitionService — provides speech recognition
// 4. MayaAssistActivity — handles ASSIST intent (long-press home)
// ═══════════════════════════════════════════════════════════

// ── 1. VOICE INTERACTION SERVICE ──────────────────────────
// Set as default voice interaction service to replace Google Assistant
class MayaVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        // Maya is now the system voice assistant
        // Long-press home button → triggers Maya
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}

// ── 2. VOICE INTERACTION SESSION SERVICE ──────────────────
class MayaVoiceInteractionSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return MayaVoiceSession(this)
    }
}

class MayaVoiceSession(context: android.content.Context)
    : VoiceInteractionSession(context) {

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        // Triggered when user activates voice assistant
        // Send ASSIST_WAKE to MayaForegroundService
        context.sendBroadcast(Intent(MayaActions.ASSIST_WAKE))
    }

    override fun onHide() {
        super.onHide()
        finish()
    }
}

// ── 3. RECOGNITION SERVICE ────────────────────────────────
// Maya provides her own speech recognition to system
// Routes through Deepgram (if key available) or Google STT
class MayaRecognitionService : RecognitionService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeSttEngine: SttEngine? = null
    private var activeRecognizer: SpeechRecognizer? = null
    private var pendingRecognizerIntent: Intent? = null

    override fun onStartListening(recognizerIntent: Intent, listener: Callback) {
        pendingRecognizerIntent = Intent(recognizerIntent)
        // Check if Deepgram key available → use Deepgram WebSocket
        // Otherwise → use Android SpeechRecognizer (Google)
        val useDeepgram = !getDeepgramKey().isNullOrEmpty()

        if (useDeepgram) {
            startDeepgramRecognition(listener)
        } else {
            startAndroidRecognition(recognizerIntent, listener)
        }
    }

    private fun startDeepgramRecognition(listener: Callback) {
        val key = getDeepgramKey()
        if (key.isNullOrBlank()) {
            listener.error(SpeechRecognizer.ERROR_CLIENT)
            return
        }

        activeSttEngine?.stopStreaming()
        val engine = SttEngine(this)
        activeSttEngine = engine
        listener.readyForSpeech(Bundle())
        listener.beginningOfSpeech()

        engine.startStreaming(
            deepgramApiKey = key,
            onInterim = { transcript ->
                mainHandler.post {
                    if (activeSttEngine === engine && transcript.isNotBlank()) {
                        listener.partialResults(Bundle().apply {
                            putStringArrayList(
                                SpeechRecognizer.RESULTS_RECOGNITION,
                                arrayListOf(transcript)
                            )
                        })
                    }
                }
            },
            onFinal = { transcript ->
                mainHandler.post {
                    if (activeSttEngine === engine && transcript.isNotBlank()) {
                        listener.results(Bundle().apply {
                            putStringArrayList(
                                SpeechRecognizer.RESULTS_RECOGNITION,
                                arrayListOf(transcript)
                            )
                        })
                        listener.endOfSpeech()
                        engine.stopStreaming()
                        activeSttEngine = null
                    }
                }
            },
            onError = {
                mainHandler.post {
                    if (activeSttEngine === engine) {
                        engine.stopStreaming()
                        activeSttEngine = null
                        val fallbackIntent = pendingRecognizerIntent
                        if (fallbackIntent != null) {
                            startAndroidRecognition(fallbackIntent, listener)
                        } else {
                            listener.error(SpeechRecognizer.ERROR_NETWORK)
                        }
                    }
                }
            }
        )
    }

    private fun startAndroidRecognition(intent: Intent, listener: Callback) {
        activeRecognizer?.destroy()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        activeRecognizer = recognizer
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listener.readyForSpeech(params ?: Bundle()) }
            override fun onBeginningOfSpeech() { listener.beginningOfSpeech() }
            override fun onRmsChanged(rmsdB: Float) { listener.rmsChanged(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) { listener.bufferReceived(buffer) }
            override fun onEndOfSpeech() { listener.endOfSpeech() }
            override fun onError(error: Int) {
                listener.error(error)
                if (activeRecognizer === recognizer) {
                    recognizer.destroy()
                    activeRecognizer = null
                }
            }
            override fun onResults(results: Bundle?) {
                listener.results(results ?: Bundle())
                if (activeRecognizer === recognizer) {
                    recognizer.destroy()
                    activeRecognizer = null
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                listener.partialResults(partialResults ?: Bundle())
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    override fun onStopListening(listener: Callback) {
        val engine = activeSttEngine
        if (engine != null) {
            engine.stopStreaming()
            activeSttEngine = null
            listener.endOfSpeech()
        } else {
            activeRecognizer?.stopListening()
        }
    }

    override fun onCancel(listener: Callback) {
        activeSttEngine?.stopStreaming()
        activeSttEngine = null
        activeRecognizer?.cancel()
        activeRecognizer?.destroy()
        activeRecognizer = null
    }

    override fun onDestroy() {
        activeSttEngine?.stopStreaming()
        activeSttEngine = null
        activeRecognizer?.destroy()
        activeRecognizer = null
        pendingRecognizerIntent = null
        super.onDestroy()
    }

    private fun getDeepgramKey(): String? {
        return try {
            com.getmaya.android.MayaApplication.instance
                .settingsRepository.getApiKey("deepgram")
                .ifEmpty { null }
        } catch (_: Exception) { null }
    }
}

// ── 4. ASSIST ACTIVITY ────────────────────────────────────
// Handles android.intent.action.ASSIST (long-press home)
class MayaAssistActivity : android.app.Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Transparent activity — just triggers Maya
        sendBroadcast(Intent(MayaActions.ASSIST_WAKE))

        // Start Maya's foreground service in LIVE mode
        startForegroundService(
            Intent(this, com.getmaya.android.core.MayaForegroundService::class.java)
                .apply { action = "START" }
        )
        finish()
    }
}
