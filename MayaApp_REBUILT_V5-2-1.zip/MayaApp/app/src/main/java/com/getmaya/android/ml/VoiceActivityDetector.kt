package com.getmaya.android.ml

import org.tensorflow.lite.Interpreter

class VoiceActivityDetector(private val interpreter: Interpreter) {
    
    fun detectVoiceActivity(audioData: FloatArray): Float {
        val input = arrayOf(audioData)
        val output = arrayOf(FloatArray(1))
        interpreter.runForMultipleInputsOutputs(input, output)
        
        return output[0][0]
    }
    
    fun close() {
        interpreter.close()
    }
}
