package com.getmaya.android.marketing

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Receives alarm-manager triggers from [MarketingEngine] and starts
 * the appropriate marketing analysis task in the background.
 *
 * Extracted from APK DEX:
 *   Field a: Int  (alarm counter / request-code tracker)
 *   onReceive(Context, Intent)
 *
 * DEX actions:
 *   com.getmaya.android.marketing.DAILY_TRENDS
 *   com.getmaya.android.marketing.WEEKLY_NUMBERS
 *   com.getmaya.android.marketing.FOLLOWUPS_DUE
 *   com.getmaya.android.marketing.CALENDAR_DUE
 *
 * DEX SharedPreferences keys (prefs: "maya_marketing"):
 *   "trends_daily"          — daily trend content
 *   "trends_last_day"       — last day trends ran
 *   "weekly_summary"        — weekly numbers summary
 *   "followups_announced_at"— timestamp of last followup
 *   "calendar_upcoming"     — serialized upcoming calendar entries
 */
class MarketingAlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val PREFS           = "maya_marketing"
        const val ACTION_DAILY_TRENDS     = "com.getmaya.android.marketing.DAILY_TRENDS"
        const val ACTION_WEEKLY_NUMBERS   = "com.getmaya.android.marketing.WEEKLY_NUMBERS"
        const val ACTION_FOLLOWUPS_DUE    = "com.getmaya.android.marketing.FOLLOWUPS_DUE"
        const val ACTION_CALENDAR_DUE     = "com.getmaya.android.marketing.CALENDAR_DUE"

        private var a: Int = 0   // request-code counter, preserved from DEX field
    }

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        a++
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_DAILY_TRENDS   -> handleDailyTrends(context, prefs)
            ACTION_WEEKLY_NUMBERS -> handleWeeklyNumbers(context, prefs)
            ACTION_FOLLOWUPS_DUE  -> handleFollowUps(context, prefs)
            ACTION_CALENDAR_DUE   -> handleCalendarDue(context, prefs)
        }
    }

    private fun handleDailyTrends(ctx: Context, prefs: SharedPreferences) {
        scope.launch {
            val lastDay = prefs.getString("trends_last_day", "") ?: ""
            val today   = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                .format(java.util.Date())
            if (lastDay == today) return@launch
            prefs.edit().putString("trends_last_day", today).apply()
            // MarketingEngine handles actual trend fetch + AI generation
            ctx.sendBroadcast(
                Intent("com.getmaya.android.marketing.TRENDS_READY")
                    .setPackage(ctx.packageName)
            )
        }
    }

    private fun handleWeeklyNumbers(ctx: Context, prefs: SharedPreferences) {
        scope.launch {
            ctx.sendBroadcast(
                Intent("com.getmaya.android.marketing.WEEKLY_READY")
                    .setPackage(ctx.packageName)
            )
        }
    }

    private fun handleFollowUps(ctx: Context, prefs: SharedPreferences) {
        scope.launch {
            val now = System.currentTimeMillis().toString()
            prefs.edit().putString("followups_announced_at", now).apply()
            ctx.sendBroadcast(
                Intent("com.getmaya.android.marketing.FOLLOWUPS_READY")
                    .setPackage(ctx.packageName)
            )
        }
    }

    private fun handleCalendarDue(ctx: Context, prefs: SharedPreferences) {
        scope.launch {
            ctx.sendBroadcast(
                Intent("com.getmaya.android.marketing.CALENDAR_READY")
                    .setPackage(ctx.packageName)
            )
        }
    }
}
