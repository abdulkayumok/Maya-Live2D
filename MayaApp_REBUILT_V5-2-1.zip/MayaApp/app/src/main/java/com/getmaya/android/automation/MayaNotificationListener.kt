package com.getmaya.android.automation

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle
import com.getmaya.android.tools.handlers.WhatsAppTools

// ═══════════════════════════════════════════════════════════
// MAYA NOTIFICATION LISTENER — rebuilt from APK analysis
//
// APK: 10 methods including onListenerConnected + full parsing
// ZIP was: 2 empty methods
//
// Restores:
// ✅ read_notifications tool
// ✅ WhatsApp message parsing (sender, body extraction)
// ✅ Incoming call announcement (driving mode)
// ✅ Notification filtering (by package / priority)
// ✅ Auto-reply trigger → WhatsAppTools
// ✅ Commentary mode forwarding
// ═══════════════════════════════════════════════════════════

class MayaNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile var instance: MayaNotificationListener? = null
        @Volatile var commentaryMode = false

        // Exposed to PhoneTools for reject + SMS
        @Volatile var lastCallerNumber: String? = null
        @Volatile var lastCallerName: String?   = null
    }

    // Packages we actively parse
    private val WATCHED_PACKAGES = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.android.dialer",
        "com.google.android.dialer",
        "com.samsung.android.incallui",
        "com.facebook.orca",     // Messenger
        "org.telegram.messenger",
        "com.google.android.apps.messaging" // SMS
    )

    private val recentNotifications = ArrayDeque<ParsedNotification>(50)

    override fun onListenerConnected() {
        instance = this
        sendBroadcast(Intent("com.getmaya.android.NOTIFICATION_LISTENER_CONNECTED"))
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    // ═══════════════════════════════════════════════════════
    // NOTIFICATION POSTED
    // ═══════════════════════════════════════════════════════
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return
        if (pkg !in WATCHED_PACKAGES) return

        val extras = sbn.notification?.extras ?: return
        val title  = extras.getCharSequence("android.title")?.toString() ?: ""
        val text   = extras.getCharSequence("android.text")?.toString()  ?: ""
        val bigText = extras.getCharSequence("android.bigText")?.toString() ?: text

        val parsed = ParsedNotification(
            pkg     = pkg,
            title   = title,
            text    = bigText.ifEmpty { text },
            time    = sbn.postTime,
            key     = sbn.key
        )
        recentNotifications.addFirst(parsed)
        if (recentNotifications.size > 50) recentNotifications.removeLast()

        // ── WhatsApp handling ──────────────────────────────
        if (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") {
            handleWhatsApp(parsed)
        }

        // ── Call announce (driving / commentary mode) ──────
        if (isCallPackage(pkg) && (isDrivingMode() || commentaryMode)) {
            handleCallNotification(parsed)
        }

        // ── Commentary mode: speak all ─────────────────────
        if (commentaryMode) {
            val speak = when {
                title.isNotEmpty() && text.isNotEmpty() -> "$title: $text"
                title.isNotEmpty() -> title
                else -> text
            }
            if (speak.isNotEmpty()) {
                sendBroadcast(Intent("com.getmaya.android.SPEAK").apply {
                    putExtra("text", speak)
                })
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    // WHATSAPP PARSER
    // ═══════════════════════════════════════════════════════
    private fun handleWhatsApp(n: ParsedNotification) {
        // title = "Sender Name" or "Group > Sender"
        // text  = message body
        val sender  = n.title
        val body    = n.text

        // Store for read_notifications tool
        sendBroadcast(Intent("com.getmaya.android.WA_MESSAGE").apply {
            putExtra("sender", sender)
            putExtra("body", body)
            putExtra("time", n.time)
        })

        // Check auto-reply
        val autoReplyOn = com.getmaya.android.tools.handlers.WhatsAppTools.autoReplyEnabled
        if (autoReplyOn && !isGroupMessage(n)) {
            // Resolve sender → phone number via contacts
            val number = resolveWhatsAppNumber(sender)
            if (number != null) {
                val replyMsg = WhatsAppTools.autoReplyMessage
                sendBroadcast(Intent("com.getmaya.android.WA_AUTO_REPLY").apply {
                    putExtra("number", number)
                    putExtra("sender", sender)
                    putExtra("message", replyMsg)
                })
            }
        }
    }

    private fun isGroupMessage(n: ParsedNotification): Boolean {
        // Group messages have "Group Name > Sender Name" format or contain •
        return n.title.contains(">") || n.title.contains("•")
    }

    private fun resolveWhatsAppNumber(displayName: String): String? {
        // Query contacts by display name
        val cursor = contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} = ?",
            arrayOf(displayName), null
        )
        return cursor?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }

    // ═══════════════════════════════════════════════════════
    // CALL NOTIFICATION PARSER
    // ═══════════════════════════════════════════════════════
    private fun handleCallNotification(n: ParsedNotification) {
        // Incoming call title is usually the caller's name or number
        val isIncoming = n.text.contains("Incoming", ignoreCase = true)
            || n.title.contains("Incoming", ignoreCase = true)
            || n.text.contains("is calling", ignoreCase = true)

        if (isIncoming) {
            val callerName = n.title.let {
                if (it.contains("Incoming")) n.text else it
            }
            lastCallerName   = callerName
            lastCallerNumber = resolveWhatsAppNumber(callerName)

            val announce = "Incoming call from $callerName"
            sendBroadcast(Intent("com.getmaya.android.SPEAK").apply {
                putExtra("text", announce)
            })
        }
    }

    // ═══════════════════════════════════════════════════════
    // NOTIFICATION REMOVED
    // ═══════════════════════════════════════════════════════
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        recentNotifications.removeAll { it.key == sbn.key }
    }

    // ═══════════════════════════════════════════════════════
    // READ NOTIFICATIONS TOOL
    // ═══════════════════════════════════════════════════════
    fun getRecentNotifications(pkg: String? = null, limit: Int = 10): List<ParsedNotification> {
        return recentNotifications
            .filter { pkg == null || it.pkg == pkg }
            .take(limit)
    }

    fun getActiveNotifications(pkg: String? = null): List<ParsedNotification> {
        return try {
            activeNotifications
                ?.filter { pkg == null || it.packageName == pkg }
                ?.take(20)
                ?.map { sbn ->
                    val extras = sbn.notification?.extras ?: Bundle()
                    ParsedNotification(
                        pkg   = sbn.packageName,
                        title = extras.getCharSequence("android.title")?.toString() ?: "",
                        text  = extras.getCharSequence("android.text")?.toString()  ?: "",
                        time  = sbn.postTime,
                        key   = sbn.key
                    )
                } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    // ── Helpers ────────────────────────────────────────────
    private fun isCallPackage(pkg: String) =
        "dialer" in pkg || "incall" in pkg || "call" in pkg

    private fun isDrivingMode(): Boolean {
        val prefs = getSharedPreferences("maya_settings_secure", MODE_PRIVATE)
        return prefs.getBoolean("maya_driving_mode", false)
    }
}

// ── Data class ─────────────────────────────────────────────
data class ParsedNotification(
    val pkg: String,
    val title: String,
    val text: String,
    val time: Long,
    val key: String
)
