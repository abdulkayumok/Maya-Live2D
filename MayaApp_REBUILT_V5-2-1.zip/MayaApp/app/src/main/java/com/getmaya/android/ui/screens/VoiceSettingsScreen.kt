package com.getmaya.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.getmaya.android.voice.CharacterVoices
import com.getmaya.android.voice.VoiceSettings
import com.getmaya.android.voice.VoiceSettingsRepository

@Composable
fun VoiceSettingsScreen(repository: VoiceSettingsRepository) {
    val voiceSettingsFlow = repository.voiceSettings.collectAsState(
        initial = VoiceSettings("Maya", "Normal", 1.0f, 1.0f, 1.0f, "English")
    )
    val settings = voiceSettingsFlow.value

    var selectedCharacter by remember { mutableStateOf(settings.character) }
    var selectedMode by remember { mutableStateOf(settings.mode) }
    var voiceSpeed by remember { mutableStateOf(settings.speed) }
    var voicePitch by remember { mutableStateOf(settings.pitch) }
    var voiceVolume by remember { mutableStateOf(settings.volume) }
    var selectedLanguage by remember { mutableStateOf(settings.language) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("🎤 VOICE SETTINGS", style = MaterialTheme.typography.headlineMedium)
        Divider(modifier = Modifier.padding(vertical = 16.dp))

        // Character Selection
        Text("👤 SELECT CHARACTER", style = MaterialTheme.typography.labelLarge)
        CharacterDropdown(
            selectedCharacter = selectedCharacter,
            onCharacterSelected = { selectedCharacter = it }
        )

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        // Voice Mode Selection (only if Maya selected)
        if (selectedCharacter == "Maya") {
            Text("🎭 VOICE MODE", style = MaterialTheme.typography.labelLarge)
            VoiceModeSelector(
                selectedMode = selectedMode,
                onModeSelected = { selectedMode = it }
            )
            Divider(modifier = Modifier.padding(vertical = 16.dp))
        }

        // Voice Speed
        Text("🎙️ VOICE SPEED", style = MaterialTheme.typography.labelLarge)
        VoiceSlider(
            label = "Speed",
            value = voiceSpeed,
            onValueChange = { voiceSpeed = it }
        )

        // Voice Pitch
        Text("📊 VOICE PITCH", style = MaterialTheme.typography.labelLarge)
        VoiceSlider(
            label = "Pitch",
            value = voicePitch,
            onValueChange = { voicePitch = it }
        )

        // Volume
        Text("🔊 VOLUME", style = MaterialTheme.typography.labelLarge)
        VoiceSlider(
            label = "Volume",
            value = voiceVolume,
            onValueChange = { voiceVolume = it }
        )

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        // Language Selection
        Text("🌐 LANGUAGE", style = MaterialTheme.typography.labelLarge)
        LanguageDropdown(
            selectedLanguage = selectedLanguage,
            onLanguageSelected = { selectedLanguage = it }
        )

        Button(
            onClick = {
                // Save settings
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Text("Save Voice Settings")
        }
    }
}

@Composable
fun CharacterDropdown(selectedCharacter: String, onCharacterSelected: (String) -> Unit) {
    val characters = listOf("Maya", "Friday", "Venom", "Jarvis")
    var expanded by remember { mutableStateOf(false) }

    Box {
        Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selectedCharacter)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            characters.forEach { character ->
                DropdownMenuItem(
                    text = { Text(character) },
                    onClick = {
                        onCharacterSelected(character)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun VoiceModeSelector(selectedMode: String, onModeSelected: (String) -> Unit) {
    val modes = listOf("Girlfriend", "Normal", "Friend", "Mentor")
    var expanded by remember { mutableStateOf(false) }

    Box {
        Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selectedMode)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            modes.forEach { mode ->
                DropdownMenuItem(
                    text = { Text(mode) },
                    onClick = {
                        onModeSelected(mode)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun VoiceSlider(label: String, value: Float, onValueChange: (Float) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("${(value * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun LanguageDropdown(selectedLanguage: String, onLanguageSelected: (String) -> Unit) {
    val languages = listOf("English", "Hindi", "Urdu", "Spanish")
    var expanded by remember { mutableStateOf(false) }

    Box {
        Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selectedLanguage)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            languages.forEach { language ->
                DropdownMenuItem(
                    text = { Text(language) },
                    onClick = {
                        onLanguageSelected(language)
                        expanded = false
                    }
                )
            }
        }
    }
}
