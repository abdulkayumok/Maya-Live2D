package com.getmaya.android.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.getmaya.android.ui.screens.*

object NavScreens {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val VOICE_MODES = "voice_modes"
    const val MAYA_HOME = "maya_home"
    const val MEMORIES = "memories"
    const val WEBSITE_CODING = "website_coding"
    const val STUDY = "study"
    const val MAYA_RULES = "maya_rules"
    const val PC_PHONE = "pc_phone"
    const val PRIVACY = "privacy"
    const val ABOUT = "about"
    
    // Advanced Features
    const val SECURITY = "security"
    const val FACE_LOCK = "face_lock"
    const val BIOMETRIC = "biometric"
    const val BARCODE_SCANNER = "barcode_scanner"
    const val ADVANCED_VOICE = "advanced_voice"
    const val NOTIFICATIONS = "notifications"
    const val DEVICE_MANAGEMENT = "device_management"
}

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = NavScreens.HOME) {
        composable(NavScreens.HOME) {
            HomeScreen(navController)
        }
        composable(NavScreens.SETTINGS) {
            SettingsScreen(navController)
        }
        composable(NavScreens.VOICE_MODES) {
            VoiceModeSelectionScreen(navController)
        }
        composable(NavScreens.MAYA_HOME) {
            HomeScreen(navController)
        }
        composable(NavScreens.MEMORIES) {
            MemoriesScreen(navController)
        }
        composable(NavScreens.WEBSITE_CODING) {
            WebsiteCodingScreen(navController)
        }
        composable(NavScreens.STUDY) {
            StudyWhiteboardScreen(navController)
        }
        composable(NavScreens.MAYA_RULES) {
            MayaRulesScreen(navController)
        }
        composable(NavScreens.PC_PHONE) {
            PCPhoneScreen(navController)
        }
        composable(NavScreens.PRIVACY) {
            PrivacyPolicyScreen(navController)
        }
        composable(NavScreens.ABOUT) {
            AboutScreen(navController)
        }
        
        // Advanced Features
        composable(NavScreens.SECURITY) {
            SecurityScreen(navController)
        }
        composable(NavScreens.FACE_LOCK) {
            FaceLockScreen(navController)
        }
        composable(NavScreens.BARCODE_SCANNER) {
            BarcodeScannerScreen(navController)
        }
        composable(NavScreens.ADVANCED_VOICE) {
            AdvancedVoiceSettingsScreen(navController)
        }
        composable(NavScreens.NOTIFICATIONS) {
            NotificationsScreen(navController)
        }
        composable(NavScreens.DEVICE_MANAGEMENT) {
            DeviceManagementScreen(navController)
        }
    }
}
