package com.getmaya.android.data.repository

import android.content.Context
import com.getmaya.android.core.AiEngine
import com.getmaya.android.data.models.MayaSettings
import com.getmaya.android.data.models.PersonaRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

// ═══════════════════════════════════════════════════════════
// WIKI MEMORY — Maya's personal memory about the user
//
// From APK system prompt (extracted verbatim):
// "You maintain a small personal wiki about ONE person,
//  on their own phone. You are the assistant who serves
//  them; these pages are your own notes."
//
// FORMAT:
// SUMMARY: <one line, max 100 chars>
// ---
// <the page, in markdown, short bullet lines>
//
// Pages stored: /data/data/com.getmaya.android/files/wiki/
// ═══════════════════════════════════════════════════════════

class WikiMemory(context: Context, private val settings: MayaSettings) {

    private val wikiDir = File(context.filesDir, "wiki").also { it.mkdirs() }
    private val ai = AiEngine(settings, PersonaRegistry.MAYA)

    // ── All wiki pages ─────────────────────────────────────
    fun listPages(): List<WikiPage> {
        return wikiDir.listFiles()?.mapNotNull { f ->
            if (!f.name.endsWith(".md")) return@mapNotNull null
            val content = f.readText()
            val summaryLine = content.lines().firstOrNull { it.startsWith("SUMMARY:") }
            val summary = summaryLine?.removePrefix("SUMMARY:")?.trim() ?: f.nameWithoutExtension
            WikiPage(
                key     = f.nameWithoutExtension,
                summary = summary,
                content = content,
                lastModified = f.lastModified()
            )
        } ?: emptyList()
    }

    // ── Read page ──────────────────────────────────────────
    fun readPage(key: String): WikiPage? {
        val f = File(wikiDir, "$key.md")
        if (!f.exists()) return null
        val content = f.readText()
        val summary = content.lines().firstOrNull { it.startsWith("SUMMARY:") }
            ?.removePrefix("SUMMARY:")?.trim() ?: key
        return WikiPage(key, summary, content, f.lastModified())
    }

    // ── Write / update page ────────────────────────────────
    fun writePage(key: String, content: String) {
        File(wikiDir, "$key.md").writeText(content)
    }

    // ── AI: update a page with new information ─────────────
    suspend fun updatePage(key: String, newInfo: String): String = withContext(Dispatchers.IO) {
        val existing = readPage(key)?.content ?: ""
        val prompt = """
            You maintain a small personal wiki about ONE person, on their own phone.
            You are the assistant who serves them; these pages are your own notes.
            
            FORMAT:
            SUMMARY: <one line, max 100 chars>
            ---
            <the page, in markdown, short bullet lines>
            
            RULES:
            1. REWRITE THE PAGE IN FULL — not addition, replacement
            2. BE SPECIFIC — times, names, apps, numbers
            3. SEPARATE STATED FROM OBSERVED — lagta hai, shayad, maine notice kiya
            4. MARK LOW CONFIDENCE — a hedged right line > confident wrong line
            5. NO INVENTING — everything must trace to evidence
            6. HIS WORDS — Hinglish, his vocabulary
            
            EXISTING PAGE ($key):
            $existing
            
            NEW INFORMATION TO INCORPORATE:
            $newInfo
            
            Output the complete rewritten page only.
        """.trimIndent()

        val result = ai.chat(prompt)
        writePage(key, result)
        result
    }

    // ── AI: get relevant memory context for a message ──────
    suspend fun getRelevantContext(userMessage: String): String = withContext(Dispatchers.IO) {
        val pages = listPages()
        if (pages.isEmpty()) return@withContext ""

        val summaries = pages.joinToString("\n") { "- ${it.key}: ${it.summary}" }
        val checkPrompt = """
            User message: "$userMessage"
            
            Wiki pages available:
            $summaries
            
            Which pages are relevant? Reply with comma-separated keys only.
            If none relevant, reply: none
        """.trimIndent()

        val relevant = ai.chat(checkPrompt).trim()
        if (relevant.equals("none", ignoreCase = true)) return@withContext ""

        val relevantPages = relevant.split(",").map { it.trim() }
            .mapNotNull { readPage(it) }

        if (relevantPages.isEmpty()) return@withContext ""

        "MEMORY:\n" + relevantPages.joinToString("\n\n") { "[${it.key}]\n${it.content}" }
    }

    // ── Standard pages Maya maintains ─────────────────────
    companion object {
        const val PAGE_PROFILE    = "profile"      // Who the user is
        const val PAGE_BUSINESS   = "business"     // Business details
        const val PAGE_PREFERENCES = "preferences" // How user likes things
        const val PAGE_CONTACTS   = "contacts"     // Important people
        const val PAGE_PROJECTS   = "projects"     // Active projects
        const val PAGE_FINANCES   = "finances"     // Financial context
        const val PAGE_HEALTH     = "health"       // Health notes
        const val PAGE_GOALS      = "goals"        // User's goals
        const val PAGE_DEVICES    = "devices"      // Devices + accounts
        const val PAGE_SCHEDULE   = "schedule"     // Recurring schedule
    }

    // ── Remember (REMEMBER tool from coding agent) ─────────
    fun remember(key: String, value: String) {
        val f = File(wikiDir, "remember.json")
        val obj = if (f.exists()) JSONObject(f.readText()) else JSONObject()
        obj.put(key, value)
        f.writeText(obj.toString(2))
    }

    fun recall(key: String): String? {
        val f = File(wikiDir, "remember.json")
        if (!f.exists()) return null
        return JSONObject(f.readText()).optString(key).ifEmpty { null }
    }

    // ── Business profile ───────────────────────────────────
    fun saveBusinessProfile(profile: BusinessProfile) {
        File(wikiDir, "business.json").writeText(JSONObject().apply {
            put("name", profile.name)
            put("type", profile.type)
            put("location", profile.location)
            put("description", profile.description)
            put("target_audience", profile.targetAudience)
            put("social_handles", profile.socialHandles.toString())
            put("website", profile.website)
            put("contact", profile.contact)
        }.toString(2))
    }

    fun loadBusinessProfile(): BusinessProfile? {
        val f = File(wikiDir, "business.json")
        if (!f.exists()) return null
        val j = JSONObject(f.readText())
        return BusinessProfile(
            name = j.optString("name"),
            type = j.optString("type"),
            location = j.optString("location"),
            description = j.optString("description"),
            targetAudience = j.optString("target_audience"),
            website = j.optString("website"),
            contact = j.optString("contact")
        )
    }

    // ── Export / Import for backup ─────────────────────────
    fun exportAll(): String {
        val export = JSONObject()
        listPages().forEach { export.put(it.key, it.content) }
        return export.toString(2)
    }

    fun importAll(json: String) {
        val obj = JSONObject(json)
        obj.keys().forEach { key -> writePage(key, obj.getString(key)) }
    }
}

data class WikiPage(
    val key: String,
    val summary: String,
    val content: String,
    val lastModified: Long
)

data class BusinessProfile(
    val name: String = "",
    val type: String = "",
    val location: String = "",
    val description: String = "",
    val targetAudience: String = "",
    val socialHandles: Map<String, String> = emptyMap(),
    val website: String = "",
    val contact: String = ""
)

    // ── Context summary for AI injection ──────────────────
    fun buildContextSummary(): String {
        val pages = listPages()
        if (pages.isEmpty()) return ""
        return buildString {
            append("\n[MEMORY CONTEXT]\n")
            pages.take(5).forEach { page ->
                append("${page.key}: ${page.summary}\n")
            }
            append("[/MEMORY CONTEXT]")
        }
    }

    // ── Auto-update after tool calls ──────────────────────
    suspend fun autoUpdate(toolName: String, params: org.json.JSONObject, result: com.getmaya.android.tools.ToolResult) {
        val info = when (toolName) {
            "set_alarm"       -> "Alarm set at ${params.optString("time")} — ${params.optString("label")}"
            "add_reminder"    -> "Reminder: ${params.optString("text")} at ${params.optString("time")}"
            "set_user_name"   -> "User name set to: ${params.optString("name")}"
            "add_note"        -> "Note added: ${params.optString("content").take(50)}"
            "add_lead"        -> "Lead added: ${params.optString("name")}"
            "add_favorite"    -> "Favorite: ${params.optString("name")} = ${params.optString("value")}"
            "add_calendar_event" -> "Event: ${params.optString("title")} on ${params.optString("start")}"
            else -> return
        }
        updatePage("activity_log", info)
    }
