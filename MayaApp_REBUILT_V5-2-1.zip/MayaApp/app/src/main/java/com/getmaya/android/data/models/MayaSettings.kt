package com.getmaya.android.data.models

// ═══════════════════════════════════════════════════════════
// MAYA SETTINGS — extracted from APK strings
// Keys match actual SharedPreferences keys found in DEX
// ═══════════════════════════════════════════════════════════

data class MayaSettings(
    // ── Personal ──────────────────────────────────────────
    val userName: String = "",              // "How Maya addresses you"
    val userGender: String = "prefer_not",  // male/female/prefer_not
    val geminiApiKey: String = "",
    val defaultPersona: String = "maya",    // key: default_persona
    val personaSwitchDelaySec: Int = 3,

    // ── AI Engine ─────────────────────────────────────────
    val aiProvider: AiProvider = AiProvider.GEMINI_FREE,
    val codingModel: String = "",           // key: coding_model
    val visionModel: String = "",           // key: vision_model
    val groqApiKey: String = "",
    val anthropicApiKey: String = "",
    val openRouterApiKey: String = "",
    val openAiApiKey: String = "",
    val deepseekApiKey: String = "",
    val nvidiaApiKey: String = "",
    val togetherApiKey: String = "",
    val mistralApiKey: String = "",
    val customEndpointUrl: String = "",     // custom OpenAI-compatible
    val customEndpointTag: String = "",
    val customEndpointName: String = "",

    // ── Voice / STT ───────────────────────────────────────
    val deepgramApiKey: String = "",        // backup transcriber
    val helloMaya: Boolean = true,          // key: hello_maya (Hey Maya wake)
    val wakeUpMaya: Boolean = false,        // key: wake_up_maya (alternate wake)
    val emotiveMode: Boolean = false,       // key: emotive_mode (emotion voice)

    // ── Avatar ────────────────────────────────────────────
    val avatarCharacter: String = "maya",   // key: avatar_character
    val overlayCharacter: String = "maya",  // key: overlay_character
    val wallpaperCharacter: String = "",    // key: wallpaper_character
    val characterSizeDp: Int = 200,         // key: character_size_dp
    val avatarOnLowRam: Boolean = false,    // key: avatar_on_low_ram
    val blendMode: String = "normal",       // key: blend_mode

    // ── Intimacy / Mode ───────────────────────────────────
    val girlfriendMode: Boolean = false,    // key: girlfriend_mode (Settings toggle)
    val rRatedMode: Boolean = false,        // key: r_rated_mode (18+, Pro Max)
    val ageVerified: Boolean = false,       // must confirm twice
    val conversationMode: Boolean = false,  // key: conversation_mode (Pro Max)

    // ── Voice Guardian ────────────────────────────────────
    val guardianEnabled: Boolean = false,
    val guardianModelId: String = "",
    val listenMode: ListenMode = ListenMode.EVERYONE, // key: listen_mode
    val godMode: Boolean = false,           // key: god_mode
    val awayMode: Boolean = false,          // guard/away mode

    // ── Face Lock ─────────────────────────────────────────
    val faceLockEnabled: Boolean = false,   // key: maya_face_lock
    val watchmanMode: Boolean = false,      // key: watchman_mode
    val stealthMode: Boolean = false,

    // ── Audio ─────────────────────────────────────────────
    val earpieceMode: Boolean = false,      // key: earpiece_mode
    val mediaMode: Boolean = false,         // key: audio_media_mode
    val ignoreDoNotDisturb: Boolean = false,

    // ── System ────────────────────────────────────────────
    val keepAlive: Boolean = true,
    val batterySaver: Boolean = false,      // key: maya_battery_saver
    val proactiveMode: Boolean = false,
    val sendUnrecognized: Boolean = false,  // send unrecognized speech to Google

    // ── Driving ───────────────────────────────────────────
    val drivingModeEnabled: Boolean = false, // key: maya_driving_mode

    // ── Email ─────────────────────────────────────────────
    val emailAddress: String = "",
    val emailPassword: String = "",         // app password, never stored plain
    val emailSmtpHost: String = "",
    val emailSmtpPort: Int = 465,
    val emailSignature: String = "",

    // ── Image Generation ──────────────────────────────────
    val imageProvider: ImageProvider = ImageProvider.POLLINATIONS_FREE,
    val imageModelId: String = "",
    val imageApiKey: String = "",

    // ── Maya Sites ────────────────────────────────────────
    val mayaSitesPlanActive: Boolean = false,

    // ── Sync / Home ───────────────────────────────────────
    val mayaHomeBoxId: String = "",
    val mayaHomePassword: String = "",

    // ── Marketing ─────────────────────────────────────────
    val dailyStoryEnabled: Boolean = false,
    val dailyStoryTime: String = "09:00",
    val autoPostEnabled: Boolean = false,
    val useForPersonalSocial: Boolean = false,

    // ── Search ────────────────────────────────────────────
    val braveApiKey: String = "",
    val tavilyApiKey: String = "",
    val serpApiKey: String = "",
    val googlePlacesApiKey: String = "",

    // ── Notifications ─────────────────────────────────────
    val callAnnouncer: Boolean = true,
    val announceBatteryFull: Boolean = true,
    val announceBatteryLow: Boolean = true,
    val announceCharger: Boolean = true,
    val announceAirplaneMode: Boolean = true,

    // ── Pro ───────────────────────────────────────────────
    val proMaxActive: Boolean = true,

    // ── Update ────────────────────────────────────────────
    val autoUpdate: Boolean = true,
    val appVersion: String = "5.2.9"
)

// ───────────────────────────────────────────────────────────
// ENUMS
// ───────────────────────────────────────────────────────────

enum class AiProvider(val key: String, val displayName: String, val baseUrl: String) {
    GEMINI_FREE("gemini_free", "Gemini (Free)", "generativelanguage.googleapis.com"),
    GROQ("groq", "Groq", "api.groq.com/openai/v1"),
    ANTHROPIC("anthropic", "Claude (Anthropic)", "api.anthropic.com/v1/messages"),
    OPENAI("openai", "OpenAI", "api.openai.com/v1"),
    DEEPSEEK("deepseek", "DeepSeek", "api.deepseek.com/v1"),
    NVIDIA("nvidia", "NVIDIA NIM", "integrate.api.nvidia.com/v1"),
    TOGETHER("together", "Together AI", "api.together.xyz/v1"),
    MISTRAL("mistral", "Mistral", "api.mistral.ai/v1"),
    OPENROUTER("openrouter", "OpenRouter", "openrouter.ai/api/v1"),
    DEEPINFRA("deepinfra", "DeepInfra", "api.deepinfra.com/v1/openai"),
    CUSTOM("custom", "Custom / Local", "")
}

enum class ImageProvider(val key: String, val displayName: String) {
    POLLINATIONS_FREE("pollinations", "Pollinations (Free — 1 per 15s)"),
    OPENAI_IMAGE("openai_image", "OpenAI GPT Image 1"),
    GEMINI_IMAGE("gemini_image", "Gemini"),
    TOGETHER_IMAGE("together_image", "Together AI"),
    CUSTOM_IMAGE("custom_image", "Custom (OpenAI-compatible)")
}

enum class ListenMode(val key: String, val displayName: String) {
    EVERYONE("everyone", "Everyone (all voices reach Maya)"),
    BOSS_ONLY("boss", "Boss only (friends nearby filtered out)"),
    TRUSTED("trusted", "Trusted voices only")
}

enum class VoiceRole(val key: String, val description: String) {
    BOSS("boss", "Full control — all tools available"),
    FAMILY("family", "Normal tasks — voice-guardian admin stays boss-only"),
    FRIEND("friend", "Info only — music, YouTube, weather, search"),
    GUEST("guest", "Chat only — no phone tools, boss notified"),
    BLOCKED("blocked", "Cold treatment — nothing done")
}
