package com.getmaya.android.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.getmaya.android.R

// ═══════════════════════════════════════════════════════════
// CORE BROADCAST RECEIVERS
//
// All extracted from APK DEX with exact string constants,
// intent actions, and extra keys preserved.
// ═══════════════════════════════════════════════════════════

// ── 1. BootReceiver ────────────────────────────────────────

/**
 * Restarts Maya's foreground service after device boot.
 *
 * DEX actions:
 *   android.intent.action.BOOT_COMPLETED
 *   android.intent.action.QUICKBOOT_POWERON
 *   android.intent.action.MY_PACKAGE_REPLACED
 * DEX outgoing: com.getmaya.android.BOOT_STANDBY
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON" &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        // Start foreground service
        val svc = Intent(context, MayaForegroundService::class.java).apply {
            this.action = MayaForegroundService.ACTION_STANDBY
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc)
        } else {
            context.startService(svc)
        }

        // Broadcast standby signal to other components
        context.sendBroadcast(
            Intent("com.getmaya.android.BOOT_STANDBY")
                .setPackage(context.packageName)
        )
    }
}

// ── 2. DrivingOffReceiver ──────────────────────────────────

/**
 * Fires when Maya detects the user is driving (Bluetooth car disconnect, etc.).
 *
 * DEX action:  com.getmaya.android.DRIVING_OFF
 * DEX extras:  "notification" (Boolean — show a notification)
 */
class DrivingOffReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.getmaya.android.DRIVING_OFF") return

        val showNotification = intent.getBooleanExtra("notification", false)
        if (showNotification) {
            val nm = context.getSystemService(NotificationManager::class.java)
            ensureChannel(nm, "maya_reminders", "Maya reminders")
            val note = NotificationCompat.Builder(context, "maya_reminders")
                .setSmallIcon(R.drawable.ic_maya_logo)
                .setContentTitle("Maya")
                .setContentText("Drive safe 🚗")
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_DRIVING, note)
        }
    }

    private fun ensureChannel(nm: NotificationManager, id: String, name: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(id, name, NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    companion object {
        private const val NOTIF_DRIVING = 7401
    }
}

// ── 3. MicCaptureReceiver ─────────────────────────────────

/**
 * Triggers microphone capture or dump sessions.
 *
 * DEX action: com.getmaya.android.CAPTURE_MIC
 * DEX extras:
 *   ".enabled"   (Boolean) — enable/disable capture
 *   "seconds"    (Int)     — capture duration in seconds
 *   "dumps"      (Int)     — number of dump cycles
 *   "wakedumps"  (Boolean) — dump on wake-word events only
 */
class MicCaptureReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.getmaya.android.CAPTURE_MIC") return

        val enabled   = intent.getBooleanExtra(".enabled", true)
        val seconds   = intent.getIntExtra("seconds", 5)
        val dumps     = intent.getIntExtra("dumps", 1)
        val wakeDumps = intent.getBooleanExtra("wakedumps", false)

        val svc = Intent(context, MayaForegroundService::class.java).apply {
            action = MayaForegroundService.ACTION_CAPTURE_MIC
            putExtra(".enabled",  enabled)
            putExtra("seconds",   seconds)
            putExtra("dumps",     dumps)
            putExtra("wakedumps", wakeDumps)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc)
        } else {
            context.startService(svc)
        }
    }
}

// ── 4. PhoneStateReceiver ─────────────────────────────────

/**
 * Monitors phone call state changes.
 *
 * DEX action: android.intent.action.PHONE_STATE
 * DEX fields: [a: CoroutineScope/dispatcher, b: Boolean (in-call flag)]
 * DEX extras read:  "state", "incoming_number"
 * DEX broadcast:    com.getmaya.android.INCOMING_CALL
 *   extras:         "extra_call_state", "extra_call_number"
 */
class PhoneStateReceiver : BroadcastReceiver() {

    companion object {
        private var inCall: Boolean = false
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.intent.action.PHONE_STATE") return

        val state  = intent.getStringExtra("state") ?: return
        val number = intent.getStringExtra("incoming_number") ?: ""

        val newInCall = state != "IDLE"
        if (newInCall == inCall) return
        inCall = newInCall

        context.sendBroadcast(
            Intent("com.getmaya.android.INCOMING_CALL")
                .setPackage(context.packageName)
                .putExtra("extra_call_state",  state)
                .putExtra("extra_call_number", number)
        )
    }
}

// ── 5. ReminderReceiver ───────────────────────────────────

/**
 * Fires scheduled reminders as notifications with Maya's text.
 *
 * DEX channel: "maya_reminders" / "Maya reminders"
 * DEX extras read: "reminder_id" (Int), "reminder_text" (String)
 * DEX strings:
 *   "Maya ka reminder 🔔"
 *   "\nLAST ACTION RESULT: "
 *   " Termux se padh lo: termux_read_file."
 *   " owed_tools="
 */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID   = "maya_reminders"
        const val CHANNEL_NAME = "Maya reminders"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId   = intent.getIntExtra("reminder_id", 0)
        val reminderText = intent.getStringExtra("reminder_text") ?: return

        val nm = context.getSystemService(NotificationManager::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }

        val note = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_maya_logo)
            .setContentTitle("Maya ka reminder 🔔")
            .setContentText(reminderText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reminderText))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        nm.notify(CHANNEL_ID, reminderId, note)
    }
}
