package com.getmaya.android.tools.handlers

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.core.app.ActivityCompat
import com.getmaya.android.tools.ToolContext
import com.getmaya.android.tools.ToolResult

// ═══════════════════════════════════════════════════════════
// PHONE TOOLS — calls, SMS, lock, SIM
// ═══════════════════════════════════════════════════════════

class PhoneTools(private val ctx: ToolContext) {

    private val c = ctx.context

    // ── Answer incoming call ───────────────────────────────
    fun answerCall(): ToolResult {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val tm = c.getSystemService(TelecomManager::class.java)
            if (ActivityCompat.checkSelfPermission(c, Manifest.permission.ANSWER_PHONE_CALLS)
                == PackageManager.PERMISSION_GRANTED) {
                tm.acceptRingingCall()
                ToolResult.ok("Call answer kar liya")
            } else {
                // Accessibility fallback — tap "Answer" button
                ctx.accessibility?.performAnswerCall()
                ToolResult.ok("Call answer kiya")
            }
        } else {
            // Pre-O: Intent-based
            val intent = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                putExtra(Intent.EXTRA_KEY_EVENT, android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_HEADSETHOOK))
            }
            c.sendBroadcast(intent)
            ToolResult.ok("Call answer kiya")
        }
    }

    // ── Reject / decline call ──────────────────────────────
    fun rejectCall(message: String): ToolResult {
        val tm = c.getSystemService(TelecomManager::class.java)
        if (ActivityCompat.checkSelfPermission(c, Manifest.permission.ANSWER_PHONE_CALLS)
            == PackageManager.PERMISSION_GRANTED) {
            tm.endCall()
        } else {
            ctx.accessibility?.performEndCall()
        }
        if (message.isNotEmpty()) {
            // Auto-SMS — number comes from notification parser
            val number = ctx.notifications?.lastCallerNumber
            if (!number.isNullOrEmpty()) {
                sendSms(number, message)
            }
        }
        return ToolResult.ok("Call reject kar diya${if (message.isNotEmpty()) ", message bheji" else ""}")
    }

    // ── End active call ────────────────────────────────────
    fun endCall(): ToolResult {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val tm = c.getSystemService(TelecomManager::class.java)
            if (ActivityCompat.checkSelfPermission(c, Manifest.permission.ANSWER_PHONE_CALLS)
                == PackageManager.PERMISSION_GRANTED) {
                tm.endCall()
                return ToolResult.ok("Call kaat diya")
            }
        }
        // Accessibility fallback
        ctx.accessibility?.performEndCall()
        return ToolResult.ok("Call kaat diya")
    }

    // ── Make a call ────────────────────────────────────────
    fun makeCall(number: String, name: String): ToolResult {
        val dialNumber = resolveNumber(number, name)
            ?: return ToolResult.err("$name ka number nahi mila")

        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$dialNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (ActivityCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED) {
            c.startActivity(intent)
            return ToolResult.ok("${name.ifEmpty { dialNumber }} ko call kar raha hoon")
        }
        // Fallback: dial without auto-call
        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$dialNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        c.startActivity(dialIntent)
        return ToolResult.ok("Dialer khul gaya — manually dial karo")
    }

    // ── WhatsApp voice call ────────────────────────────────
    fun whatsappCall(number: String, name: String): ToolResult {
        val dialNumber = resolveNumber(number, name) ?: return ToolResult.err("Number nahi mila")
        val formatted = dialNumber.removePrefix("+").removePrefix("0").let {
            if (!it.startsWith("91")) "91$it" else it
        }
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://wa.me/$formatted")).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            c.startActivity(intent)
            // Accessibility: tap the Call button
            ctx.accessibility?.tapTextDelayed("Voice call", delayMs = 2000)
            ToolResult.ok("WhatsApp call शुरू कर रहा हूँ")
        } catch (e: Exception) {
            ToolResult.err("WhatsApp install nahi hai")
        }
    }

    // ── Set active SIM for calls ───────────────────────────
    fun setCallSim(sim: Int): ToolResult {
        // Opens SIM settings — no direct API without root
        val intent = Intent(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            android.provider.Settings.ACTION_NETWORK_OPERATOR_SETTINGS
        else
            android.provider.Settings.ACTION_SETTINGS
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        c.startActivity(intent)
        return ToolResult.ok("SIM settings khul gaye — SIM $sim select karo")
    }

    // ── Send SMS ───────────────────────────────────────────
    fun sendSms(number: String, message: String): ToolResult {
        return try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                c.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(number, null, parts, null, null)
            ToolResult.ok("SMS bhej diya")
        } catch (e: Exception) {
            ToolResult.err("SMS nahi gayi: ${e.message}")
        }
    }

    // ── Get lock state ─────────────────────────────────────
    fun getLockState(): ToolResult {
        val km = c.getSystemService(android.app.KeyguardManager::class.java)
        val isLocked = km.isKeyguardLocked
        return ToolResult.ok(if (isLocked) "Phone abhi lock hai" else "Phone unlock hai")
    }

    // ── Unlock phone ───────────────────────────────────────
    fun unlockPhone(): ToolResult {
        val intent = Intent(c, com.getmaya.android.ui.UnlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        c.startActivity(intent)
        return ToolResult.ok("Unlock screen khul gaya")
    }

    // ── Lock device ────────────────────────────────────────
    fun lockDevice(): ToolResult {
        val dpm = c.getSystemService(android.app.admin.DevicePolicyManager::class.java)
        return try {
            dpm.lockNow()
            ToolResult.ok("Phone lock kar diya")
        } catch (e: Exception) {
            // Accessibility: press power
            ctx.accessibility?.performLockScreen()
            ToolResult.ok("Phone lock kar diya")
        }
    }

    // ── Commentary mode ────────────────────────────────────
    private var commentaryActive = false

    fun startCommentary(): ToolResult {
        commentaryActive = true
        // MayaForegroundService will read notifications and speak them
        ctx.context.sendBroadcast(Intent("com.getmaya.android.COMMENTARY_START"))
        return ToolResult.ok("Call commentary on — notifications bol raha hoon")
    }

    fun stopCommentary(): ToolResult {
        commentaryActive = false
        ctx.context.sendBroadcast(Intent("com.getmaya.android.COMMENTARY_STOP"))
        return ToolResult.ok("Commentary band kar diya")
    }

    // ── Helper: resolve contact name to number ─────────────
    private fun resolveNumber(number: String, name: String): String? {
        if (number.isNotEmpty() && number.first().isDigit()) return number
        if (number.startsWith("+")) return number
        if (name.isEmpty()) return number.ifEmpty { null }

        // Query contacts
        val cursor = c.contentResolver.query(
            Uri.withAppendedPath(
                android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(name)
            ),
            arrayOf(android.provider.ContactsContract.PhoneLookup.NUMBER),
            null, null, null
        )
        return cursor?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: number.ifEmpty { null }
    }
}
