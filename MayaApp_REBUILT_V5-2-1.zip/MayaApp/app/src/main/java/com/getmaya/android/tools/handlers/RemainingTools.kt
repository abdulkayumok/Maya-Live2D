package com.getmaya.android.tools.handlers

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import com.getmaya.android.core.MayaForegroundService
import com.getmaya.android.sites.MayaDB
import com.getmaya.android.tools.ToolContext
import com.getmaya.android.tools.ToolResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ═══════════════════════════════════════════════════════════
// CAMERA TOOLS
// ═══════════════════════════════════════════════════════════
class CameraTools(private val ctx: ToolContext) {
    fun takePhoto(front: Boolean): ToolResult {
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (front) putExtra("android.intent.extras.CAMERA_FACING", 1)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok(if (front) "Front camera khul gaya" else "Camera khul gaya")
    }

    fun captureScreen(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CAPTURE_SCREEN"))
        return ToolResult.ok("Screenshot le raha hoon")
    }

    fun recordVideo(durationSec: Long): ToolResult {
        val intent = Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(android.provider.MediaStore.EXTRA_DURATION_LIMIT, durationSec.toInt())
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("Video recording shuru — ${durationSec}s")
    }

    fun recordScreen(durationSec: Long): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.RECORD_SCREEN").apply {
            putExtra("duration", durationSec)
        })
        return ToolResult.ok("Screen recording shuru")
    }

    fun stopRecording(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.STOP_RECORDING"))
        return ToolResult.ok("Recording rok diya")
    }

    fun startScreenShare(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.START_SCREEN_SHARE"))
        return ToolResult.ok("Screen share shuru")
    }

    fun stopScreenShare(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.STOP_SCREEN_SHARE"))
        return ToolResult.ok("Screen share band")
    }

    suspend fun generateImage(prompt: String, style: String): ToolResult = withContext(Dispatchers.IO) {
        val s = ctx.settings
        val provider = s.imageProvider
        val fullPrompt = if (style.isNotEmpty()) "$prompt, $style" else prompt
        try {
            val url = "https://image.pollinations.ai/prompt/${Uri.encode(fullPrompt)}?width=1024&height=1024&nologo=true"
            val outFile = File(ctx.context.cacheDir, "maya_img_${System.currentTimeMillis()}.jpg")
            val client = OkHttpClient()
            val resp = client.newCall(Request.Builder().url(url).build()).execute()
            if (resp.isSuccessful) {
                outFile.writeBytes(resp.body!!.bytes())
                ctx.context.sendBroadcast(Intent("com.getmaya.android.IMAGE_READY").apply {
                    putExtra("path", outFile.absolutePath)
                })
                ToolResult.ok("Image ban gayi — dekh le")
            } else {
                ToolResult.err("Image generate nahi hui: ${resp.code}")
            }
        } catch (e: Exception) {
            ToolResult.err("Image error: ${e.message}")
        }
    }

    suspend fun generateQuoteImage(text: String, author: String, background: String): ToolResult {
        val prompt = "motivational quote poster: \"$text\" by $author, ${background.ifEmpty { "beautiful gradient background" }}, typography, minimal"
        return generateImage(prompt, "high quality, poster design")
    }
}

// ═══════════════════════════════════════════════════════════
// WEB TOOLS
// ═══════════════════════════════════════════════════════════
class WebTools(private val ctx: ToolContext) {
    private val http = OkHttpClient()

    suspend fun search(query: String, results: Int): ToolResult = withContext(Dispatchers.IO) {
        val result = ctx.search.search(query, results)
        val sb = StringBuilder()
        result.items.take(3).forEachIndexed { i, item ->
            sb.append("${i+1}. ${item.title}: ${item.snippet.take(120)}\n")
        }
        ToolResult.ok(sb.toString().trim(), JSONObject().apply {
            put("query", query)
            put("provider", result.provider)
            put("count", result.items.size)
        })
    }

    suspend fun readUrl(url: ToolResult.Companion.() -> String): ToolResult = readUrl(url.toString())

    suspend fun readUrl(url: String): ToolResult = withContext(Dispatchers.IO) {
        try {
            val resp = http.newCall(Request.Builder().url(url)
                .header("User-Agent", "MayaAndroid/5.2.9").build()).execute()
            val body = resp.body?.string() ?: return@withContext ToolResult.err("Page khaali mili")
            // Strip HTML tags
            val text = body.replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ").trim().take(2000)
            ToolResult.ok("Page: $text")
        } catch (e: Exception) {
            ToolResult.err("URL read nahi hua: ${e.message}")
        }
    }

    suspend fun searchNearby(query: String, lat: Double, lng: Double): ToolResult {
        val location = if (lat != 0.0 && lng != 0.0) "$lat,$lng" else {
            val locResult = DeviceTools(ctx).getLocation()
            if (!locResult.success) return ToolResult.err("Location nahi mili")
            "${locResult.data.optDouble("lat")},${locResult.data.optDouble("lng")}"
        }
        return search("$query near $location", 5)
    }

    suspend fun deepResearch(topic: String, depth: Int): ToolResult = withContext(Dispatchers.IO) {
        val queries = listOf(topic, "$topic overview", "$topic latest 2024", "$topic India")
        val results = StringBuilder()
        queries.take(depth).forEach { q ->
            val r = ctx.search.search(q, 3)
            r.items.take(2).forEach { item ->
                results.append("• ${item.title}: ${item.snippet.take(100)}\n")
            }
        }
        ToolResult.ok("Research complete:\n${results.toString().trim()}")
    }

    suspend fun getResearchReport(topic: String) = deepResearch(topic, 5)

    suspend fun getNews(topic: String, country: String): ToolResult =
        search("$topic news $country latest", 5)

    suspend fun getWeather(location: String): ToolResult = withContext(Dispatchers.IO) {
        try {
            val loc = location.ifEmpty { "India" }
            val url = "https://wttr.in/${ Uri.encode(loc)}?format=3"
            val resp = http.newCall(Request.Builder().url(url).build()).execute()
            val text = resp.body?.string() ?: return@withContext ToolResult.err("Weather nahi mila")
            ToolResult.ok("Weather: $text")
        } catch (e: Exception) {
            ToolResult.err("Weather fetch nahi hua")
        }
    }
}

// ═══════════════════════════════════════════════════════════
// CODE / WEBSITE TOOLS  (routes to MayaDB + Termux)
// ═══════════════════════════════════════════════════════════
class CodeTools(private val ctx: ToolContext) {
    private val db by lazy { MayaDB.getInstance(ctx.context) }

    fun createWebsite(name: String, description: String, type: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_WEBSITE").apply {
            putExtra("name", name); putExtra("description", description); putExtra("type", type)
        })
        return ToolResult.ok("Website \"$name\" bana raha hoon — thodi der mein ready")
    }

    fun updateWebsite(name: String, instruction: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.UPDATE_WEBSITE").apply {
            putExtra("name", name); putExtra("instruction", instruction)
        })
        return ToolResult.ok("Website update ho rahi hai")
    }

    fun readWebsiteCode(name: String, file: String): ToolResult {
        val path = "${ctx.context.filesDir}/sites/$name/${file.ifEmpty { "index.html" }}"
        val f = File(path)
        return if (f.exists()) ToolResult.ok(f.readText().take(3000))
        else ToolResult.err("\"$name\" ka code nahi mila")
    }

    fun deleteWebsite(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.DELETE_WEBSITE").apply { putExtra("name", name) })
        return ToolResult.ok("\"$name\" delete ho raha hai")
    }

    fun deployWebsite(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.DEPLOY_WEBSITE").apply { putExtra("name", name) })
        return ToolResult.ok("\"$name\" deploy ho raha hai — url milega thodi der mein")
    }

    fun listWebsites(): ToolResult {
        val dir = File("${ctx.context.filesDir}/sites")
        val sites = dir.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
        return if (sites.isEmpty()) ToolResult.ok("Koi website nahi bani abhi tak")
        else ToolResult.ok("Websites: ${sites.joinToString(", ")}")
    }

    fun listLiveWebsites(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.LIST_LIVE_WEBSITES"))
        return ToolResult.ok("Live websites check kar raha hoon")
    }

    fun getWebsiteStatus(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.WEBSITE_STATUS").apply { putExtra("name", name) })
        return ToolResult.ok("\"$name\" ka status check kar raha hoon")
    }

    fun generatePage(site: String, page: String, description: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GENERATE_PAGE").apply {
            putExtra("site", site); putExtra("page", page); putExtra("description", description)
        })
        return ToolResult.ok("Page \"$page\" generate ho raha hai")
    }

    fun createCodeProject(name: String, language: String, description: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_CODE_PROJECT").apply {
            putExtra("name", name); putExtra("language", language); putExtra("description", description)
        })
        return ToolResult.ok("Project \"$name\" bana raha hoon")
    }

    suspend fun publishToGithub(project: String, repo: String, message: String): ToolResult {
        val cmd = "cd ~/projects/$project && git add -A && git commit -m \"${message.ifEmpty { "Maya update" }}\" && git push"
        return ctx.termux.exec(cmd)
            ?.let { ToolResult.ok("GitHub pe push ho gaya: $repo") }
            ?: ToolResult.err("GitHub push fail — Termux check karo")
    }

    suspend fun githubLocalRead(repo: String, path: String): ToolResult {
        val filePath = "~/projects/$repo/$path"
        return ctx.termux.exec("cat $filePath")
            ?.let { ToolResult.ok(it.take(2000)) }
            ?: ToolResult.err("File nahi mili: $filePath")
    }

    fun setGitIdentity(name: String, email: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_GIT_IDENTITY").apply {
            putExtra("name", name); putExtra("email", email)
        })
        return ToolResult.ok("Git identity set: $name <$email>")
    }

    fun huntercodeAction(action: String, project: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.HUNTERCODE_${ action.uppercase()}").apply {
            putExtra("project", project)
        })
        return ToolResult.ok("HunterCode: $action \"$project\"")
    }
}

// ═══════════════════════════════════════════════════════════
// SOCIAL MEDIA TOOLS
// ═══════════════════════════════════════════════════════════
class SocialTools(private val ctx: ToolContext) {
    fun postPhoto(platform: String, imagePath: String, caption: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOCIAL_POST_PHOTO").apply {
            putExtra("platform", platform); putExtra("imagePath", imagePath); putExtra("caption", caption)
        })
        return ToolResult.ok("$platform pe photo post ho raha hai")
    }

    fun postText(platform: String, text: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOCIAL_POST_TEXT").apply {
            putExtra("platform", platform); putExtra("text", text)
        })
        return ToolResult.ok("$platform pe post ho raha hai")
    }

    fun postStory(platform: String, mediaPath: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOCIAL_POST_STORY").apply {
            putExtra("platform", platform); putExtra("mediaPath", mediaPath)
        })
        return ToolResult.ok("Story post ho rahi hai")
    }

    fun facebookPost(text: String, imagePath: String): ToolResult = postPhoto("facebook", imagePath, text)
    fun instagramPost(imagePath: String, caption: String): ToolResult = postPhoto("instagram", imagePath, caption)

    fun schedulePost(platform: String, content: String, time: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOCIAL_SCHEDULE").apply {
            putExtra("platform", platform); putExtra("content", content); putExtra("time", time)
        })
        return ToolResult.ok("Post schedule ho gaya: $time")
    }

    fun cancelScheduledPost(id: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOCIAL_CANCEL_SCHEDULE").apply { putExtra("id", id) })
        return ToolResult.ok("Scheduled post cancel")
    }

    fun listScheduledPosts(): ToolResult {
        val prefs = ctx.context.getSharedPreferences("maya_scheduled_posts", Context.MODE_PRIVATE)
        val posts = prefs.all.entries.take(10).joinToString("\n") { "${it.key}: ${it.value}" }
        return ToolResult.ok(if (posts.isEmpty()) "Koi scheduled post nahi" else posts)
    }

    fun setDailyStory(enabled: Boolean, time: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_DAILY_STORY").apply {
            putExtra("enabled", enabled); putExtra("time", time)
        })
        return ToolResult.ok(if (enabled) "Daily story on — $time bajey" else "Daily story off")
    }

    fun createContent(topic: String, platform: String, tone: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_CONTENT").apply {
            putExtra("topic", topic); putExtra("platform", platform); putExtra("tone", tone)
        })
        return ToolResult.ok("Content bana raha hoon — thodi der mein")
    }

    fun autoPost(enabled: Boolean): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.AUTO_POST").apply { putExtra("enabled", enabled) })
        return ToolResult.ok(if (enabled) "Auto post on" else "Auto post off")
    }
}

// ═══════════════════════════════════════════════════════════
// DOCUMENT TOOLS
// ═══════════════════════════════════════════════════════════
class DocTools(private val ctx: ToolContext) {
    private val docsDir by lazy { File(ctx.context.filesDir, "docs").also { it.mkdirs() } }

    fun createDocument(title: String, content: String): ToolResult {
        val file = File(docsDir, "${title.replace(" ", "_")}.txt")
        file.writeText(content)
        return ToolResult.ok("Document \"$title\" ban gaya")
    }

    fun readDocument(title: String): ToolResult {
        val file = docsDir.listFiles()?.firstOrNull { it.nameWithoutExtension.equals(title, ignoreCase = true) }
            ?: return ToolResult.err("Document \"$title\" nahi mila")
        return ToolResult.ok(file.readText().take(2000))
    }

    fun listDocuments(): ToolResult {
        val files = docsDir.listFiles()?.map { it.nameWithoutExtension } ?: emptyList()
        return if (files.isEmpty()) ToolResult.ok("Koi document nahi")
        else ToolResult.ok("Documents: ${files.joinToString(", ")}")
    }

    fun openDocument(title: String): ToolResult {
        val file = docsDir.listFiles()?.firstOrNull { it.nameWithoutExtension.equals(title, ignoreCase = true) }
            ?: return ToolResult.err("Document nahi mila")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.fromFile(file), "text/plain")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("Document khul gaya")
    }

    suspend fun writeEmail(to: String, subject: String, body: String): ToolResult {
        // Draft only — stored locally
        val draft = JSONObject().apply {
            put("to", to); put("subject", subject); put("body", body)
            put("draft_time", System.currentTimeMillis())
        }
        File(ctx.context.cacheDir, "email_draft.json").writeText(draft.toString())
        return ToolResult.ok("Email draft ready — \"$subject\" — bhejun?")
    }

    suspend fun sendEmail(to: String, subject: String, body: String): ToolResult = withContext(Dispatchers.IO) {
        val s = ctx.settings
        if (s.emailAddress.isEmpty()) return@withContext ToolResult.err("Email settings set nahi — Settings mein jao")
        try {
            ctx.context.sendBroadcast(Intent("com.getmaya.android.SEND_EMAIL").apply {
                putExtra("to", to); putExtra("subject", subject)
                putExtra("body", body)
            })
            ToolResult.ok("Email bhej di \"$subject\" to $to")
        } catch (e: Exception) {
            ToolResult.err("Email nahi gayi: ${e.message}")
        }
    }

    fun createNote(title: String, content: String): ToolResult {
        val notesDir = File(ctx.context.filesDir, "notes").also { it.mkdirs() }
        File(notesDir, "${title.replace(" ","_")}_${System.currentTimeMillis()}.txt").writeText("$title\n\n$content")
        return ToolResult.ok("Note save ho gaya: \"$title\"")
    }

    fun addNote(content: String): ToolResult {
        val title = SimpleDateFormat("MMM d HH:mm", Locale.getDefault()).format(Date())
        return createNote(title, content)
    }

    fun saveScript(title: String, script: String): ToolResult {
        return createNote("Script: $title", script)
    }

    fun writeVideoScript(topic: String, duration: String, style: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.WRITE_VIDEO_SCRIPT").apply {
            putExtra("topic", topic); putExtra("duration", duration); putExtra("style", style)
        })
        return ToolResult.ok("Video script likh raha hoon \"$topic\" ke liye")
    }
}

// ═══════════════════════════════════════════════════════════
// ALARM TOOLS
// ═══════════════════════════════════════════════════════════
class AlarmTools(private val ctx: ToolContext) {
    fun addReminder(text: String, time: String, repeat: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.ADD_REMINDER").apply {
            putExtra("text", text); putExtra("time", time); putExtra("repeat", repeat)
        })
        return ToolResult.ok("Reminder set: \"$text\" — $time")
    }

    fun listReminders(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.LIST_REMINDERS"))
        return ToolResult.ok("Reminders list aa rahi hai")
    }

    fun setAlarm(time: String, label: String): ToolResult {
        val parts = time.split(":")
        val hour = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 0
        val minute = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifEmpty { "Maya alarm" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("Alarm set: $time${if (label.isNotEmpty()) " — $label" else ""}")
    }

    fun setTimer(seconds: Long, label: String): ToolResult {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds.toInt())
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifEmpty { "Maya timer" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.context.startActivity(intent)
        val display = when {
            seconds >= 3600 -> "${seconds/3600}h ${(seconds%3600)/60}m"
            seconds >= 60   -> "${seconds/60}m ${seconds%60}s"
            else            -> "${seconds}s"
        }
        return ToolResult.ok("Timer set: $display")
    }

    fun addCalendarEvent(title: String, start: String, end: String, location: String): ToolResult {
        val cv = ContentValues().apply {
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, "Added by Maya")
            put(CalendarContract.Events.EVENT_LOCATION, location)
            put(CalendarContract.Events.CALENDAR_ID, 1)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            // Parse start/end — accept "HH:mm" or epoch millis or ISO
            put(CalendarContract.Events.DTSTART, parseTime(start))
            put(CalendarContract.Events.DTEND, parseTime(end).let { if (it == 0L) parseTime(start) + 3600000 else it })
        }
        try {
            ctx.context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, cv)
            return ToolResult.ok("Calendar event add kiya: \"$title\"")
        } catch (e: Exception) {
            return ToolResult.err("Calendar access nahi mila — permission do")
        }
    }

    private fun parseTime(s: String): Long {
        if (s.isEmpty()) return System.currentTimeMillis()
        return s.toLongOrNull()
            ?: SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).runCatching { parse(s)?.time }.getOrNull()
            ?: System.currentTimeMillis()
    }

    fun setEventTrigger(event: String, action: String): ToolResult {
        val prefs = ctx.context.getSharedPreferences("maya_triggers", Context.MODE_PRIVATE)
        prefs.edit().putString("trigger_$event", action).apply()
        return ToolResult.ok("Trigger set: $event → $action")
    }
}

// ═══════════════════════════════════════════════════════════
// SECURITY TOOLS
// ═══════════════════════════════════════════════════════════
class SecurityTools(private val ctx: ToolContext) {
    private val prefs get() = ctx.context.getSharedPreferences("maya_security", Context.MODE_PRIVATE)

    fun armGuard(): ToolResult {
        prefs.edit().putBoolean("guard_armed", true).apply()
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GUARD_ARM"))
        return ToolResult.ok("Guard armed — touch alert on")
    }

    fun disarmGuard(): ToolResult {
        prefs.edit().putBoolean("guard_armed", false).apply()
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GUARD_DISARM"))
        return ToolResult.ok("Guard disarmed")
    }

    fun setTouchGuard(on: Boolean): ToolResult = if (on) armGuard() else disarmGuard()

    fun getTouchGuardStatus(): ToolResult {
        val armed = prefs.getBoolean("guard_armed", false)
        return ToolResult.ok(if (armed) "Touch guard ON" else "Touch guard OFF")
    }

    fun guardianLock(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GUARDIAN_LOCK"))
        return ToolResult.ok("Voice guardian lock on — boss voice ke bina kuch nahi hoga")
    }

    fun setWatchman(on: Boolean): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_WATCHMAN").apply { putExtra("on", on) })
        return ToolResult.ok(if (on) "Watchman on — har face save ho raha hai" else "Watchman off")
    }

    fun getWatchmanLog(): ToolResult {
        val logFile = File(ctx.context.filesDir, "watchman_log.txt")
        return if (logFile.exists()) ToolResult.ok(logFile.readText().takeLast(1000))
        else ToolResult.ok("Watchman log khaali")
    }

    fun addFace(name: String, role: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.ADD_FACE").apply {
            putExtra("name", name); putExtra("role", role)
        })
        return ToolResult.ok("Face add ho raha hai: $name ($role)")
    }

    fun removeFace(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.REMOVE_FACE").apply { putExtra("name", name) })
        return ToolResult.ok("Face remove: $name")
    }

    fun listFaces(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.LIST_FACES"))
        return ToolResult.ok("Face list aa rahi hai")
    }

    fun verifyFace(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.VERIFY_FACE"))
        return ToolResult.ok("Face verify kar raha hoon")
    }

    fun setVoiceRole(role: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_VOICE_ROLE").apply { putExtra("role", role) })
        return ToolResult.ok("Voice role set: $role")
    }

    fun removeVoice(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.REMOVE_VOICE").apply { putExtra("name", name) })
        return ToolResult.ok("Voice remove: $name")
    }

    fun listVoices(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.LIST_VOICES"))
        return ToolResult.ok("Voice list aa rahi hai")
    }

    fun voiceCheck(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.VOICE_CHECK"))
        return ToolResult.ok("Voice check shuru — bol kuch bhi")
    }

    fun sosTrigger(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SOS_TRIGGER"))
        return ToolResult.ok("SOS bhej raha hoon!")
    }

    fun addSosContact(name: String, number: String): ToolResult {
        prefs.edit().putString("sos_$name", number).apply()
        return ToolResult.ok("SOS contact add: $name — $number")
    }

    fun listSosContacts(): ToolResult {
        val contacts = prefs.all.filter { it.key.startsWith("sos_") }
            .map { "${it.key.removePrefix("sos_")}: ${it.value}" }
        return if (contacts.isEmpty()) ToolResult.ok("Koi SOS contact nahi")
        else ToolResult.ok("SOS contacts:\n${contacts.joinToString("\n")}")
    }
}

// ═══════════════════════════════════════════════════════════
// FINANCE TOOLS
// ═══════════════════════════════════════════════════════════
class FinanceTools(private val ctx: ToolContext) {
    private val http = OkHttpClient()
    private val prefs get() = ctx.context.getSharedPreferences("maya_finance", Context.MODE_PRIVATE)

    suspend fun getStockQuote(symbol: String): ToolResult = withContext(Dispatchers.IO) {
        try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$symbol?interval=1d&range=1d"
            val resp = http.newCall(Request.Builder().url(url).build()).execute()
            val json = JSONObject(resp.body!!.string())
            val result = json.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val meta = result.getJSONObject("meta")
            val price = meta.optDouble("regularMarketPrice", 0.0)
            val prev  = meta.optDouble("previousClose", 0.0)
            val change = if (prev > 0) ((price - prev) / prev * 100) else 0.0
            val sym = meta.optString("symbol", symbol)
            val sign = if (change >= 0) "▲" else "▼"
            ToolResult.ok("$sym: ₹${String.format("%.2f", price)} $sign${String.format("%.2f", kotlin.math.abs(change))}%")
        } catch (e: Exception) {
            ToolResult.err("$symbol ka rate nahi mila")
        }
    }

    suspend fun getStockHistory(symbol: String, period: String): ToolResult = withContext(Dispatchers.IO) {
        try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$symbol?interval=1d&range=$period"
            val resp = http.newCall(Request.Builder().url(url).build()).execute()
            val json = JSONObject(resp.body!!.string())
            val result = json.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val closes = result.getJSONObject("indicators").getJSONArray("quote")
                .getJSONObject(0).getJSONArray("close")
            val high = (0 until closes.length()).maxOf { closes.optDouble(it, 0.0) }
            val low  = (0 until closes.length()).minOf { closes.optDouble(it, Double.MAX_VALUE) }
            ToolResult.ok("$symbol ($period) — High: ${String.format("%.2f",high)} | Low: ${String.format("%.2f",low)}")
        } catch (e: Exception) {
            ToolResult.err("History nahi mili")
        }
    }

    suspend fun getStockIndicators(symbol: String) = getStockHistory(symbol, "3mo")
    suspend fun getTrendingStocks(market: String) = search("trending stocks $market today")

    private suspend fun search(q: String) = ctx.search.search(q, 3).let {
        ToolResult.ok(it.items.take(3).joinToString("\n") { i -> "• ${i.title}" })
    }

    suspend fun searchStock(query: String): ToolResult = withContext(Dispatchers.IO) {
        try {
            val url = "https://query1.finance.yahoo.com/v1/finance/search?q=${Uri.encode(query)}&newsCount=0"
            val resp = http.newCall(Request.Builder().url(url).build()).execute()
            val json = JSONObject(resp.body!!.string())
            val quotes = json.optJSONArray("quotes") ?: JSONArray()
            val result = (0 until minOf(quotes.length(), 5)).map {
                val q2 = quotes.getJSONObject(it)
                "${q2.optString("symbol")} — ${q2.optString("longname", q2.optString("shortname"))}"
            }
            ToolResult.ok(result.joinToString("\n"))
        } catch (e: Exception) {
            ToolResult.err("Search fail: ${e.message}")
        }
    }

    fun addToWatchlist(symbol: String): ToolResult {
        val list = getWatchlistRaw().toMutableSet().also { it.add(symbol.uppercase()) }
        prefs.edit().putStringSet("watchlist", list).apply()
        return ToolResult.ok("$symbol watchlist mein add")
    }

    fun removeFromWatchlist(symbol: String): ToolResult {
        val list = getWatchlistRaw().toMutableSet().also { it.remove(symbol.uppercase()) }
        prefs.edit().putStringSet("watchlist", list).apply()
        return ToolResult.ok("$symbol watchlist se remove")
    }

    fun getWatchlist(): ToolResult {
        val list = getWatchlistRaw()
        return if (list.isEmpty()) ToolResult.ok("Watchlist khaali hai")
        else ToolResult.ok("Watchlist: ${list.joinToString(", ")}")
    }

    private fun getWatchlistRaw() = prefs.getStringSet("watchlist", emptySet()) ?: emptySet()

    fun listPriceAlerts(): ToolResult {
        val alerts = prefs.all.filter { it.key.startsWith("alert_") }
            .map { "${it.key.removePrefix("alert_")}: ${it.value}" }
        return if (alerts.isEmpty()) ToolResult.ok("Koi price alert nahi")
        else ToolResult.ok(alerts.joinToString("\n"))
    }

    fun setPriceAlert(symbol: String, price: Double, condition: String): ToolResult {
        prefs.edit().putString("alert_${symbol}_${condition}", price.toString()).apply()
        return ToolResult.ok("Alert set: $symbol $condition ₹$price")
    }

    fun addHolding(symbol: String, qty: Double, avgPrice: Double): ToolResult {
        val holding = JSONObject().apply {
            put("symbol", symbol.uppercase()); put("qty", qty); put("avgPrice", avgPrice)
        }
        val holdings = getHoldingsJson()
        holdings.put(symbol.uppercase(), holding)
        prefs.edit().putString("portfolio", holdings.toString()).apply()
        return ToolResult.ok("Portfolio: ${symbol.uppercase()} — ${qty} units @ ₹$avgPrice")
    }

    fun removeHolding(symbol: String): ToolResult {
        val holdings = getHoldingsJson()
        holdings.remove(symbol.uppercase())
        prefs.edit().putString("portfolio", holdings.toString()).apply()
        return ToolResult.ok("$symbol portfolio se remove")
    }

    fun updateHolding(symbol: String, qty: Double, avgPrice: Double) = addHolding(symbol, qty, avgPrice)

    fun getPortfolio(): ToolResult {
        val holdings = getHoldingsJson()
        if (holdings.length() == 0) return ToolResult.ok("Portfolio khaali hai")
        val sb = StringBuilder("Portfolio:\n")
        holdings.keys().forEach { key ->
            val h = holdings.getJSONObject(key)
            sb.append("• $key — ${h.optDouble("qty")} units @ ₹${h.optDouble("avgPrice")}\n")
        }
        return ToolResult.ok(sb.toString().trim())
    }

    private fun getHoldingsJson(): JSONObject {
        val raw = prefs.getString("portfolio", "{}") ?: "{}"
        return JSONObject(raw)
    }

    suspend fun getMarketNews(symbol: String) = search("$symbol stock news today India")
    suspend fun getMarketSnapshot(market: String) = search("$market market today NIFTY SENSEX")
    suspend fun getCryptoPrice(symbol: String) = getStockQuote("${symbol}-USD")
    suspend fun getForexRate(from: String, to: String) = getStockQuote("${from}${to}=X")

    suspend fun scanWatchlist(): ToolResult {
        val list = getWatchlistRaw()
        if (list.isEmpty()) return ToolResult.ok("Watchlist khaali hai")
        val sb = StringBuilder()
        list.forEach { sym ->
            val r = getStockQuote(sym)
            sb.append("${r.speak}\n")
        }
        return ToolResult.ok(sb.toString().trim())
    }

    fun sendReport(type: String, period: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SEND_FINANCE_REPORT").apply {
            putExtra("type", type); putExtra("period", period)
        })
        return ToolResult.ok("Report bhej raha hoon")
    }

    fun saveReportFormat(format: String): ToolResult {
        prefs.edit().putString("report_format", format).apply()
        return ToolResult.ok("Report format save: $format")
    }
}

// ═══════════════════════════════════════════════════════════
// MARKETING TOOLS
// ═══════════════════════════════════════════════════════════
class MarketingToolsHandler(private val ctx: ToolContext) {
    fun createAdPlan(product: String, budget: String, audience: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_AD_PLAN").apply {
            putExtra("product", product); putExtra("budget", budget); putExtra("audience", audience)
        })
        return ToolResult.ok("Ad plan bana raha hoon \"$product\" ke liye")
    }

    fun createLandingPage(product: String, cta: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_LANDING_PAGE").apply {
            putExtra("product", product); putExtra("cta", cta)
        })
        return ToolResult.ok("Landing page bana raha hoon")
    }

    fun getAdMetrics(platform: String, period: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GET_AD_METRICS").apply {
            putExtra("platform", platform); putExtra("period", period)
        })
        return ToolResult.ok("$platform metrics check kar raha hoon")
    }

    private val prefs get() = ctx.context.getSharedPreferences("maya_crm", Context.MODE_PRIVATE)

    fun addLead(name: String, phone: String, email: String, note: String): ToolResult {
        val id = System.currentTimeMillis().toString()
        val lead = JSONObject().apply {
            put("id", id); put("name", name); put("phone", phone)
            put("email", email); put("note", note); put("status", "new")
            put("created", System.currentTimeMillis())
        }
        prefs.edit().putString("lead_$id", lead.toString()).apply()
        return ToolResult.ok("Lead add: $name — ID $id")
    }

    fun updateLead(id: String, status: String, note: String): ToolResult {
        val raw = prefs.getString("lead_$id", null) ?: return ToolResult.err("Lead $id nahi mila")
        val lead = JSONObject(raw).apply {
            if (status.isNotEmpty()) put("status", status)
            if (note.isNotEmpty()) put("note", note)
        }
        prefs.edit().putString("lead_$id", lead.toString()).apply()
        return ToolResult.ok("Lead update: $id")
    }

    fun deleteLead(id: String): ToolResult {
        prefs.edit().remove("lead_$id").apply()
        return ToolResult.ok("Lead delete: $id")
    }

    fun listLeads(status: String): ToolResult {
        val leads = prefs.all.filter { it.key.startsWith("lead_") }
            .mapNotNull { JSONObject(it.value.toString()) }
            .filter { status.isEmpty() || it.optString("status") == status }
        if (leads.isEmpty()) return ToolResult.ok("Koi lead nahi")
        val sb = leads.take(10).joinToString("\n") {
            "• ${it.optString("name")} — ${it.optString("status")} — ${it.optString("phone")}"
        }
        return ToolResult.ok(sb)
    }

    fun sendLeadMessage(id: String, message: String): ToolResult {
        val raw = prefs.getString("lead_$id", null) ?: return ToolResult.err("Lead nahi mila")
        val lead = JSONObject(raw)
        val phone = lead.optString("phone")
        if (phone.isEmpty()) return ToolResult.err("Lead ka phone number nahi")
        WhatsAppTools(ctx).sendMessage(phone, lead.optString("name"), message)
        return ToolResult.ok("Lead ko message bheja")
    }

    fun setMessageAlerts(on: Boolean, keyword: String): ToolResult {
        prefs.edit().putBoolean("message_alerts", on).putString("alert_keyword", keyword).apply()
        return ToolResult.ok(if (on) "Message alerts on — keyword: \"$keyword\"" else "Alerts off")
    }

    fun listWatches(): ToolResult {
        val keyword = prefs.getString("alert_keyword", "") ?: ""
        val on = prefs.getBoolean("message_alerts", false)
        return ToolResult.ok("Watches: ${if (on) "ON — $keyword" else "OFF"}")
    }

    suspend fun sendWebhook(url: String, data: JSONObject): ToolResult = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient()
            val body = data.toString().toRequestBody("application/json".toMediaType())
            val resp = client.newCall(Request.Builder().url(url).post(body).build()).execute()
            ToolResult.ok("Webhook sent — status ${resp.code}")
        } catch (e: Exception) {
            ToolResult.err("Webhook fail: ${e.message}")
        }
    }
}

// ═══════════════════════════════════════════════════════════
// MEMORY / RULES TOOLS
// ═══════════════════════════════════════════════════════════
class MemoryTools(private val ctx: ToolContext) {
    private val prefs get() = ctx.context.getSharedPreferences("maya_memory_meta", Context.MODE_PRIVATE)

    fun backupMemory(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.BACKUP_MEMORY"))
        return ToolResult.ok("Memory backup ho rahi hai")
    }

    fun restoreMemory(backup: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.RESTORE_MEMORY").apply { putExtra("backup", backup) })
        return ToolResult.ok("Memory restore ho rahi hai")
    }

    fun exportMemory(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.EXPORT_MEMORY"))
        return ToolResult.ok("Memory export ho rahi hai")
    }

    fun addRule(trigger: String, action: String, condition: String): ToolResult {
        val id = System.currentTimeMillis().toString()
        val rule = JSONObject().apply {
            put("id", id); put("trigger", trigger); put("action", action); put("condition", condition)
        }
        prefs.edit().putString("rule_$id", rule.toString()).apply()
        return ToolResult.ok("Rule add: \"$trigger\" → \"$action\"")
    }

    fun deleteRule(id: String): ToolResult {
        prefs.edit().remove("rule_$id").apply()
        return ToolResult.ok("Rule delete: $id")
    }

    fun listRules(): ToolResult {
        val rules = prefs.all.filter { it.key.startsWith("rule_") }
            .mapNotNull { JSONObject(it.value.toString()) }
        if (rules.isEmpty()) return ToolResult.ok("Koi rule nahi")
        return ToolResult.ok(rules.joinToString("\n") {
            "• ${it.optString("trigger")} → ${it.optString("action")}"
        })
    }

    fun updateRule(id: String, trigger: String, action: String): ToolResult {
        val raw = prefs.getString("rule_$id", null) ?: return ToolResult.err("Rule nahi mila")
        val rule = JSONObject(raw).apply {
            if (trigger.isNotEmpty()) put("trigger", trigger)
            if (action.isNotEmpty()) put("action", action)
        }
        prefs.edit().putString("rule_$id", rule.toString()).apply()
        return ToolResult.ok("Rule update: $id")
    }

    fun setUserName(name: String): ToolResult {
        val repo = ctx.repo
        val settings = ctx.settings.copy(userName = name)
        repo.save(settings)
        return ToolResult.ok("Theek hai — ab se \"$name\" bolungi")
    }

    fun setAutoSave(on: Boolean): ToolResult {
        prefs.edit().putBoolean("auto_save", on).apply()
        return ToolResult.ok(if (on) "Memory auto-save on" else "Auto-save off")
    }
}

// ═══════════════════════════════════════════════════════════
// CONNECTOR TOOLS
// ═══════════════════════════════════════════════════════════
class ConnectorTools(private val ctx: ToolContext) {
    suspend fun notionSearch(query: String): ToolResult = withContext(Dispatchers.IO) {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.NOTION_SEARCH").apply { putExtra("query", query) })
        ToolResult.ok("Notion search: \"$query\"")
    }

    fun spotifyPlay(query: String): ToolResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.context.startActivity(intent)
            ToolResult.ok("Spotify: \"$query\"")
        } catch (e: Exception) {
            playMusicFallback(query)
        }
    }

    fun playMusic(query: String, service: String): ToolResult {
        return when (service.lowercase()) {
            "spotify" -> spotifyPlay(query)
            "youtube" -> youtubePlay(query)
            else -> spotifyPlay(query)
        }
    }

    private fun playMusicFallback(query: String): ToolResult {
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://music.youtube.com/search?q=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("YouTube Music: \"$query\"")
    }

    fun getNowPlaying(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.GET_NOW_PLAYING"))
        return ToolResult.ok("Now playing check kar raha hoon")
    }

    fun setMusicPrefs(genres: String, service: String): ToolResult {
        val prefs = ctx.context.getSharedPreferences("maya_music", Context.MODE_PRIVATE)
        prefs.edit().putString("genres", genres).putString("service", service).apply()
        return ToolResult.ok("Music preferences save: $genres — $service")
    }

    fun youtubePlay(query: String): ToolResult {
        val intent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.context.startActivity(intent)
            ToolResult.ok("YouTube: \"$query\"")
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.context.startActivity(webIntent)
            ToolResult.ok("YouTube browser mein khula: \"$query\"")
        }
    }
}

// ═══════════════════════════════════════════════════════════
// AUTOMATION TOOLS
// ═══════════════════════════════════════════════════════════
class AutomationTools(private val ctx: ToolContext) {
    private val macroDir by lazy { File(ctx.context.filesDir, "macros").also { it.mkdirs() } }

    fun playMacro(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.PLAY_MACRO").apply { putExtra("name", name) })
        return ToolResult.ok("Macro \"$name\" chal raha hai")
    }

    fun recordMacro(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.RECORD_MACRO").apply { putExtra("name", name) })
        return ToolResult.ok("Macro recording: \"$name\" — apne actions karo")
    }

    fun createMacro(name: String, steps: String): ToolResult {
        File(macroDir, "$name.json").writeText(JSONObject().apply {
            put("name", name); put("steps", steps); put("created", System.currentTimeMillis())
        }.toString())
        return ToolResult.ok("Macro bana: \"$name\"")
    }

    fun editMacro(name: String, steps: String): ToolResult = createMacro(name, steps)

    fun deleteMacro(name: String): ToolResult {
        File(macroDir, "$name.json").delete()
        return ToolResult.ok("Macro delete: \"$name\"")
    }

    fun saveMacro(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SAVE_MACRO").apply { putExtra("name", name) })
        return ToolResult.ok("Macro save: \"$name\"")
    }

    fun listMacros(): ToolResult {
        val macros = macroDir.listFiles()?.map { it.nameWithoutExtension } ?: emptyList()
        return if (macros.isEmpty()) ToolResult.ok("Koi macro nahi")
        else ToolResult.ok("Macros: ${macros.joinToString(", ")}")
    }

    fun runAgentTask(task: String, steps: Int): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.RUN_AGENT_TASK").apply {
            putExtra("task", task); putExtra("steps", steps)
        })
        return ToolResult.ok("Agent task shuru: \"$task\" — max $steps steps")
    }

    fun runMission(mission: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.RUN_MISSION").apply { putExtra("mission", mission) })
        return ToolResult.ok("Mission: \"$mission\"")
    }

    fun findTool(query: String): ToolResult {
        // Search tool names from ToolDispatcher
        val toolKeywords = mapOf(
            "call" to listOf("make_call", "answer_call", "end_call"),
            "message" to listOf("whatsapp_send_message", "send_sms"),
            "search" to listOf("web_search", "deep_research"),
            "photo" to listOf("take_photo", "generate_image"),
            "alarm" to listOf("set_alarm", "set_timer", "add_reminder"),
            "stock" to listOf("get_stock_quote", "get_portfolio"),
            "screen" to listOf("read_screen_text", "tap_text", "take_screenshot")
        )
        val q = query.lowercase()
        val matched = toolKeywords.entries.filter { it.key in q }.flatMap { it.value }
        return if (matched.isEmpty()) ToolResult.ok("\"$query\" ke liye koi tool nahi mila")
        else ToolResult.ok("Mil gaya: ${matched.joinToString(", ")}")
    }

    fun rememberAppName(name: String, packageName: String): ToolResult {
        val prefs = ctx.context.getSharedPreferences("maya_app_names", Context.MODE_PRIVATE)
        prefs.edit().putString(name.lowercase(), packageName).apply()
        return ToolResult.ok("Yaad kar liya — \"$name\" = $packageName")
    }

    suspend fun termuxRun(command: String): ToolResult = withContext(Dispatchers.IO) {
        val result = ctx.termux.exec(command)
        result?.let { ToolResult.ok(it.take(500)) }
            ?: ToolResult.err("Termux nahi mila — pehle install karo")
    }
}

// ═══════════════════════════════════════════════════════════
// PC LINK TOOLS
// ═══════════════════════════════════════════════════════════
class PcLinkTools(private val ctx: ToolContext) {
    fun callPc(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.PC_CALL"))
        return ToolResult.ok("PC ko call kar raha hoon")
    }

    fun endPcCall(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.PC_CALL_END"))
        return ToolResult.ok("PC call band")
    }

    fun askPcMaya(message: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.ASK_PC_MAYA").apply { putExtra("message", message) })
        return ToolResult.ok("PC Maya se pooch raha hoon")
    }

    fun pcControl(command: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.PC_CONTROL").apply { putExtra("command", command) })
        return ToolResult.ok("PC command: $command")
    }

    fun relayToPc(data: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.PC_RELAY").apply { putExtra("data", data) })
        return ToolResult.ok("PC pe relay kar diya")
    }

    fun startDuetCall(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.START_DUET_CALL"))
        return ToolResult.ok("Duet call shuru")
    }

    fun setListenMode(mode: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_LISTEN_MODE").apply { putExtra("mode", mode) })
        return ToolResult.ok("Listen mode: $mode")
    }

    fun setVoiceFilter(on: Boolean, profile: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_VOICE_FILTER").apply {
            putExtra("on", on); putExtra("profile", profile)
        })
        return ToolResult.ok(if (on) "Voice filter on: $profile" else "Voice filter off")
    }
}

// ═══════════════════════════════════════════════════════════
// SMART HOME TOOLS
// ═══════════════════════════════════════════════════════════
class SmartHomeTools(private val ctx: ToolContext) {
    fun listDevices(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SMART_HOME_LIST"))
        return ToolResult.ok("Smart home devices check kar raha hoon")
    }

    fun openBluetoothSettings(): ToolResult {
        ctx.context.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        return ToolResult.ok("Bluetooth settings khul gaye")
    }

    fun openWifiSettings(): ToolResult {
        ctx.context.startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        return ToolResult.ok("WiFi settings khul gaye")
    }
}

// ═══════════════════════════════════════════════════════════
// PERSONA TOOLS
// ═══════════════════════════════════════════════════════════
class PersonaTools(private val ctx: ToolContext) {
    fun switchPersona(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SWITCH_PERSONA").apply { putExtra("name", name) })
        return ToolResult.ok("Persona switch: $name")
    }

    fun getPersonas(): ToolResult =
        ToolResult.ok("Personas: Maya (default), Friday (formal), Venom (dark), Jarvis (classic)")

    fun setIntimacy(level: Int): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SET_INTIMACY").apply { putExtra("level", level) })
        return ToolResult.ok("Intimacy level: $level")
    }

    fun installSkill(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.INSTALL_SKILL").apply { putExtra("name", name) })
        return ToolResult.ok("Skill install ho rahi hai: $name")
    }

    fun uninstallSkill(name: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.UNINSTALL_SKILL").apply { putExtra("name", name) })
        return ToolResult.ok("Skill remove: $name")
    }

    fun listSkills(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.LIST_SKILLS"))
        return ToolResult.ok("Skills list aa rahi hai")
    }

    fun createSkill(name: String, description: String, trigger: String, action: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.CREATE_SKILL").apply {
            putExtra("name", name); putExtra("description", description)
            putExtra("trigger", trigger); putExtra("action", action)
        })
        return ToolResult.ok("Skill create: \"$name\"")
    }

    fun openWhiteboard(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.OPEN_WHITEBOARD"))
        return ToolResult.ok("Whiteboard khul gaya")
    }

    fun whiteboardTeach(topic: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.WHITEBOARD_TEACH").apply { putExtra("topic", topic) })
        return ToolResult.ok("Whiteboard pe samjha rahi hoon: $topic")
    }

    fun whiteboardClear(): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.WHITEBOARD_CLEAR"))
        return ToolResult.ok("Whiteboard clear")
    }
}

// ═══════════════════════════════════════════════════════════
// FILE & CONTACT TOOLS
// ═══════════════════════════════════════════════════════════
class FileTools(private val ctx: ToolContext) {
    private val prefs get() = ctx.context.getSharedPreferences("maya_favorites", Context.MODE_PRIVATE)

    fun findFiles(query: String, type: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.FIND_FILES").apply {
            putExtra("query", query); putExtra("type", type)
        })
        return ToolResult.ok("Files search: \"$query\"")
    }

    fun deleteFile(path: String): ToolResult {
        val f = File(path)
        return if (f.exists() && f.delete()) ToolResult.ok("File delete: $path")
        else ToolResult.err("File nahi mili ya delete nahi hui")
    }

    fun shareFile(path: String, target: String): ToolResult {
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SHARE_FILE").apply {
            putExtra("path", path); putExtra("target", target)
        })
        return ToolResult.ok("File share ho rahi hai")
    }

    fun openFile(path: String): ToolResult {
        val f = File(path)
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx.context, "${ctx.context.packageName}.provider", f)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, ctx.context.contentResolver.getType(uri) ?: "*/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            ctx.context.startActivity(intent)
            ToolResult.ok("File khul gayi")
        } catch (e: Exception) {
            ToolResult.err("File nahi khuli: ${e.message}")
        }
    }

    fun openUrl(url: String): ToolResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("Browser mein khul gaya")
    }

    fun findContact(name: String): ToolResult {
        val cursor = ctx.context.contentResolver.query(
            Uri.withAppendedPath(android.provider.ContactsContract.Contacts.CONTENT_FILTER_URI, Uri.encode(name)),
            arrayOf(android.provider.ContactsContract.Contacts.DISPLAY_NAME,
                    android.provider.ContactsContract.Contacts._ID),
            null, null, null
        )
        val results = mutableListOf<String>()
        cursor?.use {
            while (it.moveToNext() && results.size < 5) {
                results.add(it.getString(0))
            }
        }
        return if (results.isEmpty()) ToolResult.err("\"$name\" contacts mein nahi mila")
        else ToolResult.ok("Contacts: ${results.joinToString(", ")}")
    }

    fun findEmail(name: String): ToolResult {
        val cursor = ctx.context.contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Email.ADDRESS,
                    android.provider.ContactsContract.CommonDataKinds.Email.DISPLAY_NAME),
            "${android.provider.ContactsContract.CommonDataKinds.Email.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )
        val emails = mutableListOf<String>()
        cursor?.use {
            while (it.moveToNext() && emails.size < 3) {
                emails.add("${it.getString(1)}: ${it.getString(0)}")
            }
        }
        return if (emails.isEmpty()) ToolResult.err("$name ki email nahi mili")
        else ToolResult.ok(emails.joinToString("\n"))
    }

    fun saveContact(name: String, phone: String, email: String): ToolResult {
        val intent = Intent(android.provider.ContactsContract.Intents.Insert.ACTION).apply {
            type = android.provider.ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(android.provider.ContactsContract.Intents.Insert.NAME, name)
            putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, phone)
            putExtra(android.provider.ContactsContract.Intents.Insert.EMAIL, email)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.context.startActivity(intent)
        return ToolResult.ok("Contact save ho raha hai: $name")
    }

    fun addFavorite(name: String, value: String, type: String): ToolResult {
        prefs.edit().putString("fav_${name}", JSONObject().apply {
            put("name", name); put("value", value); put("type", type)
        }.toString()).apply()
        return ToolResult.ok("Favorite add: $name")
    }

    fun removeFavorite(name: String): ToolResult {
        prefs.edit().remove("fav_$name").apply()
        return ToolResult.ok("Favorite remove: $name")
    }

    fun listFavorites(): ToolResult {
        val favs = prefs.all.filter { it.key.startsWith("fav_") }
            .mapNotNull { JSONObject(it.value.toString()) }
        return if (favs.isEmpty()) ToolResult.ok("Koi favorite nahi")
        else ToolResult.ok(favs.joinToString("\n") { "• ${it.optString("name")}: ${it.optString("value")}" })
    }
}
