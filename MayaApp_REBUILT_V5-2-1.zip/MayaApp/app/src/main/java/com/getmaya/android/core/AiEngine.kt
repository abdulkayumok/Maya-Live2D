package com.getmaya.android.core

import com.getmaya.android.data.models.AiProvider
import com.getmaya.android.data.models.MayaPersonaConfig
import com.getmaya.android.data.models.MayaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

// ═══════════════════════════════════════════════════════════
// AI ENGINE — Multi-provider with automatic fallback
// Extracted from APK strings + architecture analysis
//
// Priority chain (extracted from DEX):
// User API key → Gemini Free → rate-limit fallback → error
//
// Providers: Gemini, Groq, Anthropic, OpenAI, DeepSeek,
//            NVIDIA NIM, Together, Mistral, OpenRouter,
//            DeepInfra, Custom
// ═══════════════════════════════════════════════════════════

class AiEngine(
    private val settings: MayaSettings,
    private val persona: MayaPersonaConfig
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("User-Agent", "MayaAndroid/5.2.9")
                    .build()
            )
        }
        .build()

    // Conversation history (in-memory, full context each call)
    private val history = mutableListOf<ChatMessage>()

    // ── Main chat method ───────────────────────────────────
    suspend fun chat(userMessage: String): String = withContext(Dispatchers.IO) {
        history.add(ChatMessage("user", userMessage))

        val response = tryProviders(buildMessages())
        history.add(ChatMessage("assistant", response))
        response
    }

    private fun buildMessages(): List<ChatMessage> {
        val sysMsg = ChatMessage("system", persona.systemPrompt + buildContextAdditions())
        return listOf(sysMsg) + history
    }

    private fun buildContextAdditions(): String {
        return buildString {
            // Memory / wiki context injected here
            // Business profile injected here
            // Persona-specific additions
            if (settings.girlfriendMode) append("\n[GIRLFRIEND MODE: ON]")
            if (settings.rRatedMode && settings.ageVerified) append("\n[R-RATED MODE: ON — age verified]")
            if (settings.godMode) append("\n[GOD MODE ON]")
        }
    }

    // ── Provider fallback chain ────────────────────────────
    private suspend fun tryProviders(messages: List<ChatMessage>): String {
        // 1. Try configured provider
        runCatching { callProvider(settings.aiProvider, messages) }
            .onSuccess { return it }

        // 2. Fallback to Gemini free
        if (settings.aiProvider != AiProvider.GEMINI_FREE) {
            runCatching { callGeminiFree(messages) }
                .onSuccess { return it }
        }

        return "Maya ruk gayi — API key check karo, phir mic dabao."
    }

    private suspend fun callProvider(provider: AiProvider, messages: List<ChatMessage>): String {
        return when (provider) {
            AiProvider.GEMINI_FREE  -> callGeminiFree(messages)
            AiProvider.GROQ         -> callOpenAiCompatible(
                "https://api.groq.com/openai/v1/chat/completions",
                settings.groqApiKey, "llama-3.3-70b-versatile", messages)
            AiProvider.ANTHROPIC    -> callAnthropic(messages)
            AiProvider.OPENAI       -> callOpenAiCompatible(
                "https://api.openai.com/v1/chat/completions",
                settings.openAiApiKey, "gpt-4o-mini", messages)
            AiProvider.DEEPSEEK     -> callOpenAiCompatible(
                "https://api.deepseek.com/v1/chat/completions",
                settings.deepseekApiKey, "deepseek-chat", messages)
            AiProvider.NVIDIA       -> callOpenAiCompatible(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                settings.nvidiaApiKey, "nvidia/llama-3.1-nemotron-70b-instruct", messages)
            AiProvider.TOGETHER     -> callOpenAiCompatible(
                "https://api.together.xyz/v1/chat/completions",
                settings.togetherApiKey, "meta-llama/Llama-3.3-70B-Instruct-Turbo", messages)
            AiProvider.MISTRAL      -> callOpenAiCompatible(
                "https://api.mistral.ai/v1/chat/completions",
                settings.mistralApiKey, "mistral-small-latest", messages)
            AiProvider.OPENROUTER   -> callOpenAiCompatible(
                "https://openrouter.ai/api/v1/chat/completions",
                settings.openRouterApiKey, "openai/gpt-4o-mini", messages)
            AiProvider.DEEPINFRA    -> callOpenAiCompatible(
                "https://api.deepinfra.com/v1/openai/chat/completions",
                settings.openRouterApiKey, "meta-llama/Meta-Llama-3.1-70B-Instruct", messages)
            AiProvider.CUSTOM       -> callOpenAiCompatible(
                "${settings.customEndpointUrl}/chat/completions",
                "", settings.customEndpointTag, messages)
        }
    }

    // ── Gemini Free (WebSocket BidiGenerateContent) ────────
    private suspend fun callGeminiFree(messages: List<ChatMessage>): String {
        // Try newest Flash models first, auto-switch on rate limit
        val models = listOf(
            "models/gemini-3.8-live",
            "models/gemini-3.1-flash-live-preview",
            "models/gemini-flash-latest"
        )
        val key = settings.geminiApiKey
        val baseUrl = "https://generativelanguage.googleapis.com/v1beta"

        for (model in models) {
            runCatching {
                val body = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        messages.filter { it.role != "system" }.forEach { msg ->
                            put(JSONObject().apply {
                                put("role", if (msg.role == "user") "user" else "model")
                                put("parts", JSONArray().put(JSONObject().put("text", msg.content)))
                            })
                        }
                    })
                    // System instruction
                    messages.firstOrNull { it.role == "system" }?.let { sys ->
                        put("system_instruction", JSONObject().apply {
                            put("parts", JSONArray().put(JSONObject().put("text", sys.content)))
                        })
                    }
                }

                val req = Request.Builder()
                    .url("$baseUrl/$model:generateContent?key=$key")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    val json = JSONObject(resp.body!!.string())
                    json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                }
            }.onSuccess { return it }
            // Rate limited → try next model
        }
        throw IOException("All Gemini models exhausted")
    }

    // ── Anthropic Claude ───────────────────────────────────
    private suspend fun callAnthropic(messages: List<ChatMessage>): String {
        val sysPrompt = messages.firstOrNull { it.role == "system" }?.content ?: ""
        val userMessages = messages.filter { it.role != "system" }

        // Cheapest Claude model first, then sonnet
        val model = if (settings.codingModel.isEmpty()) "claude-haiku-4-5" else settings.codingModel

        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1000)
            put("system", sysPrompt)
            put("messages", JSONArray().apply {
                userMessages.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            })
        }

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("x-api-key", settings.anthropicApiKey)
            .header("anthropic-version", "2023-06-01")
            .build()

        return http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Anthropic HTTP ${resp.code}")
            JSONObject(resp.body!!.string())
                .getJSONArray("content")
                .getJSONObject(0)
                .getString("text")
        }
    }

    // ── OpenAI-compatible (Groq, DeepSeek, NVIDIA, etc.) ──
    private suspend fun callOpenAiCompatible(
        url: String,
        apiKey: String,
        model: String,
        messages: List<ChatMessage>
    ): String {
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1000)
            put("messages", JSONArray().apply {
                messages.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            })
        }

        val req = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .apply { if (apiKey.isNotEmpty()) header("Authorization", "Bearer $apiKey") }
            .build()

        return http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            JSONObject(resp.body!!.string())
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    // ── History management ─────────────────────────────────
    fun clearHistory() { history.clear() }

    fun getHistory(): List<ChatMessage> = history.toList()
}

data class ChatMessage(val role: String, val content: String)

    // ── Chat with tool-call support ────────────────────────
    // Returns either plain text or JSON: {"tool":"...","params":{...}}
    suspend fun chatWithTools(userMessage: String, memoryContext: String): String {
        val systemWithMemory = if (memoryContext.isNotEmpty())
            persona.systemPrompt + "\n" + memoryContext
        else persona.systemPrompt

        history.add(ChatMessage("user", userMessage))
        val messages = listOf(ChatMessage("system", systemWithMemory)) + history
        val response = tryProviders(messages)
        history.add(ChatMessage("assistant", response))
        return response
    }

    // ── Vision: analyze image file ─────────────────────────
    suspend fun analyzeImage(imagePath: String): String = withContext(Dispatchers.IO) {
        // Encode image to base64 and send to vision-capable model
        val file = java.io.File(imagePath)
        if (!file.exists()) return@withContext "Image file nahi mili"
        val bytes = file.readBytes()
        val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        val mimeType = if (imagePath.endsWith(".png")) "image/png" else "image/jpeg"

        // Use Gemini vision
        val body = org.json.JSONObject().apply {
            put("contents", org.json.JSONArray().put(
                org.json.JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(org.json.JSONObject().put("text", "Yeh image mein kya hai? Briefly batao."))
                        put(org.json.JSONObject().apply {
                            put("inline_data", org.json.JSONObject().apply {
                                put("mime_type", mimeType)
                                put("data", b64)
                            })
                        })
                    })
                }
            ))
        }
        val key = settings.geminiApiKey
        if (key.isEmpty()) return@withContext "Gemini API key set karo vision ke liye"

        return@withContext try {
            val req = okhttp3.Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$key")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use "Vision error: ${resp.code}"
                val json = org.json.JSONObject(resp.body!!.string())
                json.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text")
            }
        } catch (e: Exception) { "Image analyze nahi ho payi: ${e.message}" }
    }
