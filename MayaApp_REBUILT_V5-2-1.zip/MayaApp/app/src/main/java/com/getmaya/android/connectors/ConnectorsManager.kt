package com.getmaya.android.connectors

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// CONNECTORS MANAGER — all external integrations
// Extracted from APK strings
//
// Google Drive / GitHub / GitLab / Notion / Todoist /
// Linear / Vercel / Telegram / WhatsApp / n8n / Make
// ═══════════════════════════════════════════════════════════

class ConnectorsManager(private val context: Context) {

    private val http = OkHttpClient()

    // ══════════════════════════════════════════════════════
    // GOOGLE DRIVE
    // Client ID: 994106688046-mc0kjd0u5no7kl1sndvam504a0uhalur
    // ══════════════════════════════════════════════════════

    inner class GoogleDrive(private val accessToken: String) {

        suspend fun listFiles(query: String = ""): JSONArray = withContext(Dispatchers.IO) {
            val q = if (query.isEmpty()) "" else "&q=${query.encodeUrl()}"
            get("https://www.googleapis.com/drive/v3/files?fields=files(id,name,mimeType,modifiedTime)$q")
                .getJSONArray("files")
        }

        suspend fun readFile(fileId: String): String = withContext(Dispatchers.IO) {
            // Get text content of file
            getRaw("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
        }

        suspend fun uploadFile(name: String, content: String, mimeType: String = "text/plain"): JSONObject = withContext(Dispatchers.IO) {
            // Multipart upload
            val metadata = JSONObject().put("name", name).toString()
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("metadata", null,
                    metadata.toRequestBody("application/json".toMediaType()))
                .addFormDataPart("file", name,
                    content.toRequestBody(mimeType.toMediaType()))
                .build()
            val req = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .post(body)
                .header("Authorization", "Bearer $accessToken")
                .build()
            JSONObject(http.newCall(req).execute().use { it.body!!.string() })
        }

        suspend fun about(): JSONObject = withContext(Dispatchers.IO) {
            get("https://www.googleapis.com/drive/v3/about?fields=user,storageQuota")
        }

        private fun get(url: String) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .header("Authorization", "Bearer $accessToken").build())
                .execute().use { it.body!!.string() }
        )
        private fun getRaw(url: String) = http.newCall(
            Request.Builder().url(url)
                .header("Authorization", "Bearer $accessToken").build()
        ).execute().use { it.body!!.string() }
    }

    // ══════════════════════════════════════════════════════
    // GITHUB — Fine-grained personal access token
    // ══════════════════════════════════════════════════════

    inner class GitHub(private val token: String) {

        suspend fun listRepos(): JSONArray = withContext(Dispatchers.IO) {
            getArr("https://api.github.com/user/repos?sort=updated&per_page=30")
        }

        suspend fun getUser(): JSONObject = withContext(Dispatchers.IO) {
            get("https://api.github.com/user")
        }

        suspend fun readFile(owner: String, repo: String, path: String): String = withContext(Dispatchers.IO) {
            val res = get("https://api.github.com/repos/$owner/$repo/contents/$path")
            val encoded = res.getString("content").replace("\n", "")
            String(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT))
        }

        suspend fun writeFile(
            owner: String, repo: String, path: String,
            content: String, message: String, sha: String = ""
        ): JSONObject = withContext(Dispatchers.IO) {
            val encoded = android.util.Base64.encodeToString(content.toByteArray(), android.util.Base64.NO_WRAP)
            val body = JSONObject().apply {
                put("message", message)
                put("content", encoded)
                if (sha.isNotEmpty()) put("sha", sha)
            }
            put("https://api.github.com/repos/$owner/$repo/contents/$path", body)
        }

        // Maya Skills repo
        suspend fun listSkills(): JSONArray = withContext(Dispatchers.IO) {
            getArr("https://api.github.com/repos/HunterisLive-1/mobile-maya-skills/contents/")
        }

        private fun get(url: String) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/vnd.github.v3+json").build())
                .execute().use { it.body!!.string() }
        )
        private fun getArr(url: String) = JSONArray(
            http.newCall(Request.Builder().url(url)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/vnd.github.v3+json").build())
                .execute().use { it.body!!.string() }
        )
        private fun put(url: String, body: JSONObject) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .put(body.toString().toRequestBody("application/json".toMediaType()))
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/vnd.github.v3+json").build())
                .execute().use { it.body!!.string() }
        )
    }

    // ══════════════════════════════════════════════════════
    // NOTION — Integration token
    // ══════════════════════════════════════════════════════

    inner class Notion(private val token: String) {

        suspend fun search(query: String): JSONObject = withContext(Dispatchers.IO) {
            post("https://api.notion.com/v1/search",
                JSONObject().put("query", query))
        }

        suspend fun getPage(pageId: String): JSONObject = withContext(Dispatchers.IO) {
            get("https://api.notion.com/v1/pages/$pageId")
        }

        suspend fun getBlocks(blockId: String): JSONObject = withContext(Dispatchers.IO) {
            get("https://api.notion.com/v1/blocks/$blockId/children")
        }

        suspend fun appendBlocks(blockId: String, blocks: JSONArray): JSONObject = withContext(Dispatchers.IO) {
            patch("https://api.notion.com/v1/blocks/$blockId/children",
                JSONObject().put("children", blocks))
        }

        suspend fun createPage(parentId: String, title: String, content: String): JSONObject = withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("parent", JSONObject().put("page_id", parentId))
                put("properties", JSONObject().put("title",
                    JSONObject().put("title", JSONArray().put(
                        JSONObject().put("text", JSONObject().put("content", title))
                    ))
                ))
                put("children", JSONArray().put(
                    JSONObject().apply {
                        put("object", "block")
                        put("type", "paragraph")
                        put("paragraph", JSONObject().put("rich_text", JSONArray().put(
                            JSONObject().put("text", JSONObject().put("content", content))
                        )))
                    }
                ))
            }
            post("https://api.notion.com/v1/pages", body)
        }

        private val headers = mapOf(
            "Authorization" to "Bearer $token",
            "Notion-Version" to "2022-06-28",
            "Content-Type" to "application/json"
        )
        private fun get(url: String) = JSONObject(
            http.newCall(Request.Builder().url(url).apply {
                headers.forEach { (k,v) -> header(k, v) }
            }.build()).execute().use { it.body!!.string() }
        )
        private fun post(url: String, body: JSONObject) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .apply { headers.forEach { (k,v) -> header(k, v) } }.build())
                .execute().use { it.body!!.string() }
        )
        private fun patch(url: String, body: JSONObject) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .patch(body.toString().toRequestBody("application/json".toMediaType()))
                .apply { headers.forEach { (k,v) -> header(k, v) } }.build())
                .execute().use { it.body!!.string() }
        )
    }

    // ══════════════════════════════════════════════════════
    // TODOIST
    // ══════════════════════════════════════════════════════

    inner class Todoist(private val token: String) {

        suspend fun getTasks(filter: String = ""): JSONArray = withContext(Dispatchers.IO) {
            val url = "https://api.todoist.com/rest/v2/tasks" +
                if (filter.isNotEmpty()) "?filter=${filter.encodeUrl()}" else ""
            JSONArray(http.newCall(Request.Builder().url(url)
                .header("Authorization", "Bearer $token").build())
                .execute().use { it.body!!.string() })
        }

        suspend fun addTask(content: String, dueString: String = "", projectId: String = ""): JSONObject = withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("content", content)
                if (dueString.isNotEmpty()) put("due_string", dueString)
                if (projectId.isNotEmpty()) put("project_id", projectId)
            }
            JSONObject(http.newCall(Request.Builder()
                .url("https://api.todoist.com/rest/v2/tasks")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .header("Authorization", "Bearer $token").build())
                .execute().use { it.body!!.string() })
        }

        suspend fun completeTask(taskId: String) = withContext(Dispatchers.IO) {
            http.newCall(Request.Builder()
                .url("https://api.todoist.com/rest/v2/tasks/$taskId/close")
                .post("{}".toRequestBody("application/json".toMediaType()))
                .header("Authorization", "Bearer $token").build())
                .execute().close()
        }

        suspend fun getProjects(): JSONArray = withContext(Dispatchers.IO) {
            JSONArray(http.newCall(Request.Builder()
                .url("https://api.todoist.com/rest/v2/projects")
                .header("Authorization", "Bearer $token").build())
                .execute().use { it.body!!.string() })
        }
    }

    // ══════════════════════════════════════════════════════
    // LINEAR — GraphQL
    // ══════════════════════════════════════════════════════

    inner class Linear(private val apiKey: String) {

        suspend fun getIssues(teamId: String = ""): JSONObject = withContext(Dispatchers.IO) {
            val q = if (teamId.isEmpty()) "{ issues { nodes { id title state { name } priority } } }"
            else "{ team(id: \"$teamId\") { issues { nodes { id title state { name } } } } }"
            graphql(q)
        }

        suspend fun createIssue(title: String, teamId: String, desc: String = ""): JSONObject = withContext(Dispatchers.IO) {
            graphql("mutation { issueCreate(input: { title: \"$title\" teamId: \"$teamId\" description: \"$desc\" }) { success issue { id title } } }")
        }

        private fun graphql(query: String) = JSONObject(
            http.newCall(Request.Builder()
                .url("https://api.linear.app/graphql")
                .post(JSONObject().put("query", query).toString()
                    .toRequestBody("application/json".toMediaType()))
                .header("Authorization", apiKey)
                .header("Content-Type", "application/json").build())
                .execute().use { it.body!!.string() }
        )
    }

    // ══════════════════════════════════════════════════════
    // VERCEL
    // ══════════════════════════════════════════════════════

    inner class Vercel(private val token: String) {

        suspend fun listProjects(): JSONObject = withContext(Dispatchers.IO) {
            get("https://api.vercel.com/v9/projects")
        }

        suspend fun listDeployments(projectId: String): JSONObject = withContext(Dispatchers.IO) {
            get("https://api.vercel.com/v13/deployments?projectId=$projectId")
        }

        private fun get(url: String) = JSONObject(
            http.newCall(Request.Builder().url(url)
                .header("Authorization", "Bearer $token").build())
                .execute().use { it.body!!.string() }
        )
    }

    // ══════════════════════════════════════════════════════
    // TELEGRAM BOT
    // ══════════════════════════════════════════════════════

    inner class TelegramBot(private val botToken: String) {

        suspend fun sendMessage(chatId: String, text: String): JSONObject = withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("chat_id", chatId)
                put("text", text)
                put("parse_mode", "Markdown")
            }
            JSONObject(http.newCall(Request.Builder()
                .url("https://api.telegram.org/bot$botToken/sendMessage")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build())
                .execute().use { it.body!!.string() })
        }

        suspend fun getUpdates(offset: Long = 0): JSONObject = withContext(Dispatchers.IO) {
            JSONObject(http.newCall(Request.Builder()
                .url("https://api.telegram.org/bot$botToken/getUpdates?offset=$offset").build())
                .execute().use { it.body!!.string() })
        }
    }

    // ══════════════════════════════════════════════════════
    // WHATSAPP (via accessibility — no official API)
    // ══════════════════════════════════════════════════════

    inner class WhatsApp {

        fun openChat(contactName: String): Boolean {
            val acc = MayaAccessibilityService.instance ?: return false
            acc.openApp("com.whatsapp")
            // Navigate to search → type contact name → open chat
            return true
        }

        fun sendMessage(to: String, message: String): Boolean {
            // Use deep link: https://wa.me/$to?text=$message
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("https://wa.me/$to?text=${message.encodeUrl()}")
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try { context.startActivity(intent); true }
            catch (_: Exception) { false }
        }

        fun replyLatest(message: String): Boolean {
            val notifListener = MayaNotificationListener.instance ?: return false
            val pendingKey = MayaNotificationListener.pendingReplyActions.keys.lastOrNull() ?: return false
            return notifListener.replyWhatsApp(pendingKey, message)
        }
    }

    // ══════════════════════════════════════════════════════
    // WEBHOOK (n8n / Make / Zapier)
    // ══════════════════════════════════════════════════════

    suspend fun triggerWebhook(url: String, payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        JSONObject(http.newCall(Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody("application/json".toMediaType())).build())
            .execute().use { it.body!!.string().ifEmpty { "{\"ok\":true}" } })
    }

    // ── Helpers ───────────────────────────────────────────
    private fun String.encodeUrl() = java.net.URLEncoder.encode(this, "UTF-8")
}
