package com.getmaya.android.marketing

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.getmaya.android.core.AiEngine
import com.getmaya.android.data.models.MayaPersona
import com.getmaya.android.data.models.MayaSettings
import com.getmaya.android.data.models.PersonaRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.*

// ═══════════════════════════════════════════════════════════
// MARKETING ENGINE — extracted from APK strings
//
// Features (all from DEX strings):
// - Content calendar (posts, reels, carousels)
// - Daily trends
// - Weekly analytics
// - Follow-ups
// - SEO audit (PageSpeed + custom)
// - Review response generator
// - Landing page brief generator
// - n8n workflow generator
// - Competitor analysis
// - Ad campaign planning (Meta/Google)
// - Business profile management
// - Yahoo Finance market reads
// ═══════════════════════════════════════════════════════════

class MarketingEngine(private val context: Context, private val settings: MayaSettings) {

    private val scope  = CoroutineScope(Dispatchers.IO)
    private val http   = OkHttpClient()
    private val ai     = AiEngine(settings, PersonaRegistry.MAYA)

    // ══════════════════════════════════════════════════════
    // ALARMS — schedule daily/weekly triggers
    // ══════════════════════════════════════════════════════

    fun scheduleAll() {
        scheduleDailyStory()
        scheduleDailyTrends()
        scheduleWeeklyNumbers()
        scheduleFollowUps()
    }

    private fun scheduleDailyStory() {
        val cal = Calendar.getInstance().apply {
            val parts = settings.dailyStoryTime.split(":")
            set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.toIntOrNull() ?: 9)
            set(Calendar.MINUTE, parts.getOrNull(1)?.toIntOrNull() ?: 0)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_MONTH, 1)
        }
        scheduleAlarm("com.getmaya.android.social.DAILY_STORY", cal.timeInMillis, 1001)
    }

    private fun scheduleDailyTrends() {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 7); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_MONTH, 1)
        }
        scheduleAlarm("com.getmaya.android.marketing.DAILY_TRENDS", cal.timeInMillis, 1002)
    }

    private fun scheduleWeeklyNumbers() {
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0)
            if (before(Calendar.getInstance())) add(Calendar.WEEK_OF_YEAR, 1)
        }
        scheduleAlarm("com.getmaya.android.marketing.WEEKLY_NUMBERS", cal.timeInMillis, 1003)
    }

    private fun scheduleFollowUps() {
        scheduleAlarm("com.getmaya.android.marketing.FOLLOWUPS_DUE",
            System.currentTimeMillis() + 3600_000L, 1004)
    }

    private fun scheduleAlarm(action: String, triggerMs: Long, reqCode: Int) {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Explicit component avoids Android 8+ implicit-broadcast restrictions.
        val receiver = if (action.startsWith("com.getmaya.android.social.")) {
            SocialAlarmReceiver::class.java
        } else {
            MarketingAlarmReceiver::class.java
        }
        val broadcast = Intent(context, receiver).setAction(action)
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            broadcast,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmMgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMs, pi)
    }

    // ══════════════════════════════════════════════════════
    // CONTENT GENERATION
    // ══════════════════════════════════════════════════════

    suspend fun generatePost(
        businessName: String, topic: String, platform: String = "Instagram"
    ): String = ai.chat("""
        Business: $businessName
        Platform: $platform
        Topic: $topic
        
        Ek engaging post likho $platform ke liye.
        Hinglish allowed. Emojis use karo. Hashtags include karo.
        Call-to-action include karo.
        Max 2200 characters.
    """.trimIndent())

    suspend fun generateReelScript(
        businessName: String, topic: String, durationSec: Int = 30
    ): String = ai.chat("""
        Business: $businessName, Reel topic: $topic, Duration: ${durationSec}s
        
        Instagram Reel script banao:
        - Hook (first 3 seconds - must grab attention)
        - Main content points
        - Call to action
        - On-screen text suggestions
        - Background music mood
        
        Format: Second-by-second breakdown
    """.trimIndent())

    suspend fun generateCarousel(
        businessName: String, topic: String, slides: Int = 5
    ): String = ai.chat("""
        Business: $businessName, Topic: $topic, Slides: $slides
        
        Instagram carousel banao:
        Slide 1: Hook slide (title)
        Slides 2-${slides-1}: Content slides
        Slide $slides: CTA slide
        
        Har slide ke liye: Heading + 2-3 bullet points
    """.trimIndent())

    suspend fun respondToReview(review: String, rating: Int, businessName: String): String = ai.chat("""
        Business: $businessName
        Customer rating: $rating/5
        Review: "$review"
        
        Ek professional aur warm response likho.
        Agar negative: apologize + resolve karne ka promise.
        Agar positive: thank you + warmth.
        Max 150 words.
    """.trimIndent())

    suspend fun generateLandingPageBrief(businessName: String, product: String, targetAudience: String): String = ai.chat("""
        Business: $businessName
        Product/Service: $product
        Target audience: $targetAudience
        
        Landing page ka brief banao:
        - Hero headline + subheading
        - 3 key benefits
        - Social proof section
        - FAQ (3 questions)
        - CTA button text
        - Color scheme suggestion
    """.trimIndent())

    // ══════════════════════════════════════════════════════
    // SEO AUDIT — PageSpeed API + analysis
    // ══════════════════════════════════════════════════════

    suspend fun seoAudit(url: String, googleApiKey: String): String {
        val apiUrl = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${url}&key=${googleApiKey}&strategy=mobile"
        val raw = try {
            http.newCall(Request.Builder().url(apiUrl).build())
                .execute().use { it.body!!.string() }
        } catch (e: Exception) {
            return "PageSpeed fetch failed: ${e.message}"
        }

        val json = JSONObject(raw)
        val lhResult = json.optJSONObject("lighthouseResult") ?: return "Invalid response"
        val cats = lhResult.optJSONObject("categories")
        val perf = cats?.optJSONObject("performance")?.optDouble("score", 0.0)?.times(100)?.toInt()
        val seo  = cats?.optJSONObject("seo")?.optDouble("score", 0.0)?.times(100)?.toInt()
        val acc  = cats?.optJSONObject("accessibility")?.optDouble("score", 0.0)?.times(100)?.toInt()

        val audits = lhResult.optJSONObject("audits")
        val title       = audits?.optJSONObject("document-title")?.optString("displayValue") ?: ""
        val description = audits?.optJSONObject("meta-description")?.optString("displayValue") ?: ""
        val lcp         = audits?.optJSONObject("largest-contentful-paint")?.optString("displayValue") ?: ""
        val fid         = audits?.optJSONObject("first-input-delay")?.optString("displayValue") ?: ""
        val cls         = audits?.optJSONObject("cumulative-layout-shift")?.optString("displayValue") ?: ""

        val facts = """
            URL: $url
            Performance: $perf/100
            SEO Score: $seo/100
            Accessibility: $acc/100
            LCP: $lcp | FID: $fid | CLS: $cls
            Title: $title
            Meta description: $description
        """.trimIndent()

        return ai.chat("""
            You are an SEO consultant for small Indian businesses.
            Given MEASURED facts about one web page. Suggest fixes.
            At most 8 short lines, each starting with '- ', in simple Hinglish.
            Where title or meta description is weak, WRITE the replacement.
            (title <= 60 chars, description <= 155)
            Most important first. No invented facts.
            
            FACTS:
            $facts
        """.trimIndent())
    }

    // ══════════════════════════════════════════════════════
    // MARKET ANALYSIS — Yahoo Finance
    // ══════════════════════════════════════════════════════

    suspend fun marketRead(symbols: List<String>): String {
        val quotes = symbols.map { symbol ->
            try {
                val url = "https://query1.finance.yahoo.com/v8/finance/chart/$symbol?interval=1d&range=5d"
                val raw = http.newCall(Request.Builder().url(url).build())
                    .execute().use { it.body!!.string() }
                val chart = JSONObject(raw).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
                val meta = chart.getJSONObject("meta")
                "$symbol: ₹${meta.optDouble("regularMarketPrice")} (${meta.optDouble("regularMarketChangePercent", 0.0).let { if(it>0) "+${"%.2f".format(it)}" else "${"%.2f".format(it)}" }}%)"
            } catch (_: Exception) { "$symbol: fetch failed" }
        }.joinToString("\n")

        return ai.chat("""
            You are Maya writing up a market read for her user.
            Sections: Ab kya haal hai, Chart kya keh raha hai, Khabrein, Business, Risk aur bear case, Levels jo dekhne layak hain
            
            HARD BANS: never write buy, sell, hold, kharido, becho, 'target', 'guaranteed', or any recommendation.
            Never predict a price.
            
            Current quotes:
            $quotes
        """.trimIndent())
    }

    // ══════════════════════════════════════════════════════
    // N8N WORKFLOW GENERATOR
    // ══════════════════════════════════════════════════════

    suspend fun generateN8nWorkflow(description: String): String = ai.chat("""
        You generate n8n workflow JSON that can be imported with "Import from File".
        Reply with ONLY one JSON object.
        Shape: {name, nodes, connections, active, settings}
        Node: {id, name, type, typeVersion, position, parameters}
        
        Rules:
        - Exactly one trigger node first
        - Every node reachable from trigger
        - Anything that PUBLISHES publicly or messages a customer must have manual approval step before it
        - Keep under 14 nodes
        - No credentials, API keys or real phone numbers in parameters
        
        Workflow to create: $description
    """.trimIndent())

    // ══════════════════════════════════════════════════════
    // COMPETITOR ANALYSIS
    // ══════════════════════════════════════════════════════

    suspend fun competitorAnalysis(competitors: List<String>, businessType: String): String = ai.chat("""
        You are a marketing strategist for small Indian businesses.
        Business type: $businessType
        Competitors to analyze: ${competitors.joinToString(", ")}
        
        Reply:
        ## Common services and keywords
        ## Their messaging angles
        ## Content gaps
        ## How to be different
        
        Use only general knowledge about these businesses. No invented prices or market share.
    """.trimIndent())
}

// MarketingAlarmReceiver → com/getmaya/android/marketing/MarketingAlarmReceiver.kt
// SocialAlarmReceiver    → com/getmaya/android/social/SocialAlarmReceiver.kt
