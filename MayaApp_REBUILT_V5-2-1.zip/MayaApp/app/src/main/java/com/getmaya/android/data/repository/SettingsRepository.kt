package com.getmaya.android.data.repository

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.getmaya.android.data.models.*
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// SETTINGS REPOSITORY — EncryptedSharedPreferences storage
// API keys stored encrypted (Android Keystore-backed)
// Device-bound — cannot be extracted without root
// ═══════════════════════════════════════════════════════════

class SettingsRepository(private val context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context, "maya_settings_secure", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // ── Save ──────────────────────────────────────────────
    fun save(s: MayaSettings) {
        prefs.edit().apply {
            putString("user_name", s.userName)
            putString("user_gender", s.userGender)
            putString("gemini_api_key", s.geminiApiKey)
            putString("default_persona", s.defaultPersona)
            putInt("persona_switch_delay", s.personaSwitchDelaySec)

            // AI Engine
            putString("ai_provider", s.aiProvider.key)
            putString("coding_model", s.codingModel)
            putString("vision_model", s.visionModel)
            putString("groq_api_key", s.groqApiKey)
            putString("anthropic_api_key", s.anthropicApiKey)
            putString("openrouter_api_key", s.openRouterApiKey)
            putString("openai_api_key", s.openAiApiKey)
            putString("deepseek_api_key", s.deepseekApiKey)
            putString("nvidia_api_key", s.nvidiaApiKey)
            putString("together_api_key", s.togetherApiKey)
            putString("mistral_api_key", s.mistralApiKey)
            putString("custom_endpoint_url", s.customEndpointUrl)
            putString("custom_endpoint_tag", s.customEndpointTag)
            putString("custom_endpoint_name", s.customEndpointName)

            // Voice
            putString("deepgram_api_key", s.deepgramApiKey)
            putBoolean("hello_maya", s.helloMaya)
            putBoolean("wake_up_maya", s.wakeUpMaya)
            putBoolean("emotive_mode", s.emotiveMode)

            // Avatar
            putString("avatar_character", s.avatarCharacter)
            putString("overlay_character", s.overlayCharacter)
            putString("wallpaper_character", s.wallpaperCharacter)
            putInt("character_size_dp", s.characterSizeDp)
            putBoolean("avatar_on_low_ram", s.avatarOnLowRam)
            putString("blend_mode", s.blendMode)

            // Intimacy
            putBoolean("girlfriend_mode", s.girlfriendMode)
            putBoolean("r_rated_mode", s.rRatedMode)
            putBoolean("age_verified", s.ageVerified)
            putBoolean("conversation_mode", s.conversationMode)

            // Voice Guardian
            putBoolean("guardian_enabled", s.guardianEnabled)
            putString("guardian_model_id", s.guardianModelId)
            putString("listen_mode", s.listenMode.key)
            putBoolean("god_mode", s.godMode)
            putBoolean("away_mode", s.awayMode)

            // Face Lock
            putBoolean("maya_face_lock", s.faceLockEnabled)
            putBoolean("watchman_mode", s.watchmanMode)
            putBoolean("stealth_mode", s.stealthMode)

            // Audio
            putBoolean("earpiece_mode", s.earpieceMode)
            putBoolean("audio_media_mode", s.mediaMode)
            putBoolean("ignore_dnd", s.ignoreDoNotDisturb)

            // System
            putBoolean("keep_alive", s.keepAlive)
            putBoolean("maya_battery_saver", s.batterySaver)
            putBoolean("proactive_mode", s.proactiveMode)
            putBoolean("send_unrecognized", s.sendUnrecognized)
            putBoolean("maya_driving_mode", s.drivingModeEnabled)

            // Email
            putString("email_address", s.emailAddress)
            putString("email_password", s.emailPassword)
            putString("email_smtp_host", s.emailSmtpHost)
            putInt("email_smtp_port", s.emailSmtpPort)
            putString("email_signature", s.emailSignature)

            // Image gen
            putString("image_provider", s.imageProvider.key)
            putString("image_model_id", s.imageModelId)
            putString("image_api_key", s.imageApiKey)

            // Sites
            putBoolean("maya_sites_plan", s.mayaSitesPlanActive)

            // Sync
            putString("maya_home_box_id", s.mayaHomeBoxId)
            putString("maya_home_password", s.mayaHomePassword)

            // Marketing
            putBoolean("daily_story_enabled", s.dailyStoryEnabled)
            putString("daily_story_time", s.dailyStoryTime)
            putBoolean("auto_post_enabled", s.autoPostEnabled)

            // Search
            putString("brave_api_key", s.braveApiKey)
            putString("tavily_api_key", s.tavilyApiKey)
            putString("serp_api_key", s.serpApiKey)
            putString("google_places_api_key", s.googlePlacesApiKey)

            // Notifications
            putBoolean("call_announcer", s.callAnnouncer)
            putBoolean("announce_battery_full", s.announceBatteryFull)
            putBoolean("announce_battery_low", s.announceBatteryLow)
            putBoolean("announce_charger", s.announceCharger)
            putBoolean("announce_airplane_mode", s.announceAirplaneMode)

            // Pro
            putBoolean("pro_max_active", s.proMaxActive)
            putBoolean("auto_update", s.autoUpdate)
        }.apply()
    }

    // ── Load ──────────────────────────────────────────────
    fun load(): MayaSettings = MayaSettings(
        userName        = prefs.getString("user_name", "") ?: "",
        userGender      = prefs.getString("user_gender", "prefer_not") ?: "prefer_not",
        geminiApiKey    = prefs.getString("gemini_api_key", "") ?: "",
        defaultPersona  = prefs.getString("default_persona", "maya") ?: "maya",
        personaSwitchDelaySec = prefs.getInt("persona_switch_delay", 3),

        aiProvider      = AiProvider.values().firstOrNull { it.key == prefs.getString("ai_provider", "gemini_free") } ?: AiProvider.GEMINI_FREE,
        codingModel     = prefs.getString("coding_model", "") ?: "",
        visionModel     = prefs.getString("vision_model", "") ?: "",
        groqApiKey      = prefs.getString("groq_api_key", "") ?: "",
        anthropicApiKey = prefs.getString("anthropic_api_key", "") ?: "",
        openRouterApiKey = prefs.getString("openrouter_api_key", "") ?: "",
        openAiApiKey    = prefs.getString("openai_api_key", "") ?: "",
        deepseekApiKey  = prefs.getString("deepseek_api_key", "") ?: "",
        nvidiaApiKey    = prefs.getString("nvidia_api_key", "") ?: "",
        togetherApiKey  = prefs.getString("together_api_key", "") ?: "",
        mistralApiKey   = prefs.getString("mistral_api_key", "") ?: "",
        customEndpointUrl  = prefs.getString("custom_endpoint_url", "") ?: "",
        customEndpointTag  = prefs.getString("custom_endpoint_tag", "") ?: "",
        customEndpointName = prefs.getString("custom_endpoint_name", "") ?: "",

        deepgramApiKey  = prefs.getString("deepgram_api_key", "") ?: "",
        helloMaya       = prefs.getBoolean("hello_maya", true),
        wakeUpMaya      = prefs.getBoolean("wake_up_maya", false),
        emotiveMode     = prefs.getBoolean("emotive_mode", false),

        avatarCharacter    = prefs.getString("avatar_character", "maya") ?: "maya",
        overlayCharacter   = prefs.getString("overlay_character", "maya") ?: "maya",
        wallpaperCharacter = prefs.getString("wallpaper_character", "") ?: "",
        characterSizeDp    = prefs.getInt("character_size_dp", 200),
        avatarOnLowRam     = prefs.getBoolean("avatar_on_low_ram", false),
        blendMode          = prefs.getString("blend_mode", "normal") ?: "normal",

        girlfriendMode  = prefs.getBoolean("girlfriend_mode", false),
        rRatedMode      = prefs.getBoolean("r_rated_mode", false),
        ageVerified     = prefs.getBoolean("age_verified", false),
        conversationMode = prefs.getBoolean("conversation_mode", false),

        guardianEnabled  = prefs.getBoolean("guardian_enabled", false),
        guardianModelId  = prefs.getString("guardian_model_id", "") ?: "",
        listenMode       = ListenMode.values().firstOrNull { it.key == prefs.getString("listen_mode", "everyone") } ?: ListenMode.EVERYONE,
        godMode          = prefs.getBoolean("god_mode", false),
        awayMode         = prefs.getBoolean("away_mode", false),

        faceLockEnabled  = prefs.getBoolean("maya_face_lock", false),
        watchmanMode     = prefs.getBoolean("watchman_mode", false),
        stealthMode      = prefs.getBoolean("stealth_mode", false),

        earpieceMode     = prefs.getBoolean("earpiece_mode", false),
        mediaMode        = prefs.getBoolean("audio_media_mode", false),
        ignoreDoNotDisturb = prefs.getBoolean("ignore_dnd", false),

        keepAlive        = prefs.getBoolean("keep_alive", true),
        batterySaver     = prefs.getBoolean("maya_battery_saver", false),
        proactiveMode    = prefs.getBoolean("proactive_mode", false),
        sendUnrecognized = prefs.getBoolean("send_unrecognized", false),
        drivingModeEnabled = prefs.getBoolean("maya_driving_mode", false),

        emailAddress     = prefs.getString("email_address", "") ?: "",
        emailPassword    = prefs.getString("email_password", "") ?: "",
        emailSmtpHost    = prefs.getString("email_smtp_host", "") ?: "",
        emailSmtpPort    = prefs.getInt("email_smtp_port", 465),
        emailSignature   = prefs.getString("email_signature", "") ?: "",

        imageProvider    = ImageProvider.values().firstOrNull { it.key == prefs.getString("image_provider", "pollinations") } ?: ImageProvider.POLLINATIONS_FREE,
        imageModelId     = prefs.getString("image_model_id", "") ?: "",
        imageApiKey      = prefs.getString("image_api_key", "") ?: "",

        mayaSitesPlanActive = prefs.getBoolean("maya_sites_plan", false),

        mayaHomeBoxId    = prefs.getString("maya_home_box_id", "") ?: "",
        mayaHomePassword = prefs.getString("maya_home_password", "") ?: "",

        dailyStoryEnabled = prefs.getBoolean("daily_story_enabled", false),
        dailyStoryTime   = prefs.getString("daily_story_time", "09:00") ?: "09:00",
        autoPostEnabled  = prefs.getBoolean("auto_post_enabled", false),

        braveApiKey      = prefs.getString("brave_api_key", "") ?: "",
        tavilyApiKey     = prefs.getString("tavily_api_key", "") ?: "",
        serpApiKey       = prefs.getString("serp_api_key", "") ?: "",
        googlePlacesApiKey = prefs.getString("google_places_api_key", "") ?: "",

        callAnnouncer    = prefs.getBoolean("call_announcer", true),
        announceBatteryFull = prefs.getBoolean("announce_battery_full", true),
        announceBatteryLow  = prefs.getBoolean("announce_battery_low", true),
        announceCharger     = prefs.getBoolean("announce_charger", true),
        announceAirplaneMode = prefs.getBoolean("announce_airplane_mode", true),

        proMaxActive     = prefs.getBoolean("pro_max_active", true),
        autoUpdate       = prefs.getBoolean("auto_update", true)
    )

    // ── Quick getters (for service — no full load needed) ──
    fun getApiKey(provider: String): String = prefs.getString("${provider}_api_key", "") ?: ""
    fun isProMax(): Boolean = prefs.getBoolean("pro_max_active", false)
    fun getPersona(): String = prefs.getString("default_persona", "maya") ?: "maya"
    fun isGirlfriendMode(): Boolean = prefs.getBoolean("girlfriend_mode", false)
    fun isRRatedMode(): Boolean = prefs.getBoolean("r_rated_mode", false)
    fun isAgeVerified(): Boolean = prefs.getBoolean("age_verified", false)
}
