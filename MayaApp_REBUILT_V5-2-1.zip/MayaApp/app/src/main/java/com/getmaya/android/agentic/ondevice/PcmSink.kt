package com.getmaya.android.agentic.ondevice

/**
 * PCM audio callback interface — extracted from APK DEX.
 *
 * PocketTtsNative.nativeSpeak() calls onPcm() for every decoded audio chunk.
 * Return true to continue streaming, false to stop early (e.g. on barge-in).
 *
 * From DEX: onPcm([B, I)Z  — byte array + length → boolean
 */
fun interface PcmSink {
    /**
     * Called with each decoded PCM chunk from the TTS engine.
     * @param pcm   Raw 16-bit LE PCM samples.
     * @param len   Number of valid bytes in [pcm].
     * @return true to keep streaming; false to abort.
     */
    fun onPcm(pcm: ByteArray, len: Int): Boolean
}
