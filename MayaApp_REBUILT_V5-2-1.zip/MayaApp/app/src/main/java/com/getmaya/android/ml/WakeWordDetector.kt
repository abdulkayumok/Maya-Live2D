package com.getmaya.android.ml

import org.tensorflow.lite.Interpreter
import java.nio.MappedByteBuffer

class WakeWordDetector(private val interpreter: Interpreter) {
    
    fun detectWakeWord(audioData: FloatArray): Boolean {
        val input = arrayOf(audioData)
        val output = arrayOf(FloatArray(2))
        interpreter.runForMultipleInputsOutputs(input, output)
        
        val confidence = output[0][1]
        return confidence > 0.5f
    }
    
    fun close() {
        interpreter.close()
    }
}
