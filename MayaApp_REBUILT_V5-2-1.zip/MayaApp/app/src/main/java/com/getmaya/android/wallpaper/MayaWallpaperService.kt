package com.getmaya.android.wallpaper

import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.getmaya.android.data.repository.SettingsRepository
import kotlin.math.*

class MayaWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = MayaWallpaperEngine()

    inner class MayaWallpaperEngine : WallpaperService.Engine() {

        private val handler  = Handler(Looper.getMainLooper())
        private var visible  = false
        private var width    = 1080f
        private var height   = 1920f
        private var frame    = 0L

        // ── Paints ─────────────────────────────────────────
        private val bgPaint = Paint().apply { isAntiAlias = true }

        private val orbitPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }

        private val corePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        private val glowPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
            maskFilter = BlurMaskFilter(60f, BlurMaskFilter.Blur.NORMAL)
        }

        private val particlePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        private val textPaint = Paint().apply {
            isAntiAlias = true
            color = Color.argb(120, 180, 130, 255)
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            letterSpacing = 0.3f
        }

        // ── Particles ──────────────────────────────────────
        private val particles = Array(60) { Particle(it) }

        private inner class Particle(seed: Int) {
            var x = 0f; var y = 0f
            var vx = 0f; var vy = 0f
            var alpha = 0f; var size = 0f
            var life = 0f; var maxLife = 0f
            var color = 0

            init { reset(seed * 17f) }

            fun reset(offset: Float = 0f) {
                val cx = width / 2f
                val cy = height * 0.42f
                val angle = Math.random() * 2 * PI
                val r = (80 + Math.random() * 160).toFloat()
                x = cx + (cos(angle) * r).toFloat()
                y = cy + (sin(angle) * r).toFloat()
                vx = ((-0.3 + Math.random() * 0.6) * 0.8f).toFloat()
                vy = ((-1.2 - Math.random() * 0.8f)).toFloat()
                size = (1.5f + Math.random() * 3f).toFloat()
                maxLife = (120 + Math.random() * 180).toFloat()
                life = offset % maxLife
                alpha = 0f
                val colors = intArrayOf(
                    Color.argb(255, 180, 100, 255),
                    Color.argb(255, 100, 180, 255),
                    Color.argb(255, 255, 130, 200),
                    Color.argb(255, 130, 255, 200)
                )
                color = colors[(seed % colors.size).absoluteValue]
            }

            fun update() {
                life++
                if (life > maxLife) reset()
                x += vx; y += vy
                vy -= 0.012f
                val progress = life / maxLife
                alpha = when {
                    progress < 0.2f -> progress / 0.2f
                    progress > 0.8f -> (1f - progress) / 0.2f
                    else -> 1f
                }
            }
        }

        // ── Gradients ──────────────────────────────────────
        private fun buildBg(): LinearGradient {
            return LinearGradient(0f, 0f, 0f, height,
                intArrayOf(
                    Color.rgb(4, 0, 18),
                    Color.rgb(8, 2, 32),
                    Color.rgb(12, 4, 40),
                    Color.rgb(6, 1, 22)
                ),
                floatArrayOf(0f, 0.35f, 0.7f, 1f),
                Shader.TileMode.CLAMP)
        }

        // ── Draw frame ─────────────────────────────────────
        private val runnable = Runnable { drawFrame() }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                canvas?.let { draw(it) }
            } finally {
                try { canvas?.let { holder.unlockCanvasAndPost(it) } } catch (_: Exception) {}
            }
            handler.removeCallbacks(runnable)
            if (visible) handler.postDelayed(runnable, 33) // ~30fps
        }

        private fun draw(c: Canvas) {
            frame++
            val t = frame * 0.018f
            val cx = width / 2f
            val cy = height * 0.42f

            // ── Background ──────────────────────────────────
            bgPaint.shader = buildBg()
            c.drawRect(0f, 0f, width, height, bgPaint)

            // ── Nebula cloud ────────────────────────────────
            drawNebula(c, cx, cy, t)

            // ── Orbit rings ─────────────────────────────────
            drawOrbits(c, cx, cy, t)

            // ── Orbiting dots ───────────────────────────────
            drawOrbitingDots(c, cx, cy, t)

            // ── Core glow ───────────────────────────────────
            drawCore(c, cx, cy, t)

            // ── Particles ───────────────────────────────────
            particles.forEach { p ->
                p.update()
                val a = (p.alpha * 200).toInt().coerceIn(0, 255)
                particlePaint.color = Color.argb(a,
                    Color.red(p.color), Color.green(p.color), Color.blue(p.color))
                c.drawCircle(p.x, p.y, p.size, particlePaint)
            }

            // ── "MAYA" text ─────────────────────────────────
            val textAlpha = (120 + 60 * sin(t * 0.3f)).toInt().coerceIn(0, 255)
            textPaint.alpha = textAlpha
            val label = "MAYA"
            val tw = textPaint.measureText(label)
            c.drawText(label, cx - tw / 2f, cy + 185f, textPaint)

            // ── Bottom pulse bar ─────────────────────────────
            drawPulseBar(c, t)
        }

        private fun drawNebula(c: Canvas, cx: Float, cy: Float, t: Float) {
            val rg = RadialGradient(cx, cy,
                280f + 40f * sin(t * 0.4f),
                intArrayOf(
                    Color.argb(35, 140, 60, 255),
                    Color.argb(18, 80, 40, 200),
                    Color.argb(0, 0, 0, 0)
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP)
            glowPaint.shader = rg
            glowPaint.maskFilter = BlurMaskFilter(80f, BlurMaskFilter.Blur.NORMAL)
            c.drawCircle(cx, cy, 320f, glowPaint)
        }

        private fun drawOrbits(c: Canvas, cx: Float, cy: Float, t: Float) {
            val radii = floatArrayOf(90f, 140f, 195f)
            val alphas = intArrayOf(40, 28, 18)
            for (i in radii.indices) {
                orbitPaint.color = Color.argb(alphas[i], 160, 100, 255)
                val scaleX = 1f
                val scaleY = 0.38f
                c.save()
                c.translate(cx, cy)
                c.scale(scaleX, scaleY)
                c.drawCircle(0f, 0f, radii[i], orbitPaint)
                c.restore()
            }
        }

        private fun drawOrbitingDots(c: Canvas, cx: Float, cy: Float, t: Float) {
            val configs = arrayOf(
                Triple(90f, 0.38f, t * 0.9f),
                Triple(140f, 0.38f, t * (-0.6f) + 1.0f),
                Triple(195f, 0.38f, t * 0.5f + 2.1f)
            )
            val dotColors = intArrayOf(
                Color.argb(220, 200, 140, 255),
                Color.argb(200, 130, 200, 255),
                Color.argb(180, 255, 150, 210)
            )
            for (i in configs.indices) {
                val (r, ry, angle) = configs[i]
                val dx = cx + r * cos(angle)
                val dy = cy + r * ry * sin(angle)
                // Glow
                val glow = RadialGradient(dx.toFloat(), dy.toFloat(), 16f,
                    intArrayOf(dotColors[i], Color.argb(0, 0, 0, 0)),
                    floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
                corePaint.shader = glow
                c.drawCircle(dx.toFloat(), dy.toFloat(), 16f, corePaint)
                // Dot center
                corePaint.shader = null
                corePaint.color = Color.WHITE
                c.drawCircle(dx.toFloat(), dy.toFloat(), 4f, corePaint)
            }
        }

        private fun drawCore(c: Canvas, cx: Float, cy: Float, t: Float) {
            val pulse = 1f + 0.12f * sin(t * 1.2f)
            val r = 44f * pulse
            // Outer glow
            val outerGlow = RadialGradient(cx, cy, r * 3.5f,
                intArrayOf(
                    Color.argb(100, 180, 100, 255),
                    Color.argb(40, 120, 60, 255),
                    Color.argb(0, 0, 0, 0)
                ),
                floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
            glowPaint.shader = outerGlow
            glowPaint.maskFilter = BlurMaskFilter(r * 2f, BlurMaskFilter.Blur.NORMAL)
            c.drawCircle(cx, cy, r * 3f, glowPaint)
            // Core fill
            val coreGrad = RadialGradient(cx, cy - r * 0.3f, r,
                intArrayOf(Color.WHITE, Color.argb(255, 220, 170, 255), Color.argb(255, 140, 80, 255)),
                floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
            corePaint.shader = coreGrad
            corePaint.maskFilter = null
            c.drawCircle(cx, cy, r, corePaint)
        }

        private fun drawPulseBar(c: Canvas, t: Float) {
            val barY = height * 0.88f
            val barW = width * 0.55f
            val cx = width / 2f
            for (i in 0..11) {
                val x = cx - barW / 2f + i * (barW / 11f)
                val h = 8f + 22f * abs(sin(t * 1.4f + i * 0.55f))
                val alpha = (120 + 100 * abs(sin(t + i * 0.4f))).toInt().coerceIn(0, 220)
                corePaint.shader = null
                corePaint.maskFilter = null
                corePaint.color = Color.argb(alpha, 160, 100, 255)
                c.drawRoundRect(x - 3f, barY - h, x + 3f, barY + h, 3f, 3f, corePaint)
            }
        }

        // ── Surface lifecycle ──────────────────────────────
        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            drawFrame()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            width = w.toFloat(); height = h.toFloat()
            particles.forEachIndexed { i, p -> p.reset(i * 17f) }
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(runnable)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(vis: Boolean) {
            visible = vis
            if (vis) drawFrame() else handler.removeCallbacks(runnable)
        }
    }
}
