package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ═══════════════════════════════════════════════════════════
// ALL SCREENS — Chat, Memories, Markets, Marketing,
//               Documents, Coding, Upgrade, About
// ═══════════════════════════════════════════════════════════

// ── 1. CHAT SCREEN ───────────────────────────────────────
@Composable
fun ChatScreen(
    onBack: () -> Unit = {},
    onSend: (String) -> Unit = {}
) {
    var inputText by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(
        ChatMsg("maya", "Haan Boss, batao kya kaam hai?"),
    )}

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth()
                .background(Color(0xFF0D1525))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("←", color = Color.White, fontSize = 20.sp,
                modifier = Modifier.clickable(onClick = onBack))
            Spacer(Modifier.width(12.dp))
            Text("Maya", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape)
                .background(Color(0xFF4ADE80)))
        }

        // Messages
        LazyColumn(
            modifier = Modifier.weight(1f).padding(12.dp),
            reverseLayout = true
        ) {
            items(messages.reversed()) { msg ->
                ChatBubble(msg)
                Spacer(Modifier.height(8.dp))
            }
        }

        // Input
        Row(
            modifier = Modifier.fillMaxWidth()
                .background(Color(0xFF0D1525))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type or tap mic...", color = Color(0xFF445566)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF4477FF),
                    unfocusedBorderColor = Color(0xFF1A2540),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF111A2E),
                    unfocusedContainerColor = Color(0xFF111A2E)
                ),
                shape = RoundedCornerShape(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier.size(44.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0xFF4477FF))
                    .clickable {
                        if (inputText.isNotBlank()) {
                            messages.add(ChatMsg("user", inputText))
                            onSend(inputText)
                            inputText = ""
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Text("▶", color = Color.White, fontSize = 16.sp) }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMsg) {
    val isMaya = msg.role == "maya"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMaya) Arrangement.Start else Arrangement.End
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(
                    topStart = if (isMaya) 4.dp else 14.dp,
                    topEnd = if (isMaya) 14.dp else 4.dp,
                    bottomStart = 14.dp, bottomEnd = 14.dp
                ))
                .background(if (isMaya) Color(0xFF1A2A4A) else Color(0xFF5B21B6))
                .padding(12.dp)
        ) {
            Text(msg.text, color = Color.White, fontSize = 14.sp)
        }
    }
}

data class ChatMsg(val role: String, val text: String)

// ── 2. MEMORIES SCREEN ────────────────────────────────────
@Composable
fun MemoriesScreen(onBack: () -> Unit = {}) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))
    ) {
        ScreenHeader("Memories", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("WIKI PAGES", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            val pages = listOf(
                Triple("profile", "👤", "Who you are — name, role, city"),
                Triple("business", "💼", "Your business details"),
                Triple("preferences", "⚙️", "How you like things done"),
                Triple("contacts", "👥", "Important people in your life"),
                Triple("projects", "📁", "Active projects"),
                Triple("goals", "🎯", "Your goals"),
                Triple("schedule", "📅", "Your recurring schedule"),
                Triple("devices", "📱", "Devices and accounts"),
                Triple("health", "🏥", "Health notes"),
                Triple("finances", "💰", "Financial context")
            )

            pages.forEach { (key, icon, desc) ->
                MemoryCard(icon, key, desc)
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("REMEMBERED FACTS", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Text("Things Maya remembers across sessions via REMEMBER tool.",
                color = Color(0xFF556677), fontSize = 13.sp)
        }
    }
}

@Composable
fun MemoryCard(icon: String, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F1A2E))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Color(0xFF556677), fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("›", color = Color(0xFF334455), fontSize = 18.sp)
    }
}

// ── 3. MARKETS SCREEN ─────────────────────────────────────
@Composable
fun MarketsScreen(onBack: () -> Unit = {}) {
    var marketRead by remember { mutableStateOf("Tap 'Get Market Read' to generate...") }
    var loading by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("Markets", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Watchlist
            Text("WATCHLIST", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            val stocks = listOf(
                Triple("NIFTY 50", "24,320.15", "+0.43%"),
                Triple("SENSEX",   "80,190.32", "+0.38%"),
                Triple("RELIANCE", "2,891.20",  "-0.12%"),
                Triple("TCS",      "4,102.55",  "+0.67%"),
                Triple("BTC/USD",  "67,432.00", "+1.24%")
            )
            stocks.forEach { (name, price, change) ->
                StockRow(name, price, change)
                Spacer(Modifier.height(6.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("AI MARKET READ", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1A2E))
                    .padding(14.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color(0xFF4477FF),
                        modifier = Modifier.align(Alignment.Center))
                } else {
                    Text(marketRead, color = Color(0xFFCCD8E8), fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { loading = true /* → MarketingEngine.marketRead() */ },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4477FF)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Get Market Read", color = Color.White)
            }

            Spacer(Modifier.height(8.dp))
            Text("⚠️ Not investment advice. Maya does not recommend buy/sell/hold.",
                color = Color(0xFF445566), fontSize = 11.sp)
        }
    }
}

@Composable
fun StockRow(name: String, price: String, change: String) {
    val isPositive = change.startsWith("+")
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F1A2E))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(price, color = Color(0xFFCCD8E8), fontSize = 14.sp)
        Spacer(Modifier.width(12.dp))
        Text(change,
            color = if (isPositive) Color(0xFF4ADE80) else Color(0xFFFF4444),
            fontSize = 13.sp)
    }
}

// ── 4. MARKETING SCREEN ───────────────────────────────────
@Composable
fun MarketingScreen(onBack: () -> Unit = {}) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("Marketing", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("CREATE CONTENT", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            val tools = listOf(
                Triple("📱", "Instagram Post", "Caption + hashtags in Hinglish"),
                Triple("🎬", "Reel Script",    "Hook → content → CTA, second-by-second"),
                Triple("📊", "Carousel",       "Multi-slide content breakdown"),
                Triple("⭐", "Review Reply",   "Respond to customer reviews"),
                Triple("🌐", "Landing Page",   "Full page brief — headline to CTA"),
                Triple("📧", "Email Campaign", "Subject line + body + CTA"),
                Triple("🤖", "n8n Workflow",   "Automation workflow JSON"),
                Triple("🔍", "SEO Audit",      "PageSpeed + fixes in Hinglish"),
                Triple("🏪", "Competitor Analysis", "Gaps + differentiation"),
                Triple("📅", "Content Calendar", "Week/month plan")
            )

            tools.forEach { (icon, title, desc) ->
                MarketingTool(icon, title, desc)
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("SCHEDULED", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScheduleCard("Daily Story", "9:00 AM", Color(0xFF1A3060), Modifier.weight(1f))
                ScheduleCard("Weekly Report", "Mon 8 AM", Color(0xFF2A1A40), Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun MarketingTool(icon: String, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F1A2E))
            .clickable { /* navigate to tool */ }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(desc, color = Color(0xFF556677), fontSize = 12.sp)
        }
        Text("›", color = Color(0xFF334455), fontSize = 18.sp)
    }
}

@Composable
fun ScheduleCard(title: String, time: String, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(12.dp))
            .background(bg).padding(12.dp)
    ) {
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(time, color = Color(0xFF8899AA), fontSize = 12.sp)
    }
}

// ── 5. DOCUMENTS SCREEN ───────────────────────────────────
@Composable
fun DocumentsScreen(onBack: () -> Unit = {}) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("Documents", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("CREATE", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            listOf(
                Triple("📄", "Write Document",  "Letter, proposal, agreement..."),
                Triple("📊", "Spreadsheet",     "Tables, calculations, tracker"),
                Triple("📋", "Report",          "Formal business/project report"),
                Triple("✉️", "Email Draft",     "Professional email with Maya"),
                Triple("📑", "Template",        "Reusable document template"),
                Triple("🔏", "Legal Draft",     "Basic contracts, NDAs, T&Cs")
            ).forEach { (icon, title, desc) ->
                MarketingTool(icon, title, desc)
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("GOOGLE DRIVE", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1A2E))
                    .padding(16.dp)
            ) {
                Text("Connect Google Drive to access and save files.\nSettings → Connectors → Google Drive",
                    color = Color(0xFF556677), fontSize = 13.sp)
            }
        }
    }
}

// ── 6. WEBSITE / CODING SCREEN ────────────────────────────
@Composable
fun CodingScreen(onBack: () -> Unit = {}) {
    var prompt by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("Website / Coding", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("QUICK START", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            listOf(
                Triple("🌐", "New Website",     "Maya builds full site on your phone"),
                Triple("📱", "Landing Page",    "Single-page for product/service"),
                Triple("🛒", "E-commerce Page", "Product page with MayaDB"),
                Triple("📊", "Dashboard",       "Admin panel with live data"),
                Triple("🔧", "Fix My Code",     "Paste code, Maya debugs"),
                Triple("💡", "Explain Code",    "Maya explains any code simply"),
                Triple("🐙", "GitHub Push",     "Push current project to GitHub")
            ).forEach { (icon, title, desc) ->
                MarketingTool(icon, title, desc)
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("TERMUX REQUIRED", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0A1525))
                    .padding(14.dp)
            ) {
                Column {
                    Text("Maya builds code on your phone using Termux.",
                        color = Color(0xFFCCD8E8), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Setup (one time in Termux):", color = Color(0xFF8899AA), fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("mkdir -p ~/.termux\necho 'allow-external-apps = true' >> ~/.termux/termux.properties\ntermux-reload-settings",
                        color = Color(0xFF4ADE80), fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("MAYA SITES", color = Color(0xFF445566), fontSize = 11.sp,
                letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp))

            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1A2E))
                    .padding(14.dp)
            ) {
                Column {
                    Text("Deploy to *.getmaya.cloud instantly.",
                        color = Color(0xFFCCD8E8), fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("MayaDB included — no backend needed.",
                        color = Color(0xFF556677), fontSize = 12.sp)
                }
            }
        }
    }
}

// ── 7. UPGRADE SCREEN ─────────────────────────────────────
@Composable
fun UpgradeScreen(onBack: () -> Unit = {}) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("Upgrade to Pro Max ✦", onBack)

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Text("✦ PRO MAX", color = Color(0xFF818CF8), fontSize = 28.sp,
                fontWeight = FontWeight.Bold)
            Text("One-time purchase · Lifetime", color = Color(0xFF556677), fontSize = 14.sp)

            Spacer(Modifier.height(24.dp))

            val features = listOf(
                "🎭 All characters — Venom, Friday, Jarvis",
                "💜 Girlfriend mode (18+ gated)",
                "🔥 Intense mode (18+, age verified)",
                "🖼️ Maya live wallpaper",
                "💬 Conversation mode (long sessions)",
                "⚡ Priority AI — Gemini Pro, Claude Sonnet",
                "📊 Marketing dashboard (full access)",
                "🌐 Maya Sites — unlimited deploys",
                "🧠 Extended memory / wiki",
                "🔄 PC ⇄ Phone sync (Maya Home)",
                "📈 Markets — full AI reads",
                "📧 Email sending (unlimited)"
            )

            features.forEach { feature ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✓", color = Color(0xFF4ADE80), fontSize = 16.sp,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Text(feature, color = Color(0xFFCCD8E8), fontSize = 14.sp)
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { /* open getmaya.online/checkout?product=android&plan=promax */ },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF5B21B6)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Upgrade Now →", color = Color.White, fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(12.dp))
            Text("getmaya.online  ·  by Sir Abdul Kayum Ai",
                color = Color(0xFF334455), fontSize = 12.sp)
        }
    }
}

// ── 8. ABOUT SCREEN ───────────────────────────────────────
@Composable
fun AboutScreen(onBack: () -> Unit = {}) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080F1A))) {
        ScreenHeader("About", onBack)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))
            Text("Maya", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("v5.2.9", color = Color(0xFF556677), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text("by Sir Abdul Kayum Ai", color = Color(0xFF4477FF), fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            Text(
                "Maya is your Hinglish AI companion that runs your whole phone — " +
                "calls, WhatsApp, websites, code, marketing, and everything in between.",
                color = Color(0xFF8899AA), fontSize = 14.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            listOf(
                "Website" to "getmaya.online",
                "Builder" to "Sir Abdul Kayum Ai",
                "GitHub"  to "SirAbdulKayumAi",
                "Sites"   to "getmaya.cloud",
                "Support" to "getmaya.online/support"
            ).forEach { (label, value) ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(label, color = Color(0xFF556677), fontSize = 14.sp,
                        modifier = Modifier.weight(1f))
                    Text(value, color = Color(0xFF4477FF), fontSize = 14.sp)
                }
                Divider(color = Color(0xFF1A2540), thickness = 0.5.dp)
            }
        }
    }
}

// ── SHARED: Screen Header ─────────────────────────────────
@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(Color(0xFF0D1525))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("←", color = Color.White, fontSize = 22.sp,
            modifier = Modifier.clickable(onClick = onBack))
        Spacer(Modifier.width(14.dp))
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}
