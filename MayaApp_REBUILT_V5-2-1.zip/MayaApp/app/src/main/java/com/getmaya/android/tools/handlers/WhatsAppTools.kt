package com.getmaya.android.tools.handlers

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.FileProvider
import com.getmaya.android.tools.ToolContext
import com.getmaya.android.tools.ToolResult
import java.io.File

// ═══════════════════════════════════════════════════════════
// WHATSAPP TOOLS — messages, files, voice notes, auto-reply
//
// Three delivery methods (in order of preference):
// 1. Share Intent (universal, opens WA with pre-filled text)
// 2. wa.me deep link (opens chat but requires manual send)
// 3. Accessibility: tap Send button automatically
// ═══════════════════════════════════════════════════════════

class WhatsAppTools(private val ctx: ToolContext) {

    companion object {
        const val WA_PKG = "com.whatsapp"
        const val WA_BUSINESS_PKG = "com.whatsapp.w4b"
        var autoReplyEnabled = false
        var autoReplyMessage = "Maya se bol rahi hoon — main baad mein baat karoonga"
    }

    // ── Send text message ──────────────────────────────────
    fun sendMessage(number: String, name: String, message: String): ToolResult {
        val phoneNumber = resolveWaNumber(number, name)
            ?: return ToolResult.err("${name.ifEmpty { number }} ka WhatsApp number nahi mila")

        // Method 1: Deep link — opens chat directly
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://wa.me/$phoneNumber?text=${Uri.encode(message)}")
            setPackage(WA_PKG)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.context.startActivity(intent)
            // Auto-tap Send after 1.5s
            ctx.accessibility?.tapTextDelayed("Send", delayMs = 1500)
            ToolResult.ok("WhatsApp message bhej raha hoon ${name.ifEmpty { number }} ko")
        } catch (e: Exception) {
            ToolResult.err("WhatsApp nahi mila: ${e.message}")
        }
    }

    // ── Send file ──────────────────────────────────────────
    fun sendFile(number: String, filePath: String): ToolResult {
        val file = File(filePath)
        if (!file.exists()) return ToolResult.err("File nahi mili: $filePath")

        val uri = FileProvider.getUriForFile(
            ctx.context,
            "${ctx.context.packageName}.provider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = ctx.context.contentResolver.getType(uri) ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage(WA_PKG)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            ctx.context.startActivity(intent)
            ToolResult.ok("File WhatsApp mein share ki")
        } catch (e: Exception) {
            ToolResult.err("File share nahi hui: ${e.message}")
        }
    }

    // ── Voice reply (recorded audio note) ─────────────────
    private var pendingVoiceReplyNumber: String? = null

    fun prepareVoiceReply(number: String): ToolResult {
        pendingVoiceReplyNumber = resolveWaNumber(number, "")
        return ToolResult.ok("Ready — bol do, voice note bana ke bhejta hoon")
    }

    fun sendVoiceReply(number: String, audioPath: String): ToolResult {
        val targetNumber = resolveWaNumber(number, "") ?: pendingVoiceReplyNumber
            ?: return ToolResult.err("Number nahi mila")

        val file = File(audioPath)
        if (!file.exists()) return ToolResult.err("Audio file nahi mili")

        val uri = FileProvider.getUriForFile(
            ctx.context, "${ctx.context.packageName}.provider", file)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/ogg"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage(WA_PKG)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            ctx.context.startActivity(intent)
            pendingVoiceReplyNumber = null
            ToolResult.ok("Voice note bhej raha hoon")
        } catch (e: Exception) {
            ToolResult.err("Voice note nahi gayi: ${e.message}")
        }
    }

    fun cancelVoiceReply(): ToolResult {
        pendingVoiceReplyNumber = null
        return ToolResult.ok("Voice reply cancel")
    }

    // ── Foreign language voice reply ───────────────────────
    // Converts text → TTS audio → sends as voice note
    fun sendForeignLangReply(number: String, text: String, language: String): ToolResult {
        val targetNumber = resolveWaNumber(number, "")
            ?: return ToolResult.err("Number nahi mila")

        // TTS will generate audio file, then sendVoiceReply is called
        val outPath = "${ctx.context.cacheDir}/maya_voice_${System.currentTimeMillis()}.ogg"
        // TtsEngine.synthesizeToFile is called by the service
        ctx.context.sendBroadcast(Intent("com.getmaya.android.SYNTHESIZE_VOICE_REPLY").apply {
            putExtra("text", text)
            putExtra("language", language)
            putExtra("output", outPath)
            putExtra("target_number", targetNumber)
        })
        return ToolResult.ok("Voice message bana raha hoon — thoda wait karo")
    }

    // ── Auto-reply ─────────────────────────────────────────
    fun setAutoReply(enabled: Boolean, message: String): ToolResult {
        autoReplyEnabled = enabled
        if (message.isNotEmpty()) autoReplyMessage = message
        return ToolResult.ok(
            if (enabled) "Auto-reply on — \"$autoReplyMessage\""
            else "Auto-reply band kar diya"
        )
    }

    fun getAutoReplyStatus(): ToolResult {
        val status = if (autoReplyEnabled) "ON — message: \"$autoReplyMessage\"" else "OFF"
        return ToolResult.ok("Auto-reply: $status")
    }

    // ── Internal: called by NotificationListener ───────────
    fun shouldAutoReply(sender: String): Boolean = autoReplyEnabled

    fun getAutoReplyMessage(): String = autoReplyMessage

    // ── Helper: normalize WA number ───────────────────────
    private fun resolveWaNumber(number: String, name: String): String? {
        val cleaned = number.replace(Regex("[^0-9+]"), "")

        // Already formatted
        if (cleaned.startsWith("+91") && cleaned.length == 13) return cleaned.removePrefix("+")
        if (cleaned.length == 10 && cleaned[0].isDigit()) return "91$cleaned"
        if (cleaned.startsWith("91") && cleaned.length == 12) return cleaned

        if (name.isEmpty()) return cleaned.ifEmpty { null }

        // Look up from contacts
        val cursor = ctx.context.contentResolver.query(
            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(name)),
            arrayOf(ContactsContract.PhoneLookup.NUMBER), null, null, null
        )
        val raw = cursor?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        val digits = raw.replace(Regex("[^0-9]"), "")
        return when {
            digits.startsWith("91") && digits.length == 12 -> digits
            digits.length == 10 -> "91$digits"
            else -> digits
        }
    }
}
