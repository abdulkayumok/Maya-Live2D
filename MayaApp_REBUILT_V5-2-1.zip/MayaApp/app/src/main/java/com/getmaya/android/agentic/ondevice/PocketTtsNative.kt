package com.getmaya.android.agentic.ondevice

/**
 * JNI bridge for the PocketTTS on-device neural TTS engine.
 *
 * Extracted from APK DEX — all 24 methods and 11 fields preserved exactly.
 * Native libraries: pockettts_jni, onnxruntime.
 *
 * State constants (GRAPH_*) match the values baked into the shared library.
 * Internal log tag: "hunter-ondevice" (preserved from APK as-is — it is an
 * internal engine identifier, not a user-facing string).
 *
 * Typical usage:
 *   val h = PocketTtsNative.nativeNew(0)
 *   PocketTtsNative.nativeGraphFromFile(h, GRAPH_MAIN, modelPath)
 *   PocketTtsNative.nativeVoiceFromStage(h, "default")
 *   PocketTtsNative.nativePrime(h)
 *   PocketTtsNative.nativeSpeak(h, textUtf8Bytes, sink)
 *   PocketTtsNative.nativeClose(h)
 */
object PocketTtsNative {

    // ── Graph type constants ───────────────────────────────
    const val GRAPH_MAIN    = 0
    const val GRAPH_TEXT    = 1
    const val GRAPH_DECODER = 2
    const val GRAPH_FLOW    = 3

    // ── Text encoding constants ────────────────────────────
    const val E_TEXT  = 0
    const val CUT     = 1
    const val SPOKEN  = 2

    // ── Load state ────────────────────────────────────────
    var failure: String = ""
        private set
    var tried: Boolean = false
        private set

    // ── Library load ──────────────────────────────────────
    /**
     * Loads the native libraries. Returns empty string on success,
     * or an error message that is also stored in [failure].
     */
    fun load(): String {
        if (tried) return failure
        tried = true
        return try {
            System.loadLibrary("onnxruntime")
            System.loadLibrary("pockettts_jni")
            failure = ""
            failure
        } catch (t: Throwable) {
            failure = "library: ${t.message}"
            failure
        }
    }

    // ── Lifecycle ─────────────────────────────────────────

    /** Allocate a new engine instance. Returns a native handle (long). */
    @JvmStatic external fun nativeNew(flags: Int): Long

    /** Close and free the engine handle. */
    @JvmStatic external fun nativeClose(handle: Long)

    // ── Graph / model loading ─────────────────────────────

    /** Load a graph from a file path. Returns 0 on success. */
    @JvmStatic external fun nativeGraphFromFile(handle: Long, graphType: Int, path: String): Int

    /** Load a graph from a staged ByteBuffer (returned by nativeStage). */
    @JvmStatic external fun nativeGraphFromStage(handle: Long, graphType: Int): Int

    /** Stage a raw model buffer. Returns a ByteBuffer backed by native memory. */
    @JvmStatic external fun nativeStage(handle: Long, offset: Long): java.nio.ByteBuffer

    /** Unstage (release) a previously staged buffer. */
    @JvmStatic external fun nativeUnstage(handle: Long)

    // ── Tokenizer ─────────────────────────────────────────

    @JvmStatic external fun nativeTokenizerFromFile(handle: Long, path: String): Int
    @JvmStatic external fun nativeTokenizerFromStage(handle: Long): Int

    // ── Voice ─────────────────────────────────────────────

    @JvmStatic external fun nativeVoiceFromFile(handle: Long, path: String, key: String): Int
    @JvmStatic external fun nativeVoiceFromStage(handle: Long, key: String): Int
    @JvmStatic external fun nativeSetVoice(handle: Long, key: String): Int

    // ── Engine control ────────────────────────────────────

    /** Warm-up the engine (pre-allocate buffers). Returns 0 on success. */
    @JvmStatic external fun nativePrime(handle: Long): Int

    /** Returns number of live engine instances across all handles. */
    @JvmStatic external fun nativeLiveEngines(): Int

    /** Purge cached engine state. Returns 0 on success. */
    @JvmStatic external fun nativePurge(): Int

    /** Configure synthesis parameters. Returns 0 on success. */
    @JvmStatic external fun nativeConfigure(
        handle: Long,
        speed: Float,
        pitch: Float,
        sampleRate: Int,
        channels: Int,
        bitDepth: Int,
        bufferMs: Int,
        streaming: Boolean,
        normalize: Boolean,
        flags: Int
    ): Int

    /** Signal a barge-in / cut request to the engine. */
    @JvmStatic external fun nativeCut(handle: Long)

    /** Check if the engine is ready to speak. Returns 1 if ready. */
    @JvmStatic external fun nativeReady(handle: Long): Int

    // ── Synthesis ─────────────────────────────────────────

    /**
     * Synthesise [textUtf8] and stream PCM to [sink].
     * [sink].onPcm() is called on the calling thread for each audio chunk.
     * Returns 0 on success.
     */
    @JvmStatic external fun nativeSpeak(handle: Long, textUtf8: ByteArray, sink: PcmSink): Int

    // ── Diagnostics ───────────────────────────────────────

    /** Returns a JSON info string about the engine state. */
    @JvmStatic external fun nativeInfo(handle: Long): String

    /** Returns the last native error string. */
    @JvmStatic external fun nativeLastError(handle: Long): String

    /** Returns current RSS memory in KB. Pass true for just this engine. */
    @JvmStatic external fun nativeRssKb(thisOnly: Boolean): Long
}
