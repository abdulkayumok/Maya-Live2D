package com.getmaya.android.voice

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.edit
import androidx.datastore.preferences.stringPreferencesKey
import androidx.datastore.preferences.floatPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "voice_settings")

class VoiceSettingsRepository(private val context: Context) {
    companion object {
        val SELECTED_CHARACTER = stringPreferencesKey("selected_character")
        val SELECTED_MODE = stringPreferencesKey("selected_mode")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val VOICE_VOLUME = floatPreferencesKey("voice_volume")
        val SELECTED_LANGUAGE = stringPreferencesKey("selected_language")
    }

    val voiceSettings: Flow<VoiceSettings> = context.dataStore.data.map { preferences ->
        VoiceSettings(
            character = preferences[SELECTED_CHARACTER] ?: "Maya",
            mode = preferences[SELECTED_MODE] ?: "Normal",
            speed = preferences[VOICE_SPEED] ?: 1.0f,
            pitch = preferences[VOICE_PITCH] ?: 1.0f,
            volume = preferences[VOICE_VOLUME] ?: 1.0f,
            language = preferences[SELECTED_LANGUAGE] ?: "English"
        )
    }

    suspend fun saveVoiceSettings(settings: VoiceSettings) {
        context.dataStore.edit { preferences ->
            preferences[SELECTED_CHARACTER] = settings.character
            preferences[SELECTED_MODE] = settings.mode
            preferences[VOICE_SPEED] = settings.speed
            preferences[VOICE_PITCH] = settings.pitch
            preferences[VOICE_VOLUME] = settings.volume
            preferences[SELECTED_LANGUAGE] = settings.language
        }
    }
}

data class VoiceSettings(
    val character: String,
    val mode: String,
    val speed: Float,
    val pitch: Float,
    val volume: Float,
    val language: String
)
