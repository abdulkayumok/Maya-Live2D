package com.getmaya.android.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════════════════════
// MAYA THEME — Dark blue / purple (from screenshots)
// Font: Inter (Bold, Medium, Regular, SemiBold)
// ═══════════════════════════════════════════════════════════

val MayaBackground     = Color(0xFF080F1A)
val MayaSurface        = Color(0xFF0D1525)
val MayaCard           = Color(0xFF111D30)
val MayaPrimary        = Color(0xFF4477FF)
val MayaSecondary      = Color(0xFF7C3AED)
val MayaAccent         = Color(0xFFCC44FF)
val MayaTextPrimary    = Color(0xFFE2E8F0)
val MayaTextSecondary  = Color(0xFF8899AA)
val MayaTextHint       = Color(0xFF445566)
val MayaDivider        = Color(0xFF1A2540)
val MayaEnergy         = Color(0xFFFFAA00)
val MayaSuccess        = Color(0xFF4ADE80)
val MayaDanger         = Color(0xFFFF4444)
val MayaProMax         = Color(0xFF818CF8)
val MayaBadge          = Color(0xFF5B21B6)

private val DarkColorScheme = darkColorScheme(
    primary         = MayaPrimary,
    onPrimary       = Color.White,
    secondary       = MayaSecondary,
    onSecondary     = Color.White,
    tertiary        = MayaAccent,
    background      = MayaBackground,
    onBackground    = MayaTextPrimary,
    surface         = MayaSurface,
    onSurface       = MayaTextPrimary,
    surfaceVariant  = MayaCard,
    onSurfaceVariant= MayaTextSecondary,
    outline         = MayaDivider,
    error           = MayaDanger,
    onError         = Color.White
)

@Composable
fun MayaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),   // Inter font — add via font resources
        content = content
    )
}
