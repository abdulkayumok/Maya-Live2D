package com.getmaya.android.core

/**
 * Centralized intent action string constants used across Maya's
 * broadcast system.
 *
 * Receivers are in CoreReceivers.kt (BootReceiver, PhoneStateReceiver,
 * MicCaptureReceiver, ReminderReceiver, DrivingOffReceiver).
 */
object MayaActions {
    const val ASSIST_WAKE   = "com.getmaya.android.ASSIST_WAKE"
    const val BOOT_STANDBY  = "com.getmaya.android.BOOT_STANDBY"
    const val CAPTURE_MIC   = "com.getmaya.android.CAPTURE_MIC"
    const val INCOMING_CALL = "com.getmaya.android.INCOMING_CALL"
    const val DRIVING_OFF   = "com.getmaya.android.DRIVING_OFF"
    const val SEND_COMMAND  = "com.getmaya.android.SEND_COMMAND"
    const val REARM_ALERTS  = "com.getmaya.android.REARM_ALERTS"
}
