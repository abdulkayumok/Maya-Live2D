package com.getmaya.android.search

import com.getmaya.android.data.models.MayaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

// ═══════════════════════════════════════════════════════════
// SEARCH ENGINE — all providers from APK strings
//
// Priority (auto-selected based on available keys):
// 1. Brave Search (braveApiKey)
// 2. Tavily (tavilyApiKey)
// 3. SerpAPI (serpApiKey)
// 4. DuckDuckGo lite (free, no key)
// 5. DuckDuckGo HTML (fallback)
//
// Also: Google Autocomplete, Yahoo Finance, Maps
// ═══════════════════════════════════════════════════════════

class SearchEngine(private val settings: MayaSettings) {

    private val http = OkHttpClient()

    // ── Main search (auto-picks best provider) ─────────────
    suspend fun search(query: String, numResults: Int = 5): SearchResult = withContext(Dispatchers.IO) {
        when {
            settings.braveApiKey.isNotEmpty()   -> brave(query, numResults)
            settings.tavilyApiKey.isNotEmpty()  -> tavily(query, numResults)
            settings.serpApiKey.isNotEmpty()    -> serpApi(query, numResults)
            else                                -> duckDuckGo(query, numResults)
        }
    }

    // ── Brave Search ──────────────────────────────────────
    private fun brave(query: String, n: Int): SearchResult {
        val url = "https://api.search.brave.com/res/v1/web/search?q=${enc(query)}&count=$n"
        val json = JSONObject(get(url, mapOf("Accept" to "application/json",
            "X-Subscription-Token" to settings.braveApiKey)))
        val results = json.optJSONObject("web")?.optJSONArray("results") ?: JSONArray()
        return SearchResult(
            query = query,
            provider = "Brave",
            items = (0 until results.length()).map { i ->
                val r = results.getJSONObject(i)
                SearchItem(r.optString("title"), r.optString("url"), r.optString("description"))
            }
        )
    }

    // ── Tavily ────────────────────────────────────────────
    private fun tavily(query: String, n: Int): SearchResult {
        val body = JSONObject().apply {
            put("api_key", settings.tavilyApiKey)
            put("query", query)
            put("max_results", n)
            put("search_depth", "basic")
        }
        val json = JSONObject(post("https://api.tavily.com/search", body))
        val results = json.optJSONArray("results") ?: JSONArray()
        return SearchResult(
            query = query,
            provider = "Tavily",
            items = (0 until results.length()).map { i ->
                val r = results.getJSONObject(i)
                SearchItem(r.optString("title"), r.optString("url"), r.optString("content"))
            }
        )
    }

    // ── SerpAPI (Google) ──────────────────────────────────
    private fun serpApi(query: String, n: Int): SearchResult {
        val url = "https://serpapi.com/search.json?engine=google&q=${enc(query)}&num=$n&api_key=${settings.serpApiKey}"
        val json = JSONObject(get(url))
        val organic = json.optJSONArray("organic_results") ?: JSONArray()
        return SearchResult(
            query = query,
            provider = "Google (SerpAPI)",
            items = (0 until minOf(organic.length(), n)).map { i ->
                val r = organic.getJSONObject(i)
                SearchItem(r.optString("title"), r.optString("link"), r.optString("snippet"))
            }
        )
    }

    // ── DuckDuckGo (free, no key) ─────────────────────────
    private fun duckDuckGo(query: String, n: Int): SearchResult {
        // DDG instant answer API
        val url = "https://api.duckduckgo.com/?q=${enc(query)}&format=json&no_redirect=1&no_html=1"
        return try {
            val json = JSONObject(get(url))
            val abstract = json.optString("Abstract", "")
            val abstractUrl = json.optString("AbstractURL", "")
            val related = json.optJSONArray("RelatedTopics") ?: JSONArray()

            val items = mutableListOf<SearchItem>()
            if (abstract.isNotEmpty()) {
                items.add(SearchItem(json.optString("Heading", query), abstractUrl, abstract))
            }
            for (i in 0 until minOf(related.length(), n - 1)) {
                val r = related.optJSONObject(i) ?: continue
                val text = r.optString("Text", "")
                val firstUrl = r.optString("FirstURL", "")
                if (text.isNotEmpty()) items.add(SearchItem(text.take(60), firstUrl, text))
            }

            if (items.isEmpty()) duckDuckGoHtml(query, n) // fallback
            else SearchResult(query, "DuckDuckGo", items)
        } catch (_: Exception) {
            duckDuckGoHtml(query, n)
        }
    }

    // DDG HTML parse fallback
    private fun duckDuckGoHtml(query: String, n: Int): SearchResult {
        return try {
            val html = get("https://html.duckduckgo.com/html/?q=${enc(query)}")
            val pattern = Regex("<a class=\"result__a\" href=\"([^\"]+)\">([^<]+)</a>")
            val items = pattern.findAll(html).take(n).map {
                SearchItem(it.groupValues[2], it.groupValues[1], "")
            }.toList()
            SearchResult(query, "DuckDuckGo", items)
        } catch (_: Exception) {
            SearchResult(query, "None", emptyList(), error = "All search providers failed")
        }
    }

    // ── Autocomplete ──────────────────────────────────────
    suspend fun autocomplete(query: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&q=${enc(query)}"
            val json = JSONArray(get(url))
            val arr = json.optJSONArray(1) ?: return@withContext emptyList()
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) { emptyList() }
    }

    // ── URL fetch ─────────────────────────────────────────
    suspend fun fetchUrl(url: String): String = withContext(Dispatchers.IO) {
        try { get(url) } catch (e: Exception) { "Fetch failed: ${e.message}" }
    }

    // ── Google Maps / Places ──────────────────────────────
    suspend fun searchPlaces(query: String, location: String = ""): SearchResult = withContext(Dispatchers.IO) {
        val key = settings.googlePlacesApiKey
        if (key.isEmpty()) return@withContext SearchResult(query, "None", emptyList(),
            error = "Google Places API key not set")

        val url = "https://maps.googleapis.com/maps/api/place/textsearch/json" +
            "?query=${enc(query)}" +
            (if (location.isNotEmpty()) "&location=$location" else "") +
            "&key=$key"

        val json = JSONObject(get(url))
        val results = json.optJSONArray("results") ?: JSONArray()
        SearchResult(
            query = query,
            provider = "Google Places",
            items = (0 until minOf(results.length(), 5)).map { i ->
                val r = results.getJSONObject(i)
                SearchItem(
                    r.optString("name"),
                    "https://maps.google.com/?q=${enc(r.optString("name"))}",
                    "${r.optString("formatted_address")} | Rating: ${r.optDouble("rating", 0.0)}"
                )
            }
        )
    }

    // ── Helpers ───────────────────────────────────────────
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        val req = Request.Builder().url(url).apply {
            headers.forEach { (k, v) -> header(k, v) }
            header("User-Agent", "Mozilla/5.0 Maya/5.2.9")
        }.build()
        return http.newCall(req).execute().use { it.body!!.string() }
    }

    private fun post(url: String, body: JSONObject): String {
        val req = Request.Builder()
            .url(url)
            .post(okhttp3.RequestBody.create(
                okhttp3.MediaType.get("application/json"), body.toString()))
            .build()
        return http.newCall(req).execute().use { it.body!!.string() }
    }
}

data class SearchResult(
    val query: String,
    val provider: String,
    val items: List<SearchItem>,
    val error: String = ""
) {
    fun toPromptText() = if (error.isNotEmpty()) "Search failed: $error"
    else items.joinToString("\n") { "[${it.title}](${it.url})\n${it.snippet}" }
}

data class SearchItem(val title: String, val url: String, val snippet: String)
