package com.getmaya.android.ui.screens

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(navController: androidx.navigation.NavHostController) {
    var isListening by remember { mutableStateOf(false) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Good night ✨",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(onClick = { navController.navigate("settings") }) {
                Text("⚙️", fontSize = 24.sp)
            }
        }

        // M.A.Y.A Logo with Animation
        MayaLogoSection()

        // Greeting
        Text(
            "HOW CAN I HELP YOU?",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        )

        // Microphone Button
        MicrophoneButton(
            isListening = isListening,
            onClick = { isListening = !isListening }
        )

        // Status Cards
        StatusCardSection()

        // Info Cards
        InfoCardSection()

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun MayaLogoSection() {
    val infiniteTransition = rememberInfiniteTransition(label = "logo")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = InfiniteRepeatableSpec(
            animation = tween(1500),
            repeatMode = androidx.compose.animation.RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "M.A.Y.A",
                fontSize = 36.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.scale(scale)
            )
            Text(
                "Multimodal AI Your Assistant",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun MicrophoneButton(isListening: Boolean, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.2f else 1.05f,
        animationSpec = InfiniteRepeatableSpec(
            animation = tween(1000),
            repeatMode = androidx.compose.animation.RepeatMode.Reverse
        ),
        label = "micScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .size(100.dp)
                .scale(scale),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            shape = MaterialTheme.shapes.extraLarge
        ) {
            Text("🎤", fontSize = 40.sp)
        }
    }
}

@Composable
fun StatusCardSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatusCard("🌡️", "Ready", "System")
        StatusCard("🔋", "85%", "Battery")
        StatusCard("📡", "WiFi", "Network")
    }
}

@Composable
fun StatusCard(emoji: String, value: String, label: String) {
    Card(
        modifier = Modifier
            .weight(1f)
            .height(80.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(emoji, fontSize = 24.sp)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
        }
    }
}

@Composable
fun InfoCardSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Latest Updates",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground.copy(0.7f)
        )

        repeat(3) { index ->
            InfoCard(
                icon = when (index) {
                    0 -> "🌤️"
                    1 -> "😊"
                    else -> "📅"
                },
                title = when (index) {
                    0 -> "Weather"
                    1 -> "Mood"
                    else -> "Date"
                },
                value = when (index) {
                    0 -> "28°C, Sunny"
                    1 -> "Happy"
                    else -> "Thursday, Oct 8"
                }
            )
        }
    }
}

@Composable
fun InfoCard(icon: String, title: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Text(icon, fontSize = 20.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
                    Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Text("→", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}
