package com.getmaya.android.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.*

class VoiceManager(context: Context) : TextToSpeech.OnInitListener {
    private lateinit var textToSpeech: TextToSpeech
    private var isReady = false

    data class VoiceMode(
        val character: String,
        val mode: String,
        val speed: Float,
        val pitch: Float,
        val emotion: String
    )

    init {
        textToSpeech = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech.language = Locale.getDefault()
            isReady = true
        }
    }

    fun playVoice(text: String, voiceMode: VoiceMode) {
        if (isReady) {
            textToSpeech.pitch = voiceMode.pitch
            textToSpeech.setSpeechRate(voiceMode.speed)
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null)
        }
    }

    fun shutdown() {
        textToSpeech.shutdown()
    }
}

object CharacterVoices {
    val mayaGirlfriend = VoiceManager.VoiceMode("Maya", "Girlfriend", 0.95f, 1.1f, "Romantic")
    val mayaNormal = VoiceManager.VoiceMode("Maya", "Normal", 1.0f, 1.0f, "Neutral")
    val mayaFriend = VoiceManager.VoiceMode("Maya", "Friend", 1.05f, 0.95f, "Playful")
    val mayaMentor = VoiceManager.VoiceMode("Maya", "Mentor", 0.9f, 1.0f, "Educational")
    val friday = VoiceManager.VoiceMode("Friday", "Default", 1.0f, 1.2f, "Professional")
    val venom = VoiceManager.VoiceMode("Venom", "Symbiote", 0.85f, 0.7f, "Dark")
    val jarvis = VoiceManager.VoiceMode("Jarvis", "AI", 1.0f, 0.9f, "Robotic")
}

object VoiceFileMapping {
    val mayas = mapOf(
        "Girlfriend" to "maya_Leda.ogg",
        "Normal" to "maya_Autonoe.ogg",
        "Friend" to "maya_Callirrhoe.ogg",
        "Mentor" to "maya_Laomedeia.ogg"
    )
    
    val fridays = mapOf(
        "Assistant" to "friday_Leda.ogg",
        "Support" to "friday_Zephyr.ogg",
        "Expert" to "friday_Sulafat.ogg",
        "Smart" to "friday_Gacrux.ogg"
    )
    
    val venoms = mapOf(
        "Dark" to "venom_Alnilam.ogg",
        "Aggressive" to "venom_Iapetus.ogg",
        "Symbiote" to "venom_Achernar.ogg",
        "Intense" to "venom_Fenrir.ogg"
    )
    
    fun getVoiceFile(character: String, mode: String): String? {
        return when (character.lowercase()) {
            "maya" -> mayas[mode]
            "friday" -> fridays[mode]
            "venom" -> venoms[mode]
            else -> null
        }
    }
}
