package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SecurityScreen(navController: androidx.navigation.NavHostController) {
    var faceUnlockEnabled by remember { mutableStateOf(true) }
    var voiceGuardianEnabled by remember { mutableStateOf(true) }
    var biometricEnabled by remember { mutableStateOf(true) }
    var deviceLockEnabled by remember { mutableStateOf(true) }
    var appLockEnabled by remember { mutableStateOf(false) }
    var privacyModeEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            "🔐 Security & Privacy",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Biometric Security Section
        SecuritySection("🔓 Biometric Security") {
            SecurityToggleItem(
                icon = "👤",
                title = "Face Unlock",
                description = "Unlock device with face recognition",
                enabled = faceUnlockEnabled
            ) { faceUnlockEnabled = it }

            SecurityToggleItem(
                icon = "👆",
                title = "Fingerprint Lock",
                description = "Unlock with fingerprint sensor",
                enabled = biometricEnabled
            ) { biometricEnabled = it }

            SecurityToggleItem(
                icon = "🎤",
                title = "Voice Guardian",
                description = "Voice authentication for sensitive actions",
                enabled = voiceGuardianEnabled
            ) { voiceGuardianEnabled = it }
        }

        // Device Security Section
        SecuritySection("📱 Device Security") {
            SecurityToggleItem(
                icon = "🔒",
                title = "Device Lock",
                description = "Lock device when idle",
                enabled = deviceLockEnabled
            ) { deviceLockEnabled = it }

            SecurityToggleItem(
                icon = "🛡️",
                title = "App Lock",
                description = "Require authentication for each app",
                enabled = appLockEnabled
            ) { appLockEnabled = it }

            SecurityToggleItem(
                icon = "🕵️",
                title = "Privacy Mode",
                description = "Disable sharing and limit permissions",
                enabled = privacyModeEnabled
            ) { privacyModeEnabled = it }
        }

        // Advanced Security Section
        SecuritySection("⚙️ Advanced Settings") {
            SecurityActionItem(
                icon = "🔑",
                title = "Change PIN/Password",
                subtitle = "Set a new security PIN"
            ) { /* Navigate to PIN setup */ }

            SecurityActionItem(
                icon = "📋",
                title = "Manage Trusted Devices",
                subtitle = "View devices with access to Maya"
            ) { /* Navigate to trusted devices */ }

            SecurityActionItem(
                icon = "🗑️",
                title = "Clear All Data",
                subtitle = "Factory reset all Maya settings"
            ) { /* Show confirmation dialog */ }
        }

        // Security Status
        SecuritySection("✅ Security Status") {
            SecurityStatusCard(
                status = "All systems secure",
                lastCheckTime = "Just now",
                threatLevel = "None"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Save Button
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Save Security Settings", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SecuritySection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(bottom = 20.dp)) {
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        content()
    }
}

@Composable
fun SecurityToggleItem(
    icon: String,
    title: String,
    description: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f)) {
                Text(icon, fontSize = 20.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Switch(
                checked = enabled,
                onCheckedChange = onToggle
            )
        }
    }
}

@Composable
fun SecurityActionItem(
    icon: String,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f)) {
                Text(icon, fontSize = 20.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Text("→", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun SecurityStatusCard(status: String, lastCheckTime: String, threatLevel: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(status, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Last check: $lastCheckTime",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(0.7f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Text("✅", fontSize = 24.sp)
            }
            Text(
                "Threat Level: $threatLevel",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}
