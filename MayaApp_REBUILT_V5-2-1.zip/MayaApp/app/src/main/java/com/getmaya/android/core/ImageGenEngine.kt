package com.getmaya.android.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.getmaya.android.data.models.ImageProvider
import com.getmaya.android.data.models.MayaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

// ═══════════════════════════════════════════════════════════
// IMAGE GENERATION ENGINE — all providers from APK
//
// Providers:
// 1. Pollinations (FREE — 1 image per 15 seconds)
//    gen.pollinations.ai / image.pollinations.ai
// 2. OpenAI GPT Image 1
//    api.openai.com/v1/images/generations
// 3. Gemini
//    generativelanguage.googleapis.com (imagen model)
// 4. Together AI
//    api.together.xyz/v1/images/generations
// 5. Custom (OpenAI-compatible)
// ═══════════════════════════════════════════════════════════

class ImageGenEngine(private val settings: MayaSettings) {

    private val http = OkHttpClient()

    // ── Generate image (auto-picks provider) ──────────────
    suspend fun generate(
        prompt: String,
        size: String = "1024x1024",
        quality: String = "standard"
    ): ImageGenResult = withContext(Dispatchers.IO) {
        when (settings.imageProvider) {
            ImageProvider.POLLINATIONS_FREE -> pollinations(prompt)
            ImageProvider.OPENAI_IMAGE      -> openAiImage(prompt, size, quality)
            ImageProvider.GEMINI_IMAGE      -> geminiImage(prompt)
            ImageProvider.TOGETHER_IMAGE    -> togetherImage(prompt)
            ImageProvider.CUSTOM_IMAGE      -> customImage(prompt, size)
        }
    }

    // ── 1. Pollinations (FREE) ────────────────────────────
    // 1 per 15 seconds limit. No key required.
    private fun pollinations(prompt: String): ImageGenResult {
        val encoded = URLEncoder.encode(prompt, "UTF-8")
        val url = "https://image.pollinations.ai/prompt/$encoded?width=1024&height=1024&nologo=true"
        return try {
            val bytes = http.newCall(Request.Builder().url(url).build())
                .execute().use { it.body!!.bytes() }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ImageGenResult.Success(bmp, url, "Pollinations")
        } catch (e: Exception) {
            ImageGenResult.Error("Pollinations failed: ${e.message}")
        }
    }

    // ── 2. OpenAI GPT Image ───────────────────────────────
    private fun openAiImage(prompt: String, size: String, quality: String): ImageGenResult {
        val body = JSONObject().apply {
            put("model", if (settings.imageModelId.isEmpty()) "gpt-image-1" else settings.imageModelId)
            put("prompt", prompt)
            put("n", 1)
            put("size", size)
            put("quality", quality)
            put("response_format", "b64_json")
        }
        return try {
            val resp = http.newCall(
                Request.Builder()
                    .url("https://api.openai.com/v1/images/generations")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .header("Authorization", "Bearer ${settings.imageApiKey.ifEmpty { settings.openAiApiKey }}")
                    .build()
            ).execute().use { JSONObject(it.body!!.string()) }

            val b64 = resp.getJSONArray("data").getJSONObject(0).getString("b64_json")
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ImageGenResult.Success(bmp, "", "OpenAI GPT Image")
        } catch (e: Exception) {
            ImageGenResult.Error("OpenAI image failed: ${e.message}")
        }
    }

    // ── 3. Gemini Image ───────────────────────────────────
    private fun geminiImage(prompt: String): ImageGenResult {
        val key = settings.imageApiKey.ifEmpty { settings.geminiApiKey }
        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("IMAGE")))
        }
        return try {
            val resp = http.newCall(
                Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-preview-image-generation:generateContent?key=$key")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
            ).execute().use { JSONObject(it.body!!.string()) }

            val part = resp.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            val b64 = part.getJSONObject("inlineData").getString("data")
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ImageGenResult.Success(bmp, "", "Gemini")
        } catch (e: Exception) {
            ImageGenResult.Error("Gemini image failed: ${e.message}")
        }
    }

    // ── 4. Together AI ────────────────────────────────────
    private fun togetherImage(prompt: String): ImageGenResult {
        val body = JSONObject().apply {
            put("model", settings.imageModelId.ifEmpty { "black-forest-labs/FLUX.1-schnell-Free" })
            put("prompt", prompt)
            put("n", 1)
            put("steps", 4)
        }
        return try {
            val resp = http.newCall(
                Request.Builder()
                    .url("https://api.together.xyz/v1/images/generations")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .header("Authorization", "Bearer ${settings.imageApiKey.ifEmpty { settings.togetherApiKey }}")
                    .build()
            ).execute().use { JSONObject(it.body!!.string()) }

            val b64 = resp.getJSONArray("data").getJSONObject(0).optString("b64_json")
            val url = resp.getJSONArray("data").getJSONObject(0).optString("url")

            if (b64.isNotEmpty()) {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                ImageGenResult.Success(BitmapFactory.decodeByteArray(bytes, 0, bytes.size), url, "Together AI")
            } else if (url.isNotEmpty()) {
                val bytes = http.newCall(Request.Builder().url(url).build()).execute().use { it.body!!.bytes() }
                ImageGenResult.Success(BitmapFactory.decodeByteArray(bytes, 0, bytes.size), url, "Together AI")
            } else ImageGenResult.Error("Together: no image in response")
        } catch (e: Exception) {
            ImageGenResult.Error("Together failed: ${e.message}")
        }
    }

    // ── 5. Custom OpenAI-compatible ───────────────────────
    private fun customImage(prompt: String, size: String): ImageGenResult {
        val url = "${settings.customEndpointUrl}/images/generations"
        val body = JSONObject().apply {
            put("model", settings.imageModelId.ifEmpty { "flux" })
            put("prompt", prompt)
            put("n", 1)
            put("size", size)
        }
        return try {
            val resp = http.newCall(
                Request.Builder()
                    .url(url)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .apply { if (settings.imageApiKey.isNotEmpty()) header("Authorization", "Bearer ${settings.imageApiKey}") }
                    .build()
            ).execute().use { JSONObject(it.body!!.string()) }
            val imgUrl = resp.getJSONArray("data").getJSONObject(0).optString("url")
            val bytes = http.newCall(Request.Builder().url(imgUrl).build()).execute().use { it.body!!.bytes() }
            ImageGenResult.Success(BitmapFactory.decodeByteArray(bytes, 0, bytes.size), imgUrl, "Custom")
        } catch (e: Exception) {
            ImageGenResult.Error("Custom image failed: ${e.message}")
        }
    }
}

sealed class ImageGenResult {
    data class Success(val bitmap: Bitmap, val url: String, val provider: String) : ImageGenResult()
    data class Error(val message: String) : ImageGenResult()
}
