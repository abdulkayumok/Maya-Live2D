package com.getmaya.android.termux

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

// ═══════════════════════════════════════════════════════════
// TERMUX BRIDGE — shell command execution on the phone
//
// From APK:
// Permission: com.termux.permission.RUN_COMMAND
// Receiver: TermuxResultReceiver (com.getmaya.android.TERMUX_RESULT)
//
// One-time Termux setup (user types this once):
// mkdir -p ~/.termux && echo 'allow-external-apps = true' \
// >> ~/.termux/termux.properties && termux-reload-settings
//
// Termux setup script:
// cd ~ && wget -O setup.sh
// https://raw.githubusercontent.com/HunterisLive-1/Turmux-setup/main/hunter.sh
//
// OpenClaw gateway:
// curl -fsSL https://openclaw.ai/install.sh | bash
// openclaw onboard --install-daemon
// Dashboard: http://localhost:18789
//
// HerMES agent:
// cd ~ && rm -rf hermes-agent &&
// git clone --depth 1 https://github.com/NousResearch/hermes-agent.git
// ═══════════════════════════════════════════════════════════

class TermuxBridge(private val context: Context) {

    companion object {
        const val TERMUX_SERVICE   = "com.termux/.app.TermuxService"
        const val TERMUX_PKG       = "com.termux"
        const val RUN_COMMAND_PKG  = "com.termux.api"
        const val RESULT_ACTION    = "com.getmaya.android.TERMUX_RESULT"
        const val TIMEOUT_MS       = 30_000L

        // Static callback registry — shared across all TermuxBridge instances.
        // TermuxResultReceiver calls this to deliver results to waiting coroutines.
        private val globalCallbacks = mutableMapOf<String, (TermuxResult) -> Unit>()

        fun deliverResult(execId: String, rawResult: String): Boolean {
            val cb = globalCallbacks.remove(execId) ?: return false
            cb(TermuxResult(stdout = rawResult, stderr = "", exitCode = 0))
            return true
        }
    }

    private var pendingCallbacks = globalCallbacks
    private var isReceiverRegistered = false

    // ── Check if Termux is installed and configured ────────
    fun isAvailable(): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PKG, 0)
            true
        } catch (_: Exception) { false }
    }

    // ── Run a shell command ────────────────────────────────
    suspend fun run(command: String): TermuxResult =
        withTimeoutOrNull(TIMEOUT_MS) {
            suspendCancellableCoroutine { cont ->
                val execId = System.currentTimeMillis().toString()

                // Register one-time result receiver
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(ctx: Context, intent: Intent) {
                        if (intent.getStringExtra("exec_id") != execId) return
                        val stdout = intent.getStringExtra("stdout") ?: ""
                        val stderr = intent.getStringExtra("stderr") ?: ""
                        val exitCode = intent.getIntExtra("exit_code", -1)
                        context.unregisterReceiver(this)
                        cont.resume(TermuxResult(stdout, stderr, exitCode))
                    }
                }
                context.registerReceiver(receiver, IntentFilter(RESULT_ACTION))

                // Send command to Termux
                val intent = Intent().apply {
                    setClassName(TERMUX_PKG, "$TERMUX_PKG.app.RunCommandService")
                    action = "$TERMUX_PKG.RUN_COMMAND"
                    putExtra("$TERMUX_PKG.RUN_COMMAND_PATH", "/data/data/$TERMUX_PKG/files/usr/bin/bash")
                    putExtra("$TERMUX_PKG.RUN_COMMAND_ARGUMENTS", arrayOf("-c", wrapCommand(command, execId)))
                    putExtra("$TERMUX_PKG.RUN_COMMAND_WORKDIR", "/data/data/$TERMUX_PKG/files/home")
                    putExtra("$TERMUX_PKG.RUN_COMMAND_BACKGROUND", true)
                    putExtra("$TERMUX_PKG.RUN_COMMAND_SESSION_ACTION", "0")
                }
                try { context.startService(intent) }
                catch (e: Exception) { cont.resume(TermuxResult("", e.message ?: "Termux error", -1)) }

                cont.invokeOnCancellation {
                    try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
                }
            }
        } ?: TermuxResult("", "Timeout after ${TIMEOUT_MS}ms", -1)

    // Wrap command to send result back to Maya via broadcast
    private fun wrapCommand(cmd: String, execId: String): String = """
        STDOUT=$( $cmd 2>/tmp/maya_stderr_$execId )
        EXIT_CODE=$?
        STDERR=$(cat /tmp/maya_stderr_$execId 2>/dev/null)
        am broadcast -a $RESULT_ACTION \
          --es exec_id "$execId" \
          --es stdout "${'$'}STDOUT" \
          --es stderr "${'$'}STDERR" \
          --ei exit_code ${'$'}EXIT_CODE \
          com.getmaya.android 2>/dev/null
    """.trimIndent()

    // ── Common commands Maya uses ──────────────────────────
    suspend fun listFiles(path: String = "~"): TermuxResult = run("ls -la $path")
    suspend fun readFile(path: String): TermuxResult = run("cat $path")
    suspend fun writeFile(path: String, content: String): TermuxResult {
        val escaped = content.replace("'", "'\\''")
        return run("mkdir -p $(dirname '$path') && printf '%s' '$escaped' > '$path'")
    }
    suspend fun runPython(script: String): TermuxResult = run("python3 -c '$script'")
    suspend fun gitClone(url: String, dir: String = ""): TermuxResult = run("git clone $url $dir")
    suspend fun gitPush(msg: String = "Maya update"): TermuxResult = run("git add -A && git commit -m '$msg' && git push")
    suspend fun npmInstall(): TermuxResult = run("npm install")
    suspend fun npmStart(): TermuxResult = run("npm start &")
    suspend fun curl(url: String, args: String = ""): TermuxResult = run("curl -s $args '$url'")
    suspend fun openClawStatus(): TermuxResult = run("openclaw status")
    suspend fun serverStatus(): TermuxResult = run("ps aux | grep -E 'node|python|ruby|php' | grep -v grep")

    // ── Setup commands ─────────────────────────────────────
    fun getSetupInstructions(): String = """
        ┌─ TERMUX SETUP (one-time) ─────────────────────────
        │ 1. Install Termux from F-Droid
        │ 2. Open Termux and paste:
        │
        │    mkdir -p ~/.termux
        │    echo 'allow-external-apps = true' >> ~/.termux/termux.properties
        │    termux-reload-settings
        │
        │ 3. (Optional) Full setup:
        │    cd ~ && wget -O setup.sh https://raw.githubusercontent.com/HunterisLive-1/Turmux-setup/main/hunter.sh
        │    bash setup.sh
        │
        │ 4. (Optional) OpenClaw AI gateway:
        │    curl -fsSL https://openclaw.ai/install.sh | bash
        │    openclaw onboard --install-daemon
        │    Dashboard: http://localhost:18789
        └───────────────────────────────────────────────────
    """.trimIndent()
}

// TermuxResultReceiver is in TermuxResultReceiver.kt (com.getmaya.android.termux package)

data class TermuxResult(
    val stdout: String,
    val stderr: String,
    val exitCode: Int
) {
    val success get() = exitCode == 0
    val output  get() = if (stdout.isNotBlank()) stdout else stderr
}

    // ── Convenience exec (used by CodeTools) ───────────────
    suspend fun exec(command: String): String? = withTimeoutOrNull(TIMEOUT_MS) {
        run(command)?.stdout
    }
