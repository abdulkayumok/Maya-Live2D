package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(navController: androidx.navigation.NavHostController) {
    var selectedCharacter by remember { mutableStateOf("Maya") }
    var selectedMode by remember { mutableStateOf("Normal") }
    var voiceSpeed by remember { mutableStateOf(80f) }
    var voicePitch by remember { mutableStateOf(100f) }
    var language by remember { mutableStateOf("English") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            "⚙️ Settings",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Profile Section
        SettingsSection("👤 Profile") {
            DropdownSetting("Character", selectedCharacter) {
                selectedCharacter = it
            }
            DropdownSetting("Language", language) {
                language = it
            }
        }

        // Voice Settings Section
        SettingsSection("🎙️ Voice Settings") {
            DropdownSetting("Voice Mode", selectedMode) {
                selectedMode = it
            }
            
            SliderSetting(
                "Voice Speed",
                voiceSpeed,
                0f..100f
            ) { voiceSpeed = it }

            SliderSetting(
                "Voice Pitch",
                voicePitch,
                0f..100f
            ) { voicePitch = it }
        }

        // Security Section
        SettingsSection("🔐 Security") {
            ToggleSetting("Face Unlock", true) {}
            ToggleSetting("Voice Guardian", true) {}
        }

        // Data Section
        SettingsSection("📊 Data") {
            ToggleSetting("Cloud Sync", true) {}
            ToggleSetting("Auto Backup", false) {}
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Save Button
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("Save Settings", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(bottom = 20.dp)) {
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        content()
    }
}

@Composable
fun DropdownSetting(label: String, selectedValue: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val options = when (label) {
        "Character" -> listOf("Maya", "Friday", "Venom")
        "Voice Mode" -> listOf("Girlfriend", "Normal", "Friend", "Mentor")
        "Language" -> listOf("English", "हिंदी", "Español")
        else -> listOf(selectedValue)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(selectedValue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("▼", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SliderSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValueChange: (Float) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
                Text("${value.toInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = range,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun ToggleSetting(label: String, enabled: Boolean, onToggle: (Boolean) -> Unit) {
    var isEnabled by remember { mutableStateOf(enabled) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Switch(
                checked = isEnabled,
                onCheckedChange = {
                    isEnabled = it
                    onToggle(it)
                }
            )
        }
    }
}
