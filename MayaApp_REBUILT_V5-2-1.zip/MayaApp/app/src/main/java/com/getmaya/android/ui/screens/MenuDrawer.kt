package com.getmaya.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ═══════════════════════════════════════════════════════════
// MENU DRAWER — matches exact Maya screenshot
// Sections: HOME / PRODUCTIVITY / SYSTEM / OTHER
// ═══════════════════════════════════════════════════════════

sealed class DrawerDestination(val label: String, val icon: String) {
    // HOME section
    object Home         : DrawerDestination("Home", "🏠")
    object MayaHome     : DrawerDestination("Maya Home", "🏡")
    object Memories     : DrawerDestination("Memories", "🧠")
    object Chat         : DrawerDestination("Chat", "💬")

    // PRODUCTIVITY section
    object Markets      : DrawerDestination("Markets", "📈")
    object Marketing    : DrawerDestination("Marketing", "🏪")
    object Documents    : DrawerDestination("Documents", "📄")
    object WebsiteCoding: DrawerDestination("Website / Coding", "💻")
    object StudyWhiteboard: DrawerDestination("Study / Whiteboard", "✏️")

    // SYSTEM section
    object Settings     : DrawerDestination("Settings", "⚙️")
    object MayaRules    : DrawerDestination("Maya Rules", "🛡️")
    object PcPhoneLink  : DrawerDestination("PC ⇄ Phone", "🔄")

    // OTHER section
    object PrivacyPolicy: DrawerDestination("Privacy Policy", "🔒")
    object About        : DrawerDestination("About", "ℹ️")
    object Upgrade      : DrawerDestination("Upgrade", "⭐")
    object Notifications: DrawerDestination("Notifications", "🔔")
}

@Composable
fun MayaMenuDrawer(
    currentDestination: DrawerDestination = DrawerDestination.Home,
    onNavigate: (DrawerDestination) -> Unit,
    appVersion: String = "5.2.9"
) {
    Column(
        modifier = Modifier
            .width(300.dp)
            .fillMaxHeight()
            .background(Color(0xFF0D1525))
            .verticalScroll(rememberScrollState())
    ) {
        // ── HEADER ────────────────────────────────────────
        DrawerHeader()

        // ── HOME ──────────────────────────────────────────
        DrawerSection("HOME")
        DrawerItem(DrawerDestination.Home, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.MayaHome, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.Memories, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.Chat, currentDestination, onNavigate)

        // ── PRODUCTIVITY ──────────────────────────────────
        DrawerSection("PRODUCTIVITY")
        DrawerItem(DrawerDestination.Markets, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.Marketing, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.Documents, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.WebsiteCoding, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.StudyWhiteboard, currentDestination, onNavigate)

        // ── SYSTEM ────────────────────────────────────────
        DrawerSection("SYSTEM")
        DrawerItem(DrawerDestination.Settings, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.MayaRules, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.PcPhoneLink, currentDestination, onNavigate)

        // ── OTHER ─────────────────────────────────────────
        DrawerSection("OTHER")
        DrawerItem(DrawerDestination.PrivacyPolicy, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.About, currentDestination, onNavigate)
        // Upgrade with orange dot badge
        DrawerItemWithBadge(DrawerDestination.Upgrade, currentDestination, onNavigate)
        DrawerItem(DrawerDestination.Notifications, currentDestination, onNavigate)

        Spacer(modifier = Modifier.weight(1f))

        // ── FOOTER ────────────────────────────────────────
        Text(
            text = "v$appVersion  ·  Sir Abdul Kayum Ai",
            color = Color(0xFF445566),
            fontSize = 11.sp,
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Composable
fun DrawerHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Maya icon
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1A2540)),
            contentAlignment = Alignment.Center
        ) {
            Text("M", color = Color(0xFF4A90D9), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text("Maya", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("by Sir Abdul Kayum Ai", color = Color(0xFF8899AA), fontSize = 13.sp)
        }
    }
    Divider(color = Color(0xFF1A2540), thickness = 0.5.dp)
    Spacer(modifier = Modifier.height(8.dp))
}

@Composable
fun DrawerSection(title: String) {
    Text(
        text = title,
        color = Color(0xFF556677),
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp)
    )
}

@Composable
fun DrawerItem(
    destination: DrawerDestination,
    current: DrawerDestination,
    onNavigate: (DrawerDestination) -> Unit
) {
    val isActive = destination == current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isActive) Color(0xFF1A3060) else Color.Transparent)
            .clickable { onNavigate(destination) }
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(destination.icon, fontSize = 18.sp)
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = destination.label,
            color = if (isActive) Color(0xFF4A90D9) else Color(0xFFCCD8E8),
            fontSize = 16.sp,
            fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal
        )
    }
}

@Composable
fun DrawerItemWithBadge(
    destination: DrawerDestination,
    current: DrawerDestination,
    onNavigate: (DrawerDestination) -> Unit
) {
    val isActive = destination == current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isActive) Color(0xFF1A3060) else Color.Transparent)
            .clickable { onNavigate(destination) }
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(destination.icon, fontSize = 18.sp)
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = destination.label,
            color = if (isActive) Color(0xFF4A90D9) else Color(0xFFCCD8E8),
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        // Orange notification dot
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(Color(0xFFFF8C00))
        )
    }
}
