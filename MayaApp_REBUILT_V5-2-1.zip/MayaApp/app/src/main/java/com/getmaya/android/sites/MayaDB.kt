package com.getmaya.android.sites

import com.getmaya.android.data.models.MayaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════
// MAYA DB — cloud database for deployed Maya Sites
// Script: https://getmaya.cloud/_maya/db.js
//
// From APK strings (verbatim):
// await MayaDB.add("scores", {name, score})       → new id
// await MayaDB.list("scores", {limit: 20})         → [{id,data,created}]
// await MayaDB.update("scores", id, obj)
// await MayaDB.remove("scores", id)
// await MayaDB.inc("counters", "likes", "count", 1) → new number
// Private: prefix "private_" → owner-only
// ═══════════════════════════════════════════════════════════

class MayaSitesClient(private val settings: MayaSettings) {

    private val http = OkHttpClient()
    private val BASE = "https://getmaya.cloud"

    // ── Deploy a site ──────────────────────────────────────
    // First deploy: requires confirm=false, Maya returns CONFIRM_REQUIRED
    // Second call with confirm=true → deploys to https://<name>.getmaya.cloud
    suspend fun deploy(
        siteName: String,
        htmlContent: String,
        confirm: Boolean = false
    ): DeployResult = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("site_name", siteName)
            put("html", htmlContent)
            put("confirmed", confirm)
        }
        val resp = post("$BASE/api/deploy", body)
        when (resp.optString("status")) {
            "CONFIRM_REQUIRED" -> DeployResult.ConfirmRequired(
                resp.optString("message", "Confirm site name: $siteName")
            )
            "DEPLOYED" -> DeployResult.Success(
                url = resp.optString("url", "https://$siteName.getmaya.cloud")
            )
            else -> DeployResult.Error(resp.optString("error", "Unknown error"))
        }
    }

    // ── List sites ────────────────────────────────────────
    suspend fun listSites(): JSONObject = withContext(Dispatchers.IO) {
        get("$BASE/api/sites")
    }

    // ── MayaDB API (called from deployed site JS) ─────────
    // These are client-side calls made FROM the deployed page JS:
    // <script src="https://getmaya.cloud/_maya/db.js"></script>
    // Then: await MayaDB.add("collection", {field: value})

    // Management: check DB from Maya app
    suspend fun dbList(siteName: String, collection: String, limit: Int = 20): JSONObject = withContext(Dispatchers.IO) {
        get("$BASE/api/db/$siteName/$collection?limit=$limit")
    }

    suspend fun dbDelete(siteName: String, collection: String, id: String) = withContext(Dispatchers.IO) {
        delete("$BASE/api/db/$siteName/$collection/$id")
    }

    // ── Helpers ───────────────────────────────────────────
    private fun get(url: String) = JSONObject(
        http.newCall(Request.Builder().url(url).build())
            .execute().use { it.body!!.string() }
    )
    private fun post(url: String, body: JSONObject) = JSONObject(
        http.newCall(Request.Builder().url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build())
            .execute().use { it.body!!.string().ifEmpty { "{}" } }
    )
    private fun delete(url: String) {
        http.newCall(Request.Builder().url(url).delete().build()).execute().close()
    }
}

sealed class DeployResult {
    data class Success(val url: String) : DeployResult()
    data class ConfirmRequired(val message: String) : DeployResult()
    data class Error(val message: String) : DeployResult()
}
