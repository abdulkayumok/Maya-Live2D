# Maya APK ↔ source comparison — updated work report
Date: 10 Oct 2026

## Selected base
`MayaApp_FINAL_FIXED_SOURCE.zip` remains the base because it has explicit dependency versions and editable launcher/resources. The TAR archive has no `gradle/libs.versions.toml` despite using `libs.*` aliases, and its receiver/service files overlap classes grouped in the ZIP source. Blindly copying them would risk duplicate classes.

## Changes made in this pass
1. Registered `MayaApplication` in the manifest. Before this, `MayaApplication.instance` and its `SettingsRepository` would not initialize reliably.
2. Connected `MayaVoiceInteractionService` to `@xml/voice_interaction` metadata, and added the appropriate binding permissions to the session and recognition services.
3. Registered `MayaAssistActivity` for the Android `ASSIST` action so the existing activity can be invoked by the system.
4. Implemented the Deepgram path in `MayaRecognitionService` using `SttEngine`: interim results, final results, error handling, cleanup, and Android SpeechRecognizer fallback on Deepgram failure.
5. Hardened `SttEngine` microphone initialization and read/stop/release handling against invalid buffer sizes, initialization failures, and stop races.
6. Replaced the empty foreground-service body with a notification/channel lifecycle and explicit START/STANDBY/CAPTURE_MIC/STOP action handling. This prevents the service from silently doing nothing, but it does NOT yet implement continuous wake-word listening.
7. Wired the marketing/social alarm receiver components in the manifest and made `MarketingEngine` alarms use explicit receiver components, avoiding Android 8+ implicit-broadcast delivery restrictions.
8. Retained APK notice/license assets and the arm64 PocketTTS JNI library from the earlier merge.
9. Corrected Compose compiler setup for Kotlin 1.9.22 using compiler extension 1.5.8.

## Static checks completed
- All source XML files parse successfully.
- All Android component class names referenced by the manifest have a matching Kotlin declaration.
- No existing Kotlin source files were removed.
- ZIP integrity check passed after packaging.

## Remaining work — not yet proven or completed
### APK-only DEX class candidates requiring real mapping/decompilation
- `com.getmaya.android.agentic.ondevice.PcmSink`
- `com.getmaya.android.agentic.ondevice.PocketTtsNative`
- `com.getmaya.android.data.wiki.WikiWorker`
- `com.getmaya.android.msa.vad.VadSegment`
- `com.getmaya.android.notify.NoticeWorker`
- `com.getmaya.android.social.SocialAlarmReceiver`
- `com.getmaya.android.telemetry.OpsUploader`
- `com.getmaya.android.termux.TermuxPermissionActivity`

These are candidates from class inventory, not proof that all their behavior is absent. They need full DEX decompilation and method-level mapping before implementation; speculative stubs would create false parity.

### Feature work still incomplete
- Wake-word model preprocessing, inference input shapes, microphone loop, start/stop lifecycle, and background reliability.
- PocketTTS native Kotlin/JNI bridge and actual playback pipeline.
- Wiki/Memory background worker and persistent memory end-to-end testing.
- Marketing alarm receiver bodies currently contain placeholder handling; event delivery is wired, business logic remains.
- Settings actions and the remaining Documents/Coding/Study/Markets/Notifications/PC↔Phone screens need click-path and backend checks.
- Voice reply integration end-to-end (STT -> command/AI -> TTS) needs device test.
- Four persona voice/language behavior needs runtime comparison to reference APK.
- Permission flows and Android 14 background microphone restrictions need testing on a real device.

## Build status
A successful APK build has NOT been verified. This environment has no Android SDK/platform tools, no Gradle executable, and the project archive does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. Static checks cannot establish that Kotlin compilation, resource linking, DEX packaging, or installation succeeds.

## Required final verification
1. Open the project in Android Studio with JDK 17 and Android SDK Platform 34 installed.
2. Run Gradle sync, then `:app:assembleDebug`.
3. Save the complete Build Output and fix actual compile/resource errors.
4. Install the generated APK and test voice, wake-word, permissions, memory, settings and alarm flows.
5. Decode the reference APK fully with JADX/apktool and map the remaining DEX classes/methods before claiming feature parity.
